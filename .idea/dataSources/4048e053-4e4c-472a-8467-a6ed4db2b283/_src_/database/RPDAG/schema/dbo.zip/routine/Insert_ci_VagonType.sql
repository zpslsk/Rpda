
----------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Insert_ci_VagonType]
@type_code int,
@eks_code int,
@type_name nvarchar(50),
@weight float,
@length float,
@num_axel int

as

Insert into ci_VagonType (type_code, eks_code, type_name, weight, length, num_axel)
Values(@type_code, @eks_code, @type_name, @weight, @length, @num_axel)

