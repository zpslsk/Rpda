/*****************************************************************
-- Автор:	Сираджи Р.Ф.
-- Описание:	Удаляет данные из оперативных таблиц,
--                 при @bDeleteDrivLoc = 1 удаляет также данные по машинистам и локомотивам,
--                 при @bDeleteMap = 1 удаляет также данные о плечах, норме по плечам и считанным картам
*****************************************************************/
CREATE PROCEDURE [dbo].[sp_DeleteAllData]
@bDeleteDrivLoc bit,
@bDeleteMap bit

AS

--select @bDeleteDrivLoc = 1, @bDeleteMap = 1

delete from m_RegimInfo

declare @train_id int
declare curTr cursor READ_ONLY for select train_id from m_Trains
open curTr
FETCH FROM curTr into @train_id
WHILE @@FETCH_STATUS = 0 begin
exec sp_DeleteTrainById @train_id, 1
FETCH FROM curTr into @train_id
end

CLOSE curTr
DEALLOCATE curTr

truncate table Rep_Filter
delete from z_ReadError
delete from z_ListError
delete from m_XFiles

if @bDeleteDrivLoc = 1 begin
delete from ci_Drivers
delete from ci_Loc_Section
delete from ci_Section
delete from ci_Locomotiv
end
if @bDeleteMap = 1 begin
truncate table ci_SSByMap
truncate table ci_StByMap
truncate table ci_StbySS
delete from ci_NormaSS where bDefault = 0
delete from ci_ServiceSoulder
delete from ci_Station
delete from ci_Map
end

