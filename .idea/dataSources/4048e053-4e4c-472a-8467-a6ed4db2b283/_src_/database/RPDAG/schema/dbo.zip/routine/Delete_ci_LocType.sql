------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Delete_ci_LocType]
@type_id int

as

Delete from ci_LocType where type_id = @type_id

