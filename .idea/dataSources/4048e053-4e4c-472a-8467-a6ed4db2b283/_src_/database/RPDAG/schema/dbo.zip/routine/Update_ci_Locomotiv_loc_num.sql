-------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Update_ci_Locomotiv_loc_num]
@loc_id int,
@loc_num char(20)

as

Update ci_Locomotiv
set loc_num = @loc_num
where loc_id = @loc_id

