CREATE PROCEDURE sp_RepTrains 

@dateBegin DateTime,
@dateEnd DateTime

AS

select train_num, surname+' '+Left(name,1)+' '+Left(patronymic,1) as Driver, convert(char(20),[date],120) as DateBegin,
    DrawMeter, Run_Common
    from m_Trains Left Join ci_Drivers on mashinist_id = drv_id
    where [date] between @dateBegin and @dateEnd 