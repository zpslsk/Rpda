
/*****************************************************************
-- Автор:	Сираджи Р.Ф. 
-- Описание:	Обновляет данные для отчетов
*****************************************************************/
CREATE PROCEDURE sp_UpdateReportData
  @bWholeBase bit, 
  @dtStart DateTime, 
  @dtFinish DateTime

AS

  declare @train_id int

  if @bWholeBase = 1 
    declare curUpdate cursor READ_ONLY for select train_id from m_Trains 
  else 
    declare curUpdate cursor READ_ONLY for select train_id from m_Trains where dateTr between @dtStart and @dtFinish

  OPEN curUpdate
  FETCH FROM curUpdate into @train_id
  WHILE @@FETCH_STATUS = 0 begin
    exec sp_FillTrainInfo @train_id
    FETCH FROM curUpdate into @train_id
  end

  CLOSE curUpdate
  DEALLOCATE curUpdate


