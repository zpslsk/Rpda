-----------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Update_ci_Locomotiv_koefNorma]
@loc_type int,
@loc_id int,
@koefNorma float

as

Update ci_Locomotiv set koefNorma = @koefNorma
where (loc_type = @loc_type and @loc_id = 0) or
(loc_id = @loc_id and @loc_type = 0)

