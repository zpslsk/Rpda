--------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Update_ci_Drivers]
@tb_num int,
@surname nvarchar(20),
@name nvarchar(20),
@patronymic nvarchar(20),
@DrvCol int,
@drv_id int,
@n_road int,
@n_tch int

as

Update ci_Drivers
set tb_num = @tb_num, surname = @surname, name = @name, patronymic = @patronymic, DrvCol = @DrvCol
where drv_id = @drv_id and n_road = @n_road and n_tch = @n_tch

