
CREATE PROCEDURE [dbo].[Rep_ViolAndDriver]
@bByDriver bit,
@nFilter int,
@dtStart DateTime,
@dtFinish DateTime,
@TypeRep int,
@E_Invalidate int,
@V_Invalidate bit,
@IsResidence bit,
@NumRoad int,
@NumTch int,
@IsDateTrains bit

as

--select @bByDriver =1, @nFilter = -1, @dtStart = '2004-01-01', @dtFinish = '2005-12-01'

if @bByDriver = 0 begin
Select -1 as drv_id, NULL as tb_num, 'Все машинисты в целом' as FIO, count(*)as cnt
from m_Violation v
inner join m_Trains a on v.tr_id = a.train_id
inner join m_XFiles on m_XFiles.id_image = a.image_id
inner join m_TrainsInfo b on b.train_id = a.train_id
inner join ci_ViolationType cv on  cv.idV = v.v_id
inner join ci_Locomotiv on ci_Locomotiv.loc_id = b.loc_id
left join Rep_Filter R1 on R1.nFilter = @nFilter and R1.FCode = 2 and b.loc_id = R1.FValue
left join Rep_Filter R2 on R2.nFilter = @nFilter and R2.FCode = 3 and drv_id = R2.FValue
where

--dateTr between @dtStart and @dtFinish and

(
(dateTr between @dtStart and @dtFinish and @IsDateTrains > 0) or
(DataLastRead between @dtStart and @dtFinish and @IsDateTrains = 0)
) and


R1.FValue is NULL and R2.FValue is NULL and
((@E_Invalidate = -1) or (E_Invalidate = @E_Invalidate)) and
V_Invalidate = @V_Invalidate and
((@NumRoad = 0) or (num_road = @NumRoad)) and
((@NumTch = 0) or (num_tch = @NumTch)) and

((Residence = @IsResidence) or (@IsResidence = 0)) and

(
(((cv.vCode >= 100) and (cv.vCode < 200)) and (@TypeRep = 1) ) or
(((cv.vCode >= 200) and (cv.vCode < 300)) and (@TypeRep = 2) ) or
(((cv.vCode >= 300) and (cv.vCode < 400)) and (@TypeRep = 3) ) or
(((cv.vCode >= 400) and (cv.vCode < 500)) and (@TypeRep = 4) ) or
(((cv.vCode >= 500) and (cv.vCode < 600)) and (@TypeRep = 5) ) or
(((cv.vCode >= 600) and (cv.vCode < 700)) and (@TypeRep = 6) ) or
(@TypeRep = 0)
)
end

else begin
Select ci_Locomotiv.loc_id as drv_id, '' as FIO,
Min(cast(ci_Locomotiv.loc_num as int )) as tb_num, count(*)as cnt
from ci_Drivers dr
inner join m_Trains a on dr.drv_id = a.drv_id
inner join m_XFiles on m_XFiles.id_image = a.image_id
inner join m_TrainsInfo b on b.train_id = a.train_id
inner join m_Violation v on  v.tr_id = a.train_id
inner join ci_ViolationType cv on  cv.idV = v.v_id
inner join ci_Locomotiv on ci_Locomotiv.loc_id = b.loc_id
left join Rep_Filter R1 on R1.nFilter = @nFilter and R1.FCode = 2 and b.loc_id = R1.FValue
left join Rep_Filter R2 on R2.nFilter = @nFilter and R2.FCode = 3 and dr.drv_id = R2.FValue
where

--dateTr between @dtStart and @dtFinish and
(
(dateTr between @dtStart and @dtFinish and @IsDateTrains > 0) or
(DataLastRead between @dtStart and @dtFinish and @IsDateTrains = 0)
) and

R1.FValue is NULL and R2.FValue is NULL
and ((@E_Invalidate = -1) or (E_Invalidate = @E_Invalidate)) and
V_Invalidate = @V_Invalidate and
((@NumRoad = 0) or (num_road = @NumRoad)) and
((@NumTch = 0) or (num_tch = @NumTch)) and

((Residence = @IsResidence) or (@IsResidence = 0)) and
(
(((cv.vCode >= 100) and (cv.vCode < 200)) and (@TypeRep = 1) ) or
(((cv.vCode >= 200) and (cv.vCode < 300)) and (@TypeRep = 2) ) or
(((cv.vCode >= 300) and (cv.vCode < 400)) and (@TypeRep = 3) ) or
(((cv.vCode >= 400) and (cv.vCode < 500)) and (@TypeRep = 4) ) or
(((cv.vCode >= 500) and (cv.vCode < 600)) and (@TypeRep = 5) ) or
(((cv.vCode >= 600) and (cv.vCode < 700)) and (@TypeRep = 6) ) or
(@TypeRep = 0)
)

group by ci_Locomotiv.loc_id
order by FIO
end
