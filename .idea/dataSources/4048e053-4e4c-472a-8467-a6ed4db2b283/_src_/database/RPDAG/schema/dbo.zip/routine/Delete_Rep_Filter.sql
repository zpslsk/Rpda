

CREATE PROCEDURE [dbo].[Delete_Rep_Filter]

as

Delete from Rep_Filter

