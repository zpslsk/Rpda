------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Delete_ci_NormaSS]
@id int

as

delete from ci_NormaSS where id = @id

