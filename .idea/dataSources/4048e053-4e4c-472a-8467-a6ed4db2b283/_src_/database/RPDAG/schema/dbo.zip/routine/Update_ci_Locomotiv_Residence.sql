------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Update_ci_Locomotiv_Residence]
@Residence bit,
@loc_Type int,
@loc_num char(20)

as

update ci_Locomotiv
set Residence = @Residence
where loc_Type = @loc_Type and
loc_num = @loc_num

