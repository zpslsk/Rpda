
-------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Insert_m_Taksirovka]
@train_id int,
@st_id int,
@km int,
@pk int,
@DateTime_In datetime,
@DateTime_Out datetime,
@valALSN int,
@speed int,
@bCorrect bit,
@ECounterIn float,
@ECounterOut float,
@ERecupIn float,
@ERecuOut float

as

Insert into m_Taksirovka (train_id, st_id, km, pk, DateTime_In, DateTime_Out, valALSN, speed, bCorrect, ECounterIn, ECounterOut, ERecupIn, ERecuOut)
Values(@train_id, @st_id, @km, @pk, @DateTime_In, @DateTime_Out, @valALSN, @speed, @bCorrect, @ECounterIn, @ECounterOut, @ERecupIn, @ERecuOut)

