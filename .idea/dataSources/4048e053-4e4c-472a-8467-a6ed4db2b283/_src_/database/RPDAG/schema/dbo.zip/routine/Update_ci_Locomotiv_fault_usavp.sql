
CREATE PROCEDURE [dbo].[Update_ci_Locomotiv_fault_usavp]
@fault_usavp int,
@loc_id int
as
Update ci_locomotiv
set fault_usavp = @fault_usavp
where loc_id = @loc_id

GRANT exec ON Update_ci_Locomotiv_fault_usavp TO rpdagrole


set ANSI_NULLS OFF
set QUOTED_IDENTIFIER ON
