
-------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Insert_m_Sostav]
@train_id int,
@vag_type_id int,
@ord_num int,
@weight int

as

Insert into m_Sostav (train_id, vag_type_id, ord_num, weight)
Values(@train_id, @vag_type_id, @ord_num, @weight)

