

CREATE PROCEDURE [dbo].[Update_m_TrainsInfo_alsn_nagon]
@alsn_nagon_x int,
@alsn_nagon_time int,
@speedNagon float,
@train_id int

as

update m_trainsinfo
set alsn_nagon_x = @alsn_nagon_x,
alsn_nagon_time = @alsn_nagon_time,
speedNagon = @speedNagon
where train_id = @train_id
