------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Update_ci_Drivers_import]
@surname nvarchar(20),
@name nvarchar(20),
@patronymic nvarchar(20),
@DrvCol int,
@tb_num int,
@n_road int,
@n_tch int

as

Update ci_Drivers
set surname = @surname, name = @name, patronymic = @patronymic, DrvCol = @DrvCol
where tb_num = @tb_num and n_road = @n_road and n_tch = @n_tch

