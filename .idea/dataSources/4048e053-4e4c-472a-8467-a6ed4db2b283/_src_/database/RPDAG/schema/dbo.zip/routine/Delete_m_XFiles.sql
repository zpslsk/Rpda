------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Delete_m_XFiles]
@Id_Image int

as

delete from m_XFiles where Id_Image = @Id_Image

