
/*****************************************************************
-- Автор:	Сираджи Р.Ф.
-- Описание:	Обновляет группу полей в m_TrainsInfo по конкретному поезду
*****************************************************************/
CREATE PROCEDURE [dbo].[sp_FillTrainInfo]
@trainId int

AS

--уд.расход = (Eсчетч.[кВт] * 10000)/(пробег[км] * масса состава[тонны])
--работа = (пробег[км] * масса состава[тонны]) / 1000

declare @Norma float, @DifNorma float, @NormSpec float, @trLength int, @trWork float, @dateTr DateTime, @ss_id int,
@weight float,  @x_Common float, @num_axel int, @axelWeigth float,
@loc_id int, @koefSerLoc float, @koefLoc float, @NormaVt float, @av_speed_move float

select @dateTr = dateTr, @ss_id = ss_id, @weight = weight, @x_Common = x_Common, @loc_id = loc_id, @av_speed_move = av_speed_move
from m_Trains inner join m_TrainsInfo on m_TrainsInfo.train_id = m_Trains.train_id
where m_Trains.train_id = @trainId

select @trLength = sum(length), @num_axel = isNull(sum(num_axel),0)
from m_Sostav inner join ci_VagonType on ci_VagonType.type_id = m_Sostav.vag_type_id
where train_id = @trainId

if @num_axel = 0 set @axelWeigth = 0
else set @axelWeigth = @weight/@num_axel

exec sp_GetNormSpec @dateTr, @ss_id, @axelWeigth, @NormSpec Output

select @koefLoc = L.koefNorma, @koefSerLoc = LT.koefNorma from ci_Locomotiv L inner join ci_LocType LT on LT.type_id = L.loc_type
where loc_id = @loc_id

set @Norma = (@NormSpec * @x_Common * @weight)/10000 * isNull(@koefSerLoc, 1) * isNull(@koefLoc, 1)

select @NormaVt = NormaVt
from ci_NormaVt
where id_NameSS = (select IdNameSS
from ci_ServiceSoulder
where ss_id = @ss_id) and
@dateTr between dtBegin and dtEnd

update m_TrainsInfo set trWork = (@weight * @x_Common)/1000, Norma = @Norma,
DifNorma = case @Norma when 0 then 0  else (DrawMeter - @Norma)/@Norma * 100 end,
DrawSpec = case @x_Common * @weight when 0 then 0 else (DrawMeter * 10000) / (@x_Common * @weight) end,
trLength = @trLength, numAxel = @num_axel, NormaVt = ISNull(@NormaVt, 50),
DifNormaVt = case @av_speed_move when 0 then 0 else (@av_speed_move - NormaVt) / NormaVt * 100 end
where train_id = @trainId
