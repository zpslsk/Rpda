
--------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Insert_ci_Drivers]
@tb_num int,
@surname nvarchar(20),
@name nvarchar(20),
@patronymic nvarchar(20),
@DrvCol int,
@n_road int,
@n_tch int

as

Insert into ci_Drivers (tb_num, surname, name, patronymic, DrvCol, n_road, n_tch)
Values(@tb_num, @surname, @name, @patronymic, @DrvCol, @n_road, @n_tch)


