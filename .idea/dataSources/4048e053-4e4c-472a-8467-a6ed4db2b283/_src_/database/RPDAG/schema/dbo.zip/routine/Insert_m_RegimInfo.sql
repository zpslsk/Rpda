
------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Insert_m_RegimInfo]
@aDate smalldatetime,
@idImage int,
@idTrain int,
@RegimType int,
@x_Regim int,
@t_Regim int,
@ETract float,
@ERecup float

as

Insert into m_RegimInfo(aDate, idImage, idTrain, RegimType, x_Regim, t_Regim, ETract, ERecup)
Values(@aDate, @idImage, @idTrain, @RegimType, @x_Regim, @t_Regim, @ETract, @ERecup)

