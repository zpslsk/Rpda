
/*****************************************************************
-- Автор:	Сираджи Р.Ф. 
-- Описание:	Возвращает статистику по считанным катриджам
*****************************************************************/
CREATE PROCEDURE Rep_CatrijStat 
  @dtStart DateTime, 
  @dtFinish DateTime

AS

  --select @dtStart = '2003-01-01', @dtFinish = '2005-12-01'
  
  CREATE TABLE #T (DataFirstRead Char(10), FError int, FWarning int)

  insert into #T
    select convert(char(10), DataFirstRead, 120) as DataFirstRead, --NumKatr, 
      (select count(*) from z_ReadError where ErrLevel < 100 and idImage = m_XFiles.ID_Image),
      (select count(*) from z_ReadError where ErrLevel >= 100 and idImage = m_XFiles.ID_Image)
    from m_XFiles
    where DataFirstRead between @dtStart and @dtFinish

  select DataFirstRead, count(*) as cnt, sum(FError) as FError, sum(FWarning) as FWarning from #T 
  group by DataFirstRead
  order by DataFirstRead

  DROP TABLE #T

