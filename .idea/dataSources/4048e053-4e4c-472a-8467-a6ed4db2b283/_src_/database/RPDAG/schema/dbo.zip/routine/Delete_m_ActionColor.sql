------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Delete_m_ActionColor]

as

delete from m_ActionColor
where not exists (select *
from m_TrainsInfo ti
where m_ActionColor.train_id = ti.train_id)

