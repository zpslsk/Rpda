-----------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Update_ci_Setup_vminorzro]

as

Update ci_Setup set VersionMinor = 0

