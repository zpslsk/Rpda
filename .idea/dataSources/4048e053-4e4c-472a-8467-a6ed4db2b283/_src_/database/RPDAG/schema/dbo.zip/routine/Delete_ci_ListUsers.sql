------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Delete_ci_ListUsers]
@NameUser char(50),
@NumRoad int,
@NumTch int

as

delete from ci_ListUsers
where NameUser = @NameUser and
NumRoad = @NumRoad and
NumTch = @NumTch

