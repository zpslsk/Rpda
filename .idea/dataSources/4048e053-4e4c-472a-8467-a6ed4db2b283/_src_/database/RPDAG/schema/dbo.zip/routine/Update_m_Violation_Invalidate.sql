----------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Update_m_Violation_Invalidate]
@V_Invalidate bit,
@id int

as

update m_Violation
set V_Invalidate = @V_Invalidate
where id = @id

