-----------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Update_ci_ListUsers]
@NameUserNew char(50),
@NameUser char(50),
@NumRoad int,
@NumTch int

as

update ci_ListUsers
set NameUser = @NameUserNew
where NameUser = @NameUser and
NumRoad = @NumRoad and
NumTch = @NumTch

