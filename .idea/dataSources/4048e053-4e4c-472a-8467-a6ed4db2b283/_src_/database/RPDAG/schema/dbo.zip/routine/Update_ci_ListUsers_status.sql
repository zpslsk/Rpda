--------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Update_ci_ListUsers_status]
@Status bit,
@Id int

as

update ci_ListUsers
set Status = @Status
where Id = @Id

