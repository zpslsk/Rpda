----------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Insert_m_ActionColor]
@train_id int,
@n_color int,
@x_begin float,
@x_end float,
@time_begin int,
@time_end int,
@coord_savpe_begin float,
@coord_savpe_end float,
@km_begin int,
@pk_begin int,
@km_end int,
@pk_end int

as

Insert into m_ActionColor(train_id, n_color,  x_begin, x_end, time_begin, time_end, coord_savpe_begin, coord_savpe_end, km_begin, pk_begin, km_end, pk_end)
Values(@train_id, @n_color,  @x_begin, @x_end, @time_begin, @time_end, @coord_savpe_begin, @coord_savpe_end, @km_begin, @pk_begin, @km_end, @pk_end)

