
--------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Insert_ci_NormaVt]
@id_NameSS  int,
@dtBegin smalldatetime,
@dtEnd smalldatetime,
@NormaVt float

as

insert into ci_NormaVt (id_NameSS, dtBegin, dtEnd, NormaVt)
values (@id_NameSS, @dtBegin, @dtEnd, @NormaVt)
