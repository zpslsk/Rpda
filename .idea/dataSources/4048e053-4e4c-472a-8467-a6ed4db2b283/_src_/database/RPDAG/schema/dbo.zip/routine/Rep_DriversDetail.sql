
CREATE PROCEDURE [dbo].[Rep_DriversDetail]
@nFilter int,
@driv_id int,
@dtStart DateTime,
@dtFinish DateTime,
@TypeTrain int,
@E_Invalidate int,
@IsResidence bit,
@NumRoad int,
@NumTch int,
@IsDateTrains bit

AS

--select @driv_id = 1, @dtStart = '2004-01-01', @dtFinish = '2004-12-01'

Select
m_Trains.train_id, convert(char(16),dateTr,120)as dateTr,
train_num, [type_name], loc_num,
cast(x_Common as decimal(12,3)) as x_Common,

cast(x_SavpeAuto as decimal(12,3)) as x_Auto,
cast(x_SavpeAuto / (x_Common + 0.0001) * 100 as decimal(12,2)) as x_Auto_proc,

cast(x_SavpePrompt as decimal(12,3)) as x_Prompt,
cast(x_SavpePrompt / (x_Common + 0.0001) * 100  as decimal(12,2)) as x_Prompt_proc,

cast(trWork as decimal(15,1)) as trWork, train_time, train_time_move,

cast(DrawMeter as decimal(12,1))as DrawMeter,
cast(DrawMeter_1 as decimal(12,1))as DrawMeter_1,
cast(DrawMeter_2 as decimal(12,1))as DrawMeter_2,
cast(DrawMeter_3 as decimal(12,1))as DrawMeter_3,

cast(RecupMeter as decimal(12,1))as RecupMeter,
cast(RecupMeter_1 as decimal(12,1))as RecupMeter_1,
cast(RecupMeter_2 as decimal(12,1))as RecupMeter_2,
cast(RecupMeter_3 as decimal(12,1))as RecupMeter_3,


cast(EBack + EBack_2 + EBack_3 as decimal(12,1))as EBack,
cast(ERBack + ERBack_2 + ERBack_3 as decimal(12,1))as ERBack,
cast(EBack as decimal(12,1))as EBack_1,
cast(ERBack as decimal(12,1))as ERBack_1,
cast(EBack_2 as decimal(12,1))as EBack_2,
cast(ERBack_2 as decimal(12,1))as ERBack_2,
cast(EBack_3 as decimal(12,1))as EBack_3,
cast(ERBack_3 as decimal(12,1))as ERBack_3,

-- тепловозы ***********************************************
cast (FuelConsumpWeight1 + FuelConsumpWeight2 + FuelConsumpWeight3 + FuelConsumpWeight4 as decimal(12,1))as FuelConsumpWeightSum,
cast (FuelConsumpWeight1 as decimal(12,1))as FuelConsumpWeight1,
cast (FuelConsumpWeight2 as decimal(12,1))as FuelConsumpWeight2,
cast (FuelConsumpWeight3 as decimal(12,1))as FuelConsumpWeight3,
cast (FuelConsumpWeight4 as decimal(12,1))as FuelConsumpWeight4,

cast (FuelConsumpWeightCalc1 + FuelConsumpWeightCalc2 + FuelConsumpWeightCalc3 + FuelConsumpWeightCalc4 as decimal(12,1))as FuelConsumpWeightCalcSum,
cast (FuelConsumpWeightCalc1 as decimal(12,1))as FuelConsumpWeightCalc1,
cast (FuelConsumpWeightCalc2 as decimal(12,1))as FuelConsumpWeightCalc2,
cast (FuelConsumpWeightCalc3 as decimal(12,1))as FuelConsumpWeightCalc3,
cast (FuelConsumpWeightCalc4 as decimal(12,1))as FuelConsumpWeightCalc4,

cast (ReFuelWeight1 + ReFuelWeight2 + ReFuelWeight3 + ReFuelWeight4 as decimal(12,1))as ReFuelWeightSum,
cast (ReFuelWeight1 as decimal(12,1))as ReFuelWeight1,
cast (ReFuelWeight2 as decimal(12,1))as ReFuelWeight2,
cast (ReFuelWeight3 as decimal(12,1))as ReFuelWeight3,
cast (ReFuelWeight4 as decimal(12,1))as ReFuelWeight4,

cast (ReFuelCount1 as decimal(12,1))as ReFuelCount1,
cast (ReFuelCount2 as decimal(12,1))as ReFuelCount2,
cast (ReFuelCount3 as decimal(12,1))as ReFuelCount3,
cast (ReFuelCount4 as decimal(12,1))as ReFuelCount4,
EnTep1, EnTep2, EnTep3, EnTep4,
RpmStopTep1, RpmStopTep2, RpmStopTep3, RpmStopTep4,
RpmXXTep1, RpmXXTep2, RpmXXTep3, RpmXXTep4,

-- ***********************************************

cast(Norma as decimal(12,1)) as Norma,
cast(DifNorma as decimal(12,2)) as DifNorma,
cast(av_speed AS decimal(12,2))as av_speed,
cast(av_speed_move AS decimal(12,2))as av_speed_move,
countTLim,
ci_Drivers.surname + ' ' + Left(ci_Drivers.name,1) + ' ' + Left(ci_Drivers.patronymic,1) as FIO,
ci_Drivers.tb_num, Weight, VagsCount, ss_Name, E_Invalidate,
cast(NormaVt as decimal(12,1))as NormaVt,
cast(DifNormaVt as decimal(12,2))as DifNormaVt,
ci_Roads.name_road, num_tch -- ******************

from
m_Trains inner join m_TrainsInfo on m_TrainsInfo.train_id = m_Trains.train_id
inner join ci_Drivers on ci_Drivers.drv_id = m_Trains.drv_id
inner join m_XFiles on m_XFiles.id_image = m_Trains.image_id
inner join ci_Roads on ci_Roads.num_road = m_Trains.num_road -- ***************
left join ci_Locomotiv on ci_Locomotiv.loc_id = m_TrainsInfo.loc_id
left join ci_LocType on ci_LocType.type_id = ci_Locomotiv.loc_type
left join Rep_Filter R1 on R1.nFilter = @nFilter and R1.FCode = 1 and ci_Locomotiv.loc_id = R1.FValue
left join ci_ServiceSoulder on ci_ServiceSoulder.ss_id = m_Trains.ss_id
where
m_Trains.drv_id = @driv_id and

(
(dateTr between @dtStart and @dtFinish and @IsDateTrains > 0) or
(DataLastRead between @dtStart and @dtFinish and @IsDateTrains = 0)
) and

R1.FValue is NULL and
--ci_Locomotiv.loc_type = @TypeTrain
( ------- объединение тепловозных  ---------
--((ci_Locomotiv.loc_type =  @TypeTrain) and (ci_Locomotiv.loc_type < 5)) or
--((@TypeTrain >= 5) and (ci_Locomotiv.loc_type >= 5) )
--)

--((ci_Locomotiv.loc_type =  @TypeTrain) and ((ci_Locomotiv.loc_type < 5) or (ci_Locomotiv.loc_type > 14))) or
--(((@TypeTrain >= 5) and (@TypeTrain <= 14)) and ((ci_Locomotiv.loc_type >= 5) and (ci_Locomotiv.loc_type <= 14)) )
--)

((ci_Locomotiv.loc_type =  @TypeTrain) and (ci_Locomotiv.loc_type in (1, 2, 3, 4, 15, 16, 35, 36, 37))) or
( (@TypeTrain in (5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 38)) and
(ci_Locomotiv.loc_type in (5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 38))  )
)

and ((@E_Invalidate = -1) or (E_Invalidate = @E_Invalidate))
and ((Residence = @IsResidence) or (@IsResidence = 0))
and ((@NumRoad = 0) or (m_Trains.num_road = @NumRoad))
and ((@NumTch = 0) or (num_tch = @NumTch))
order by
dateTr
