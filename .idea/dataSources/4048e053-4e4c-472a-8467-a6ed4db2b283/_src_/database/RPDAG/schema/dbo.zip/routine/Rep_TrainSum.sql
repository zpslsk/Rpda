
CREATE PROCEDURE [dbo].[Rep_TrainSum]
@nFilter int,
@dtStart DateTime,
@dtFinish DateTime,
@TypeTrain int,
@E_Invalidate int,
@IsResidence bit,
@NumRoad int,
@NumTch int,
@IsDateTrains bit

AS

--select @nFilter = -1, @dtStart = '2004-01-01', @dtFinish = '2004-12-01'

Select train_num, count(*)as cnt,
cast(sum(x_Common) as decimal(12,3)) as x_Common,
cast(sum(x_SavpeAuto) as decimal(12,3)) as x_Auto,	cast(sum(x_SavpePrompt)as decimal(12,3)) as x_Prompt,
cast(sum(trWork)as decimal(15,1)) as trWork,
sum(train_time) as train_time,
sum(train_time_move) as train_time_move,

cast(sum(DrawMeter)as decimal(12,1))as DrawMeter,
cast(sum(RecupMeter)as decimal(12,1))as RecupMeter,
cast(sum(EBack)as decimal(12,1))as EBack,
cast(sum(ERBack)as decimal(12,1))as ERBack,

-- тепловозы ***********************************************
cast(sum(FuelConsumpWeight1 + FuelConsumpWeight2 + FuelConsumpWeight3 + FuelConsumpWeight4) as decimal(12,1))as FuelConsumpWeightSum,
cast(sum(FuelConsumpWeight1)as decimal(12,1))as FuelConsumpWeight1,
cast(sum(FuelConsumpWeight2)as decimal(12,1))as FuelConsumpWeight2,
cast(sum(FuelConsumpWeight3)as decimal(12,1))as FuelConsumpWeight3,
cast(sum(FuelConsumpWeight4)as decimal(12,1))as FuelConsumpWeight4,

cast(sum(FuelConsumpWeightCalc1 + FuelConsumpWeightCalc2 + FuelConsumpWeightCalc3 + FuelConsumpWeightCalc4) as decimal(12,1))as FuelConsumpWeightCalcSum,
cast(sum(FuelConsumpWeightCalc1)as decimal(12,1))as FuelConsumpWeightCalc1,
cast(sum(FuelConsumpWeightCalc2)as decimal(12,1))as FuelConsumpWeightCalc2,
cast(sum(FuelConsumpWeightCalc3)as decimal(12,1))as FuelConsumpWeightCalc3,
cast(sum(FuelConsumpWeightCalc4)as decimal(12,1))as FuelConsumpWeightCalc4,

cast(sum(ReFuelWeight1 + ReFuelWeight2 + ReFuelWeight3 + ReFuelWeight4) as decimal(12,1))as ReFuelWeightSum,
cast(sum(ReFuelWeight1)as decimal(12,1))as ReFuelWeight1,
cast(sum(ReFuelWeight2)as decimal(12,1))as ReFuelWeight2,
cast(sum(ReFuelWeight3)as decimal(12,1))as ReFuelWeight3,
cast(sum(ReFuelWeight4)as decimal(12,1))as ReFuelWeight4,

cast(sum(ReFuelCount1)as decimal(12,1))as ReFuelCount1,
cast(sum(ReFuelCount2)as decimal(12,1))as ReFuelCount2,
cast(sum(ReFuelCount3)as decimal(12,1))as ReFuelCount3,
cast(sum(ReFuelCount4)as decimal(12,1))as ReFuelCount4,
-- ***********************************************

cast(avg(av_speed)AS decimal(12,2))as av_speed,
cast(avg(av_speed_move)AS decimal(12,2))as av_speed_move,
sum(countTLim) as countTLim,

sum(alsn_green_x) as alsn_green_x,
sum(alsn_yellow_x) as alsn_yellow_x,
sum(alsn_redyellow_x) as alsn_redyellow_x,
sum(alsn_red_x) as alsn_red_x,
sum(alsn_white_x) as alsn_white_x,
sum(alsn_gray_x) as alsn_gray_x,
sum(alsn_nagon_x) as alsn_nagon_x,

sum(alsn_green_time) as alsn_green_time,
sum(alsn_yellow_time) as alsn_yellow_time,
sum(alsn_redyellow_time) as alsn_redyellow_time,
sum(alsn_red_time) as alsn_red_time,
sum(alsn_white_time) as alsn_white_time,
sum(alsn_gray_time) as alsn_gray_time,
sum(alsn_nagon_time) as alsn_nagon_time

from m_Trains a
inner join m_TrainsInfo b on b.train_id = a.train_id
inner join m_XFiles on m_XFiles.id_image = a.image_id
left join ci_Locomotiv loc on loc.loc_id = b.loc_id
left join Rep_Filter R1 on R1.nFilter = @nFilter and R1.FCode = 2 and b.loc_id = R1.FValue
left join Rep_Filter R2 on R2.nFilter = @nFilter and R2.FCode = 3 and drv_id = R2.FValue
where

(
(dateTr between @dtStart and @dtFinish and @IsDateTrains > 0) or
(DataLastRead between @dtStart and @dtFinish and @IsDateTrains = 0)
) and

R1.FValue is NULL and R2.FValue is NULL and
( ------- объединение тепловозных  ---------
--((loc.loc_type =  @TypeTrain) and (loc.loc_type < 5)) or
--((@TypeTrain >= 5) and (loc.loc_type >= 5) )
--) and

--((loc.loc_type =  @TypeTrain) and ((loc.loc_type < 5) or (loc.loc_type > 14))) or
--(((@TypeTrain >= 5) and (@TypeTrain <= 14)) and ((loc.loc_type >= 5) and (loc.loc_type <= 14)) )
--) and

((loc.loc_type =  @TypeTrain) and (loc.loc_type in (1, 2, 3, 4, 15, 16, 35, 36, 37))) or
( (@TypeTrain in (5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 38)) and
(loc.loc_type in (5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 38))  )
) and

((@E_Invalidate = -1) or (E_Invalidate = @E_Invalidate)) and
((Residence = @IsResidence) or (@IsResidence = 0)) and
((@NumRoad = 0) or (num_road = @NumRoad)) and
((@NumTch = 0) or (num_tch = @NumTch))
group by train_num
order by train_num
