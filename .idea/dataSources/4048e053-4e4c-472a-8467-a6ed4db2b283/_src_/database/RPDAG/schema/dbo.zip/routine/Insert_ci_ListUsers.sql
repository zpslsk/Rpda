
---------------------------------------------------
CREATE PROCEDURE [dbo].[Insert_ci_ListUsers]
@NameUser char(50),
@NumRoad int,
@NumTch int

as

insert into ci_ListUsers (NameUser, NumRoad, NumTch)
values (@NameUser, @NumRoad, @NumTch)

