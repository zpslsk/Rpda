------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Update_ci_VagonType]
@type_code int,
@eks_code int,
@type_name nvarchar (50),
@weight float,
@length float,
@num_axel int,
@type_id int

as

Update ci_VagonType set type_code = @type_code, eks_code = @eks_code, type_name = @type_name, weight = @weight, length = @length, num_axel = @num_axel
where type_id = @type_id

