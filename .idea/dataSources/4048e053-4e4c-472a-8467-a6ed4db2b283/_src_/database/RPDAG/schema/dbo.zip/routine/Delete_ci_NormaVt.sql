------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Delete_ci_NormaVt]
@id int

as

delete from ci_NormaVt where id = @id

