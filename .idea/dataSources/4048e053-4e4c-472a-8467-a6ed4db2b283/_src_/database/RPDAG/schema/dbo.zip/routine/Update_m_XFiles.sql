----------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Update_m_XFiles]
@ID_Map int,
@NumKatr int,
@DataLastRead datetime,
@ID_Image int

as

Update m_XFiles set ID_Map = @ID_Map, NumKatr = @NumKatr, DataLastRead = @DataLastRead
where ID_Image = @ID_Image

