
-----------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Insert_ci_SSByMap]
@ss_id int,
@map_id int,
@WD int,
@nRoute int,
@ss_name char(60)

as

Insert into ci_SSByMap (ss_id, map_id, WD, nRoute, ss_name)
Values(@ss_id, @map_id, @WD, @nRoute, @ss_name)

