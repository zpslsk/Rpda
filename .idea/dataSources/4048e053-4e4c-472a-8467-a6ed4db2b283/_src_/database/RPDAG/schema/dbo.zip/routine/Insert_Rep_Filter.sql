


CREATE PROCEDURE [dbo].[Insert_Rep_Filter]
@nFilter int,
@FCode int,
@FValue int

as

Insert into Rep_Filter
Values(@nFilter, @FCode, @FValue)

