
CREATE PROCEDURE [dbo].[Rep_DriversSumGrCol]
@nFilter int,
@dtStart DateTime,
@dtFinish DateTime,
@TypeTrain int,
@nDrvCol int,
@E_Invalidate int,
@IsResidence bit,
@NumRoad int,
@NumTch int,
@IsDateTrains bit


AS

--select @dtStart = '2004-01-01', @dtFinish = '2004-12-01'

Select
0 as drv_id,
'' as FIO,
0 as tb_num,
count(*) as cnt,
cast(sum(x_Common) as decimal(12,3)) as x_Common,

cast(sum(x_SavpeAuto) as decimal(12,3)) as x_Auto,
cast(sum(x_SavpeAuto) / (sum(x_Common) + 0.0001) * 100 as decimal(12,2)) as x_Auto_proc,
cast(sum(x_SavpePrompt)as decimal(12,3)) as x_Prompt,
cast(sum(x_SavpePrompt) / (sum(x_Common) + 0.0001) * 100 as decimal(12,2)) as x_Prompt_proc,

cast(sum(trWork) as decimal(15,1)) as trWork,
sum(train_time) as train_time,
sum(train_time_move) as train_time_move,

cast(sum(DrawMeter) as decimal(12,1))as DrawMeter,
cast(sum(DrawMeter_1) as decimal(12,1))as DrawMeter_1,
cast(sum(DrawMeter_2) as decimal(12,1))as DrawMeter_2,

cast(sum(RecupMeter) as decimal(12,1))as RecupMeter,
cast(sum(RecupMeter_1) as decimal(12,1))as RecupMeter_1,
cast(sum(RecupMeter_2) as decimal(12,1))as RecupMeter_2,

cast(sum(EBack) as decimal(12,1))as EBack,
cast(sum(ERBack) as decimal(12,1))as ERBack,

-- тепловозы ***********************************************
cast(sum(FuelConsumpWeight1 + FuelConsumpWeight2 + FuelConsumpWeight3 + FuelConsumpWeight4) as decimal(12,1))as FuelConsumpWeightSum,
cast(sum(FuelConsumpWeight1)as decimal(12,1))as FuelConsumpWeight1,
cast(sum(FuelConsumpWeight2)as decimal(12,1))as FuelConsumpWeight2,
cast(sum(FuelConsumpWeight3)as decimal(12,1))as FuelConsumpWeight3,
cast(sum(FuelConsumpWeight4)as decimal(12,1))as FuelConsumpWeight4,

cast(sum(FuelConsumpWeightCalc1 + FuelConsumpWeightCalc2 + FuelConsumpWeightCalc3 + FuelConsumpWeightCalc4) as decimal(12,1))as FuelConsumpWeightCalcSum,
cast(sum(FuelConsumpWeightCalc1)as decimal(12,1))as FuelConsumpWeightCalc1,
cast(sum(FuelConsumpWeightCalc2)as decimal(12,1))as FuelConsumpWeightCalc2,
cast(sum(FuelConsumpWeightCalc3)as decimal(12,1))as FuelConsumpWeightCalc3,
cast(sum(FuelConsumpWeightCalc4)as decimal(12,1))as FuelConsumpWeightCalc4,

cast(sum(ReFuelWeight1 + ReFuelWeight2 + ReFuelWeight3 + ReFuelWeight4) as decimal(12,1))as ReFuelWeightSum,
cast(sum(ReFuelWeight1)as decimal(12,1))as ReFuelWeight1,
cast(sum(ReFuelWeight2)as decimal(12,1))as ReFuelWeight2,
cast(sum(ReFuelWeight3)as decimal(12,1))as ReFuelWeight3,
cast(sum(ReFuelWeight4)as decimal(12,1))as ReFuelWeight4,

cast(sum(ReFuelCount1)as decimal(12,1))as ReFuelCount1,
cast(sum(ReFuelCount2)as decimal(12,1))as ReFuelCount2,
cast(sum(ReFuelCount3)as decimal(12,1))as ReFuelCount3,
cast(sum(ReFuelCount4)as decimal(12,1))as ReFuelCount4,
-- ***********************************************

cast(sum(Norma) as decimal(12,1)) as Norma,

(case sum(Norma) when 0 then 0 else
cast((sum(DrawMeter)-sum(Norma))/sum(Norma)*100 as decimal(12,1)) end) as DifNorma,

cast(avg(av_speed) AS decimal(12,2))as av_speed,
cast(avg(av_speed_move) AS decimal(12,2))as av_speed_move,
sum(countTLim) as countTLim,
ci_Drivers.DrvCol,
cast(avg(NormaVt) as decimal(12,1))as NormaVt,
cast(avg(DifNormaVt) as decimal(12,2))as DifNormaVt
from
m_Trains inner join m_TrainsInfo on m_TrainsInfo.train_id = m_Trains.train_id
inner join ci_Drivers on ci_Drivers.drv_id = m_Trains.drv_id
inner join m_XFiles on m_XFiles.id_image = m_Trains.image_id
left join ci_Locomotiv on ci_Locomotiv.loc_id = m_TrainsInfo.loc_id
left join ci_LocType on ci_LocType.type_id = ci_Locomotiv.loc_type
left join Rep_Filter R1 on R1.nFilter = @nFilter and R1.FCode = 1 and ci_Locomotiv.loc_id = R1.FValue
left join Rep_Filter R2 on R2.nFilter = @nFilter and R2.FCode = 2 and ci_Drivers.drv_id = R2.FValue
where

(
(dateTr between @dtStart and @dtFinish and @IsDateTrains > 0) or
(DataLastRead between @dtStart and @dtFinish and @IsDateTrains = 0)
) and

R1.FValue is NULL and R2.FValue is NULL and
--ci_Locomotiv.loc_type =  @TypeTrain and
( ------- объединение тепловозных  ---------
--((ci_Locomotiv.loc_type =  @TypeTrain) and (ci_Locomotiv.loc_type < 5)) or
--((@TypeTrain >= 5) and (ci_Locomotiv.loc_type >= 5) )
--) and

((ci_Locomotiv.loc_type =  @TypeTrain) and ((ci_Locomotiv.loc_type < 5) or (ci_Locomotiv.loc_type > 14))) or
(((@TypeTrain >= 5) and (@TypeTrain <= 14)) and ((ci_Locomotiv.loc_type >= 5) and (ci_Locomotiv.loc_type <= 14)) )
) and

((ci_Drivers.DrvCol = @nDrvCol) or (1000 = @nDrvCol)) and
((@E_Invalidate = -1) or (E_Invalidate = @E_Invalidate)) and
((Residence = @IsResidence) or (@IsResidence = 0)) and
((@NumRoad = 0) or (num_road = @NumRoad)) and
((@NumTch = 0) or (num_tch = @NumTch))
group by
ci_Drivers.DrvCol
order by
ci_Drivers.DrvCol
