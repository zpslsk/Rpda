-------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Update_ci_NormaSS]
@dtBegin smalldatetime,
@dtEnd smalldatetime,
@id int

as

update ci_NormaSS set dtBegin = @dtBegin, dtEnd = @dtEnd where id = @id

