-------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Insert_m_Violation]
@v_id int,
@tr_id int,
@kmBegin int,
@pkBegin int,
@kmEnd int,
@pkEnd int,
@dtBegin datetime,
@dtEnd datetime,
@xLen int,
@tLen int,
@aValue1 float,
@aValue2 float,
@aValue3 float,
@aValue4 float,
@aValue5 float,
@aValue6 float,
@aValue7 nvarchar(35),
@GoAuto bit

as

Insert into m_Violation(v_id, tr_id, kmBegin, pkBegin, kmEnd, pkEnd, dtBegin, dtEnd, xLen, tLen, aValue1, aValue2, aValue3, aValue4, aValue5, aValue6, aValue7, GoAuto)
Values(@v_id, @tr_id, @kmBegin, @pkBegin, @kmEnd, @pkEnd, @dtBegin, @dtEnd, @xLen, @tLen, @aValue1, @aValue2, @aValue3, @aValue4, @aValue5, @aValue6, @aValue7, @GoAuto)

