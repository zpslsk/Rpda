----------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Update_m_Trains_train_num]
@train_num int,
@train_id int

as

update m_trains
set train_num = @train_num
where train_id = @train_id

