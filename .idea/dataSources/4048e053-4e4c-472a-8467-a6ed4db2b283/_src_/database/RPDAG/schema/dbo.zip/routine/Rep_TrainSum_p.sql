

CREATE PROCEDURE [dbo].[Rep_TrainSum_p]
@nFilter int,
@dtStart DateTime,
@dtFinish DateTime,
@TypeTrain int,
@E_Invalidate int,
@IsResidence bit,
@NumRoad int,
@NumTch int,
@IsDateTrains bit

AS

--select @nFilter = -1, @dtStart = '2004-01-01', @dtFinish = '2004-12-01'

Select NameSS, count(DISTINCT(b.train_id)) as cnt,
cast(sum(DISTINCT(x_Common)) as decimal(12,3)) as x_Common,
cast(sum(DISTINCT(x_SavpeAuto)) as decimal(12,3)) as x_Auto,	cast(sum(x_SavpePrompt)as decimal(12,3)) as x_Prompt,
cast(sum(DISTINCT(trWork))as decimal(15,1)) as trWork,
sum(DISTINCT(train_time)) as train_time,

cast(sum(DISTINCT(DrawMeter))as decimal(12,1))as DrawMeter,
cast(sum(DISTINCT(RecupMeter))as decimal(12,1))as RecupMeter,
cast(sum(DISTINCT(EBack))as decimal(12,1))as EBack,
cast(sum(DISTINCT(ERBack))as decimal(12,1))as ERBack,

cast(avg(DISTINCT(av_speed))AS decimal(12,2))as av_speed,
cast(avg(DISTINCT(av_speed_move))AS decimal(12,2))as av_speed_move,
sum(DISTINCT(countTLim)) as countTLim,/*, a.ss_id*/

sum(DISTINCT(alsn_green_x)) as alsn_green_x,
sum(DISTINCT(alsn_yellow_x)) as alsn_yellow_x,
sum(DISTINCT(alsn_redyellow_x)) as alsn_redyellow_x,
sum(DISTINCT(alsn_red_x)) as alsn_red_x,
sum(DISTINCT(alsn_white_x)) as alsn_white_x,
sum(DISTINCT(alsn_gray_x)) as alsn_gray_x,
sum(DISTINCT(alsn_nagon_x)) as alsn_nagon_x,


sum(DISTINCT(alsn_green_time)) as alsn_green_time,
sum(DISTINCT(alsn_yellow_time)) as alsn_yellow_time,
sum(DISTINCT(alsn_redyellow_time)) as alsn_redyellow_time,
sum(DISTINCT(alsn_red_time)) as alsn_red_time,
sum(DISTINCT(alsn_white_time)) as alsn_white_time,
sum(DISTINCT(alsn_gray_time)) as alsn_gray_time,
sum(DISTINCT(alsn_nagon_time)) as alsn_nagon_time

from m_Trains a
inner join m_TrainsInfo b on b.train_id = a.train_id
inner join m_XFiles on m_XFiles.id_image = a.image_id
left join ci_Locomotiv loc on loc.loc_id = b.loc_id
inner join ci_ServiceSoulder on ci_ServiceSoulder.ss_id = a.ss_id
left join ci_NameSS nss on ci_ServiceSoulder.ss_Name = nss.NameSS
--left join Rep_Filter R1 on R1.nFilter = @nFilter and R1.FCode = 2 and b.loc_id = R1.FValue
--left join Rep_Filter R2 on R2.nFilter = @nFilter and R2.FCode = 3 and drv_id = R2.FValue
where

(
(dateTr between @dtStart and @dtFinish and @IsDateTrains > 0) or
(DataLastRead between @dtStart and @dtFinish and @IsDateTrains = 0)
) and

--R1.FValue is NULL and R2.FValue is NULL and
loc.loc_type =  @TypeTrain and
((@E_Invalidate = -1) or (E_Invalidate = @E_Invalidate)) and
((Residence = @IsResidence) or (@IsResidence = 0)) and
((@NumRoad = 0) or (num_road = @NumRoad)) and
((@NumTch = 0) or (num_tch = @NumTch))
group by NameSS
order by NameSS
