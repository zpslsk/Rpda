
------------------------------------------------
CREATE PROCEDURE [dbo].[Insert_ci_Setup]
@RoadName char(50),
@RoadCode char(10),
@DepoName char(50),
@DepoTCH char(10)

as

Insert into ci_Setup (RoadName, RoadCode, DepoName, DepoTCH)
Values(@RoadName, @RoadCode , @DepoName , @DepoTCH )

