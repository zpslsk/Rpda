------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Delete_Locomotiv]
@loc_num char(20),
@loc_type int

as

delete from ci_Loc_Section
where loc_id = (select loc.loc_id
from ci_Locomotiv loc
where loc.loc_num = @loc_num and
loc.loc_type = @loc_type)

delete from ci_Locomotiv
where loc_num = @loc_num and
loc_type = @loc_type

delete from ci_Section
where loc_num = @loc_num and
type_id = @loc_type

