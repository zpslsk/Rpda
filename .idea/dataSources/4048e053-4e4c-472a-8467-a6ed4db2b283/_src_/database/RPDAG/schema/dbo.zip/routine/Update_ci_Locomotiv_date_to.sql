
CREATE PROCEDURE [dbo].[Update_ci_Locomotiv_date_to]
@date_to datetime,
@loc_id int
as
Update ci_locomotiv
set date_to = @date_to
where loc_id = @loc_id
