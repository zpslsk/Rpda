
CREATE PROCEDURE [dbo].[Rep_TrainDetail_p]
@nFilter int,
--@id_ss int,
@Name_ss char(50),
@dtStart DateTime,
@dtFinish DateTime,
@TypeTrain int,
@E_Invalidate int,
@IsResidence bit,
@NumRoad int,
@NumTch int,
@IsDateTrains bit

AS

--select @train_num = 1901, @dtStart = '2004-01-01', @dtFinish = '2004-12-01'

set @TypeTrain = @TypeTrain & 255;

Select m_Trains.train_id,  nKar,
convert(char(16),dateTr,120)as dateTr,
tb_num, RTRIM(surname) + ' ' + Left([name],1) + ' ' + Left(patronymic,1) as FIO,
[type_name], loc_num,
cast(x_Common as decimal(12,3)) as x_Common, cast(x_SavpeAuto as decimal(12,3)) as x_Auto,
cast(x_SavpePrompt as decimal(12,3)) as x_Prompt,
cast(trWork / 10 as decimal(15,1)) as trWork, train_time,

cast(DrawMeter as decimal(12,1))as DrawMeter,
cast(DrawMeter_1 as decimal(12,1))as DrawMeter_1,
cast(DrawMeter_2 as decimal(12,1))as DrawMeter_2,
cast(DrawMeter_3 as decimal(12,1))as DrawMeter_3,
cast(RecupMeter as decimal(12,1))as RecupMeter,
cast(RecupMeter_1 as decimal(12,1))as RecupMeter_1,
cast(RecupMeter_2 as decimal(12,1))as RecupMeter_2,
cast(RecupMeter_3 as decimal(12,1))as RecupMeter_3,

cast(EBack + EBack_2 + EBack_3 as decimal(12,1))as EBack,
cast(ERBack + ERBack_2 + ERBack_3 as decimal(12,1))as ERBack,
cast(EBack as decimal(12,1))as EBack_1,
cast(ERBack as decimal(12,1))as ERBack_1,
cast(EBack_2 as decimal(12,1))as EBack_2,
cast(ERBack_2 as decimal(12,1))as ERBack_2,
cast(EBack_3 as decimal(12,1))as EBack_3,
cast(ERBack_3 as decimal(12,1))as ERBack_3,

cast(Norma  as decimal(12,1))as Norma, cast(DifNorma as decimal(12,2))as DifNorma,
cast(av_speed AS decimal(12,2))as av_speed, cast(av_speed_move AS decimal(12,2))as av_speed_move,
countTLim, LenGthTLim / 1000 as LenGthTLim,

Weight, VagsCount,
CountEmpty as EmptyCnt,
train_num, ss_Name, stName, E_Invalidate,
cast(NormaVt as decimal(12,1))as NormaVt, cast(DifNormaVt as decimal(12,2))as DifNormaVt,
right(m_XFiles.FileName, PATINDEX('%\%', REVERSE(m_XFiles.FileName))) as FileName,
alsn_green_x, alsn_yellow_x, alsn_redyellow_x, alsn_red_x, alsn_white_x, alsn_gray_x, alsn_nagon_x,
alsn_green_time, alsn_yellow_time, alsn_redyellow_time, alsn_red_time, alsn_white_time, alsn_gray_time, alsn_nagon_time,
cast(m_RegimInfo.ERecup as decimal(12,1))as RecupMeter_auto,   ----------------------------------------------------
convert(char(16), m_XFiles.DataFirstRead ,120)as DateFirstRead,
ci_Roads.name_road, num_tch, verpo, datemap, isavprt_status, -- ******************
alsn_green_count, alsn_yellow_count, alsn_redyellow_count, alsn_red_count, alsn_white_count, alsn_gray_count, speedNagon, speedMap, speedMapT

from m_Trains
inner join m_XFiles on m_XFiles.id_image = m_Trains.image_id
inner join m_TrainsInfo on m_TrainsInfo.train_id = m_Trains.train_id
inner join ci_Drivers on ci_Drivers.drv_id = m_Trains.drv_id
inner join ci_Roads on ci_Roads.num_road = m_Trains.num_road -- ***************
left join m_RegimInfo on m_RegimInfo.IdTrain = m_Trains.train_id  and m_RegimInfo.RegimType = 2 -------------------------------------------------------
left join ci_Locomotiv on ci_Locomotiv.loc_id = m_TrainsInfo.loc_id
left join ci_LocType on ci_LocType.type_id = ci_Locomotiv.loc_type
left join ci_ServiceSoulder on ci_ServiceSoulder.ss_id = m_Trains.ss_id
left join Rep_Filter R1 on R1.nFilter = @nFilter and R1.FCode = 1 and ci_Locomotiv.loc_id = R1.FValue
left join Rep_Filter R2 on R2.nFilter = @nFilter and R2.FCode = 2 and ci_Drivers.drv_id = R2.FValue
where -- ((ci_ServiceSoulder.ss_Name = @Name_ss) or ((@Name_ss = '') and (ss_Name is null) ) ) and
ci_ServiceSoulder.ss_Name = @Name_ss and

(
(dateTr between @dtStart and @dtFinish and @IsDateTrains > 0) or
(DataLastRead between @dtStart and @dtFinish and @IsDateTrains = 0)
) and

R1.FValue is NULL and R2.FValue is NULL and
ci_Locomotiv.loc_type = @TypeTrain and
((@E_Invalidate = -1) or (E_Invalidate = @E_Invalidate)) and
((Residence = @IsResidence) or (@IsResidence = 0)) and
((@NumRoad = 0) or (m_Trains.num_road = @NumRoad)) and
((@NumTch = 0) or (num_tch = @NumTch))
order by dateTr
