
--------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Insert_m_Limits]
@train_id int,
@Speed float,
@FlagConstant bit,
@x_begin int,
@x_end int

as

insert into m_Limits (train_id, Speed, FlagConstant, x_begin, x_end)
values (@train_id, @Speed, @FlagConstant, @x_begin, @x_end)

