
----------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Insert_ci_Section]
@type_id int,
@loc_num int,
@sec_num char

as

Insert into ci_Section (type_id, loc_num, sec_num)
Values(@type_id, @loc_num, @sec_num)

