----------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Insert_m_CountEnergy]
@id_Train int,
@ECountMeter numeric(18, 0),
@ECountRecup numeric(18, 0),
@ECountAct2 numeric(18, 0),
@ECountReact2 numeric(18, 0),
@xCoord int,
@tCoord int,
@km int,
@pk int,
@CoordSavpe int,
@ILoc int,
@ULoc int

as

Insert into m_CountEnergy(id_Train, ECountMeter, ECountRecup, ECountAct2, ECountReact2, xCoord, tCoord, km, pk, CoordSavpe, ILoc, ULoc)
Values(@id_Train, @ECountMeter, @ECountRecup, @ECountAct2, @ECountReact2, @xCoord, @tCoord, @km, @pk, @CoordSavpe, @ILoc, @ULoc)
