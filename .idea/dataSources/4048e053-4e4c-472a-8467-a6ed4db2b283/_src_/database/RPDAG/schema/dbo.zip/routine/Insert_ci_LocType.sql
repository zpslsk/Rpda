-----------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Insert_ci_LocType]
@type_code int,
@eks_code int,
@type_name nvarchar(15),
@koefNorma float

as

Insert into ci_LocType (type_code, eks_code, type_name, koefNorma)
Values(@type_code, @eks_code, @type_name, @koefNorma)

