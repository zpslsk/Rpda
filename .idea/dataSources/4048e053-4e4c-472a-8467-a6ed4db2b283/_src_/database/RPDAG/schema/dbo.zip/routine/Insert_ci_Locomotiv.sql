
---------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Insert_ci_Locomotiv]
@loc_type int,
@sec_count int,
@loc_num char(20),
@koefNorma float

as

Insert into ci_Locomotiv (loc_type, sec_count, loc_num, koefNorma)
Values(@loc_type, @sec_count, @loc_num, @koefNorma)

