

CREATE PROCEDURE [dbo].[sp_GetDriverId]
@tab_num Integer,
@num_road Integer,
@num_tch Integer

AS
declare @drv_id int
set nocount on

select @drv_id = drv_id
from ci_Drivers
where tb_num = @tab_num and
n_road = @num_road and
n_tch = @num_tch

if @drv_id is Null begin
insert into ci_Drivers (tb_num, surname, [name], patronymic, n_road, n_tch)
Values(@tab_num, 'Таб.номер - '+ltrim(str(@tab_num)), '', '', @num_road, @num_tch)
select @@IDENTITY
end
else
select @drv_id
