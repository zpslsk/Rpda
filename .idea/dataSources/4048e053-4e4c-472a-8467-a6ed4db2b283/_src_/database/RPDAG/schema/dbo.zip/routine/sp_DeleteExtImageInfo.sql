
CREATE PROCEDURE sp_DeleteExtImageInfo
@idImage int

as

if exists(select idImage from z_ReadError where idImage = @idImage)
delete from z_ReadError where idImage = @idImage

if exists(select idImage from m_RegimInfo where idImage = @idImage)
delete from m_RegimInfo where idImage = @idImage

