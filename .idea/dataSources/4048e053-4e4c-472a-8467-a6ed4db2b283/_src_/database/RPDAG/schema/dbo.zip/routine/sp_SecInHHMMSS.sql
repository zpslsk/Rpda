
/*****************************************************************
-- Автор:	Сираджи Р.Ф. 
-- Описание:	переводит время в секундах (@timeIn) в формат чч:мм:сс
*****************************************************************/
CREATE PROCEDURE sp_SecInHHMMSS  
  @timeIn float, 
  @timeOut varchar(20) output

AS

declare  @nHour int, @nMin int, @nSec int, @cMin char(2), @cSec char(2)

--select @timeIn = 383325.0
if @timeIn < 1 set @timeOut = '00:00:00'
else begin
  set @nHour = @timeIn/3600
  set @nMin = (@timeIn - @nHour *3600)/60
  set @nSec = @timeIn - @nHour *3600 - @nMin * 60
  if @nHour < 10 set @timeOut = '0' + str(@nHour,1)
  else set @timeOut = LTrim(Str(@nHour,10,0))
  if @nMin < 10 set @cMin = '0' + str(@nMin,1)
  else set @cMin = str(@nMin,2)
  if @nSec < 10 set @cSec = '0' + str(@nSec,1)
  else set @cSec = str(@nSec,2)

  set @timeOut = @timeOut + ':' + @cMin + ':' + @cSec
end
--print @timeOut


