------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Delete_XFiles_rpdagimage]

as

delete from RPDAG_IMAGE.dbo._XFiles
where not exists (Select *
from RPDAG.dbo.m_XFiles
where RPDAG.dbo.m_XFiles.id_image = RPDAG_IMAGE.dbo._XFiles.id_image)

