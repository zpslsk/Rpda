


CREATE PROCEDURE [dbo].[Update_m_TrainsInfo_alsn_color]
@train_id int

as

update m_TrainsInfo
set
alsn_green_x = ISNULL ((select sum(abs(x_end - x_begin)) / 1000
from m_ActionColor
where train_id = @train_id and
n_color = 0), 0),
alsn_yellow_x = ISNULL ((select sum(abs(x_end - x_begin)) / 1000
from m_ActionColor
where train_id = @train_id and
n_color = 1), 0),
alsn_redyellow_x = ISNULL ((select sum(abs(x_end - x_begin)) / 1000
from m_ActionColor
where train_id = @train_id and
n_color = 2), 0),
alsn_red_x = ISNULL ((select sum(abs(x_end - x_begin)) / 1000
from m_ActionColor
where train_id = @train_id and
n_color = 3), 0),
alsn_white_x = ISNULL ((select sum(abs(x_end - x_begin)) / 1000
from m_ActionColor
where train_id = @train_id and
n_color = 4), 0),
alsn_gray_x = ISNULL ((select sum(abs(x_end - x_begin)) / 1000
from m_ActionColor
where train_id = @train_id and
n_color = 5), 0),


alsn_green_time = ISNULL ((select sum(abs(time_end - time_begin))
from m_ActionColor
where train_id = @train_id and
n_color = 0), 0),
alsn_yellow_time = ISNULL ((select sum(abs(time_end - time_begin))
from m_ActionColor
where train_id = @train_id and
n_color = 1), 0),
alsn_redyellow_time = ISNULL ((select sum(abs(time_end - time_begin))
from m_ActionColor
where train_id = @train_id and
n_color = 2), 0),
alsn_red_time = ISNULL ((select sum(abs(time_end - time_begin))
from m_ActionColor
where train_id = @train_id and
n_color = 3), 0),
alsn_white_time = ISNULL ((select sum(abs(time_end - time_begin))
from m_ActionColor
where train_id = @train_id and
n_color = 4), 0),
alsn_gray_time = ISNULL ((select sum(abs(time_end - time_begin))
from m_ActionColor
where train_id = @train_id and
n_color = 5), 0),

alsn_green_count = ISNULL ((select count(*)
from m_ActionColor
where train_id = @train_id and
n_color = 0), 0),

alsn_yellow_count = ISNULL ((select count(*)
from m_ActionColor
where train_id = @train_id and
n_color = 1), 0),

alsn_redyellow_count = ISNULL ((select count(*)
from m_ActionColor
where train_id = @train_id and
n_color = 2), 0),

alsn_red_count = ISNULL ((select count(*)
from m_ActionColor
where train_id = @train_id and
n_color = 3), 0),

alsn_white_count = ISNULL ((select count(*)
from m_ActionColor
where train_id = @train_id and
n_color = 4), 0),

alsn_gray_count = ISNULL ((select count(*)
from m_ActionColor
where train_id = @train_id and
n_color = 5), 0)

where train_id = @train_id
