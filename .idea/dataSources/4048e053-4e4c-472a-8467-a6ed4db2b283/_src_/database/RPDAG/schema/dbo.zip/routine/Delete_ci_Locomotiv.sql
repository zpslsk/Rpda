------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Delete_ci_Locomotiv]
@loc_num char(20),
@loc_Type int

as

delete from ci_Locomotiv
where loc_num = @loc_num and
loc_Type = @loc_Type and
not exists (select loc_id
from ci_Loc_Section
where ci_Loc_Section.loc_id = ci_Locomotiv.loc_id)

