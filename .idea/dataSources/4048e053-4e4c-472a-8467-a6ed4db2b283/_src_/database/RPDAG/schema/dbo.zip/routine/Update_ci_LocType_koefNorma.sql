-----------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Update_ci_LocType_koefNorma]
@type_id int,
@koefNorma float

as

Update ci_LocType set koefNorma = @koefNorma
where type_id = @type_id or
@type_id = 0

