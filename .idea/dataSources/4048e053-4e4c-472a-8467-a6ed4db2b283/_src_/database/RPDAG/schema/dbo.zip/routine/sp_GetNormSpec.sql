
/*****************************************************************
-- Автор:	Сираджи Р.Ф.
-- Описание:	возвращает уд.норму по заданным дате, направлению и нагрузки на ось
*****************************************************************/
CREATE PROCEDURE [dbo].[sp_GetNormSpec]
@date DateTime,
@ss_id int,
@axelWeigth float,
@NormSpec float Output

AS

declare @n int, @id_NameSS int
select @n = 0, @NormSpec = NULL

select @id_NameSS = IdNameSS
from ci_ServiceSoulder
where ss_id = @ss_id

while (@n<2) and (@NormSpec is Null) begin
if @n = 1 begin
if not exists(select * from ci_NormaSS where bDefault = 1)
exec sp_InitSSByDefNorma -1
end

select @NormSpec = max(case
when @axelWeigth <  5 then FNorma0_5
when @axelWeigth <  6	then FNorma5_6
when @axelWeigth <  7	then FNorma6_7
when @axelWeigth <  8	then FNorma7_8
when @axelWeigth <  9	then FNorma8_9
when @axelWeigth < 10	then FNorma9_10
when @axelWeigth < 11	then FNorma10_11
when @axelWeigth < 12	then FNorma11_12
when @axelWeigth < 13	then FNorma12_13
when @axelWeigth < 14	then FNorma13_14
when @axelWeigth < 15	then FNorma14_15
when @axelWeigth < 16	then FNorma15_16
when @axelWeigth < 17	then FNorma16_17
when @axelWeigth < 18	then FNorma17_18
when @axelWeigth < 19	then FNorma18_19
when @axelWeigth < 20	then FNorma19_20
when @axelWeigth < 21	then FNorma20_21
when @axelWeigth < 22	then FNorma21_22
when @axelWeigth < 23	then FNorma22_23
when @axelWeigth < 24	then FNorma23_24
when @axelWeigth < 25	then FNorma24_25
else FNorma25_99
end)
from ci_NormaSS where ((@n=0) and
(@date between dtBegin and dtEnd) and
(id_NameSS = @id_NameSS)) or ((@n = 1) and (bDefault = 1))

set @n = @n + 1
end
