--------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Update_ci_LocType]
@type_code int,
@eks_code int,
@type_name nvarchar(15),
@koefNorma float,
@type_id int

as

Update ci_LocType set type_code = @type_code, eks_code = @eks_code, type_name = @type_name, koefNorma = @koefNorma
where type_id = @type_id

