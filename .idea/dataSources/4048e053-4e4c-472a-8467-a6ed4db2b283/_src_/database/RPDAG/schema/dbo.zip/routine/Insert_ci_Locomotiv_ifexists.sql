----------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Insert_ci_Locomotiv_ifexists]
@LocType int,
@LocNum char(20),
@SecCount int,
@koefNorma float

as

if not exists
(select *
from ci_Locomotiv
where loc_type = @LocType and
loc_num = @LocNum)
insert into ci_Locomotiv(loc_type, sec_count, loc_num, koefNorma)
values (@LocType, @SecCount, @LocNum, @koefNorma)

