------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Update_ci_NormaVt]
@dtBegin smalldatetime,
@dtEnd smalldatetime,
@id int

as

update ci_NormaVt set dtBegin = @dtBegin, dtEnd = @dtEnd where id = @id

