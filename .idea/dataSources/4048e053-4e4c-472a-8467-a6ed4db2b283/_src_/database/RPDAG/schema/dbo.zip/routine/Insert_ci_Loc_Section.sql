
-----------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Insert_ci_Loc_Section]
@loc_id int,
@sec_id int

as

Insert into ci_Loc_Section (loc_id, sec_id)
Values(@loc_id, @sec_id)

