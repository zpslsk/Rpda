

CREATE PROCEDURE [dbo].[Rep_RasxodEnergy]
@dtNow DateTime,
@NumRoad int,
@NumTch int

AS

set nocount on

declare @dtBegin DateTime, @dtEnd DateTime, @dtTemp DateTime, @i int, @n int,
@aWork float, @aRasxod float, @aUdRasxod float, @aEconomy float, @aTexSpeed float, @aWeigth float, @aCntLim int, @aRecup float, @aReact float,
@nBrigPlus float, @nBrigMinus float, @aNorma float, @cnt int,
@SRes varchar(1000), @sText nchar(100)

--set @dtNow = '2005-03-31'
set @dtNow = cast(@dtNow as int)

set @n = day(@dtNow) - 1
set @dtTemp = DATEADD(Day, -@n , @dtNow)

select @i = 1, @SRes = ''

while @i < 5 begin
if @i = 1 begin
--Текущий месяц
set @dtBegin = @dtTemp
set @dtEnd = @dtNow
end
else if @i = 2 begin
--Тот же месяц Прошлого года
set @dtBegin = DATEADD(Year, -1, @dtTemp)
set @dtEnd = DATEADD(Year, -1, @dtNow)
end
else if @i = 3 begin
--С начала Текущего года
set @n = month(@dtTemp) - 1
set @dtTemp = DATEADD(Month, -@n , @dtTemp)
set @dtBegin = @dtTemp
set @dtEnd = @dtNow
end
else if @i = 4 begin
--С начала Прошлого года
set @dtBegin = DATEADD(Year, -1, @dtTemp)
set @dtEnd = DATEADD(Year, -1, @dtNow)
end
set @dtEnd = @dtEnd + 1

--print cast(@dtBegin as char(20))+ ' - '+ cast(@dtEnd as char(20))

select @cnt = count(*), @aWork = sum(trWork), @aRasxod = sum(DrawMeter), @aNorma = sum(Norma),
@aTexSpeed = case sum(train_time_move) when 0 then 0 else
sum(x_Common) * 1000 / sum(train_time_move) * 3.6 end,
@aWeigth = avg(weight),
@aRecup = sum(RecupMeter),
@aReact = sum(RecupMeter),
@aCntLim = sum(countCLim)
from m_TrainsInfo inner join m_Trains on m_TrainsInfo.train_id = m_Trains.train_id
where dateTr between @dtBegin and @dtEnd and
((@NumRoad = 0) or (num_road = @NumRoad)) and
((@NumTch = 0) or (num_tch = @NumTch))

/************************************************************************************************************************/
select @aRecup = IsNull(sum(m_TrainsInfo.RecupMeter), 0)
from m_Trains
inner join m_TrainsInfo on m_TrainsInfo.train_id = m_Trains.train_id
inner join ci_Locomotiv on ci_Locomotiv.loc_id = m_TrainsInfo.loc_id
where ci_Locomotiv.loc_type = 2 and
dateTr between @dtBegin and @dtEnd and
((@NumRoad = 0) or (num_road = @NumRoad)) and
((@NumTch = 0) or (num_tch = @NumTch))

select @aReact = IsNull(sum(m_TrainsInfo.RecupMeter), 0)
from m_Trains
inner join m_TrainsInfo on m_TrainsInfo.train_id = m_Trains.train_id
inner join ci_Locomotiv on ci_Locomotiv.loc_id = m_TrainsInfo.loc_id
where ci_Locomotiv.loc_type = 3 and
dateTr between @dtBegin and @dtEnd and
((@NumRoad = 0) or (num_road = @NumRoad)) and
((@NumTch = 0) or (num_tch = @NumTch))
/************************************************************************************************************************/

if @aWork > 0 set @aUdRasxod = (@aRasxod * 10000) / (@aWork * 1000)  else set @aUdRasxod = NULL
if @aNorma > 0 set @aEconomy = (@aRasxod - @aNorma)/@aNorma * 100  else set @aEconomy = NULL
if @cnt > 0 begin
select @nBrigPlus = count(*)/@cnt * 100 from m_TrainsInfo inner join m_Trains on m_TrainsInfo.train_id = m_Trains.train_id
where (dateTr between @dtBegin and @dtEnd) and
(DrawMeter < Norma) and
((@NumRoad = 0) or (num_road = @NumRoad)) and
((@NumTch = 0) or (num_tch = @NumTch))
select @nBrigMinus = count(*)/@cnt * 100 from m_TrainsInfo inner join m_Trains on m_TrainsInfo.train_id = m_Trains.train_id
where (dateTr between @dtBegin and @dtEnd) and
(DrawMeter > Norma) and
((@NumRoad = 0) or (num_road = @NumRoad)) and
((@NumTch = 0) or (num_tch = @NumTch))
end
else begin
select @nBrigPlus = NULL, @nBrigMinus = NULL
end

set @SRes = @SRes + str(IsNull(@aWork, 0),15,3) + str(IsNull(@aRasxod, 0),15,3) + str(IsNull(@aUdRasxod, 0),15,3) +
str(IsNull(@aEconomy, 0),15,3) + str(IsNull(@aTexSpeed, 0),15,3) + str(IsNull(@aWeigth, 0),15,3) + str(IsNull(@aCntLim, 0),15,3) +
str(IsNull(@aRecup, 0),15,3) + str(IsNull(@aReact, 0),15,3) + str(IsNull(@nBrigPlus, 0),15,3) + str(IsNull(@nBrigMinus, 0),15,3)

set @i = @i + 1
end

create table #tmpEn (sText nchar(100), Param1 float, Param2 float, Param3 float, Param4 float)
set @i = 0
while @i < 11 begin
if @i = 0 set @sText = N'Фактический объем работы, тКм * 10000'
else if @i = 1 set @sText = N'Фактический расход электроэнерги, квт*ч'
else if @i = 2 set @sText = N'Удельный расход, Квт.ч/10 т.км, брутто'
else if @i = 3 set @sText = N'Экономия "-" , пережог "+"'
else if @i = 4 set @sText = N'Техническая скорость, км/ч'
else if @i = 5 set @sText = N'Средний вес поезда, т'
else if @i = 6 set @sText = N'Количество поездопредупреждений'
else if @i = 7 set @sText = N'Рекуперация, квт*ч'
else if @i = 8 set @sText = N'Реактивная энергия, квт*ч'
else if @i = 9 set @sText = N'Количество бригад с экономией, %'
else set @sText = N'Количество бригад с пережогом, %'

insert into #tmpEn Values(@sText,
cast(SUBSTRING(@SRes, @i*15+1, 15) as float), cast(SUBSTRING(@SRes, @i*15+166, 15) as float),
cast(SUBSTRING(@SRes, @i*15+331, 15) as float), cast(SUBSTRING(@SRes, @i*15+496,15) as float))
set @i = @i + 1
end

select * from #tmpEn

drop table #tmpEn

