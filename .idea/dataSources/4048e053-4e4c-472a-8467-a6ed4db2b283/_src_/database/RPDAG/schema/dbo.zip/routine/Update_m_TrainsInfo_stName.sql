----------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Update_m_TrainsInfo_stName]
@stName nvarchar(255),
@train_id int

as

update m_TrainsInfo
set stName = @stName
where train_id = @train_id

