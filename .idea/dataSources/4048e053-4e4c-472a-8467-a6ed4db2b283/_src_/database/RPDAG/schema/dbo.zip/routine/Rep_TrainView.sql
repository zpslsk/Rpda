
/*****************************************************************
-- Автор:	Сираджи Р.Ф.
-- Описание:	Возвращает развернутый отчет по конкретному поезду
*****************************************************************/
CREATE PROCEDURE Rep_TrainView
 @trId int

AS

--set @trId = 2299
set nocount on

declare @dateTr DateTime, @x_Common Float, @x_SavpeNot Float, @x_SavpePrompt Float, @x_SavpeAuto Float, 
	@fSecInDT float, @train_time DateTime, @train_time_move DateTime, @t_SavpeNot DateTime, @t_SavpePrompt DateTime, @t_SavpeAuto DateTime,
	@loc_num varchar(20), @loc_type varchar(20), @weight int, @VagsCount int, @cntVFull int, @cntVEmpty int,
	@tb_num int, @surname varchar(20), @name varchar(20), @patronymic varchar(20), @driverName varchar(100),
	@bandag int, @av_speed_move float, @av_speed float, @trWork float,
	@DrawMeter float, @RecupMeter float, @Norma float, @countCLim int, @countTLim int, @ss_name varchar(50)

set @fSecInDT = 1.0/86400
select @dateTr = dateTr, 
	@x_Common = x_Common, @x_SavpeNot = x_SavpeNot, @x_SavpePrompt = x_SavpePrompt, @x_SavpeAuto = x_SavpeAuto,
	@train_time = @fSecInDT*train_time, @train_time_move = @fSecInDT*train_time_move,
	@t_SavpeNot = @fSecInDT*t_SavpeNot, @t_SavpePrompt = @fSecInDT*t_SavpePrompt,	@t_SavpeAuto = @fSecInDT*t_SavpeAuto,
	@weight = weight, @VagsCount = VagsCount, @bandag = bandag,
	@av_speed_move = av_speed_move, @av_speed = av_speed, @trWork = trWork * 1000,
	@DrawMeter = DrawMeter, @RecupMeter = RecupMeter, @Norma = Norma,
	@countCLim = countCLim, @countTLim = countTLim
from m_Trains T inner join m_TrainsInfo TI on TI.train_id = T.train_id 
where T.train_id = @trId

select @ss_name = isNull(ss_name, '') from ci_ServiceSoulder SS inner join m_Trains T on SS.ss_id = T.ss_id
	where T.train_id = @trId

select @loc_num = isNull(loc_num, ''), @loc_type = isNull([type_name], '') 
from ci_Locomotiv L
	inner join m_TrainsInfo TI on L.loc_id = TI.loc_id
	inner join ci_LocType LT on type_id = loc_type where TI.train_id = @trId

select @cntVFull = count(*) from m_Sostav where train_id = @trId and weight > 0.5
select @cntVEmpty = count(*) from m_Sostav where train_id = @trId and weight < 0.5

select @tb_num = tb_num, @surname = RTRim(isNull(surname,'')), @name = RTRim(isNull([name],'')), @patronymic = RTRim(isNull(patronymic,''))
from ci_Drivers D inner join m_Trains T on D.drv_id = T.drv_id
if @tb_num is Null set @driverName = ''
else begin
	set @driverName = @surname
	if @name > '' begin
		set @driverName = @driverName + substring(@name,1,1)+'.'
		if @patronymic > '' set @driverName = @driverName + substring(@patronymic,1,1)+'.'
	end
	set @driverName = @driverName + '(таб.№ = '+LTRim(str(@tb_num))+')'	
end

select   0 as nLine,-1,  'Общие сведения', '' union
select  10 as nLine, 0,  'Маршрут', LTRim(RTRim(@ss_name)) union
select  20 as nLine, 0,  'Дата и время начала', convert(char(10),@dateTr,103)+ ' ' + convert(char(5),@dateTr,108) union
select  30 as nLine, 0,  'Пройденный путь, км', LTRim(str(@x_Common,12,1)) union
select  40 as nLine, 0,  'Путь с УСАВПГ : авто/подсказка/выкл., км', 
	LTRim(str(@x_SavpeAuto,12,1))+'/'+LTRim(str(@x_SavpePrompt,12,1))+'/'+LTRim(str(@x_SavpeNot,12,1)) union
select  50 as nLine, 0,  'Затраченное время', convert(char(5),@train_time,108) union
select  51 as nLine, 0,  'Время в движении', convert(char(5),@train_time_move,108) union
select  60 as nLine, 0,  'Время с УСАВПГ : авто/подсказка/выкл.',
	convert(char(5),@t_SavpeAuto,108)+'/'+convert(char(5),@t_SavpePrompt,108)+'/'+convert(char(5),@t_SavpeNot,108) union
select  70 as nLine, 0,  'Локомотив', '№'+RTRim(@loc_num)+' - '+RTRim(@loc_type) union  
select  80 as nLine, 0,  'Вес состава, т', LTRim(str(@weight)) union
select  90 as nLine, 0,  'Количество вагонов',  LTRim(str(@VagsCount))+' (груженных-'+LTRim(str(@cntVFull))+', порожних-'+LTRim(str(@cntVEmpty))+')' union 
select 100 as nLine, 0,  'Машинист', @driverName union
select 110 as nLine, 0,  'Диаметр бандажа, мм', LTRim(str(@bandag)) union
select 120 as nLine, 0,  'Техническая скорость, км/ч', LTRim(str(@av_speed_move,12,1)) union
select 130 as nLine, 0,  'Участковая скорость, км/ч', LTRim(str(@av_speed,12,1)) union
select 140 as nLine, 0,  'Тонно-км работа, ткм', LTRim(str(@trWork,12,1)) union
select 150 as nLine, 0,  'Общая потребленная энергия, кВт*ч', LTRim(str(@DrawMeter,12)) union
select 160 as nLine, 0,  'Энергия рекуперации, кВт*ч', LTRim(str(@RecupMeter,12)) union
select 170 as nLine, 0,  'Норма расхода энергии, кВт*ч', LTRim(str(@Norma,12)) union
select 180 as nLine, 1,  'Таксировка поезда', '' 

select stName[Станция], isNull(LTRim(str(km))+'км '+LTRim(str(pk))+'пк','')[ЖД-координата], 
	convert(char(8),DateTime_In,108) +'/'+ convert(char(8),DateTime_Out,108)[Время прибытия/отправления], 
	LTRim(str(ECounterIn,12))+'/'+LTRim(str(ECounterOut,12))[Энергия прибытия/отправления],
	speed[Скорость, км/ч], TextInfo[Сигнал АЛСН]
from m_Taksirovka Tax
	left join ci_Station S on S.st_id = Tax.st_id
	inner join ci_TextInfo on sGroup = 'ALSN' and nCode = valALSN
where train_id = @trId order by tax_id 

select  0 as nLine,-1,  'Ограничения скорости', '' union
select 10 as nLine, 0,  'Постоянных ограничений', isNull(LTRim(str(@countCLim)),'') union
select 20 as nLine, 0,  'Временных предупреждений', isNull(LTRim(str(@countTLim)),'') 

if exists(select * from m_Violation where tr_id = @trId) begin
	select 0 as nLine, 1,  'Дополнительная информация', '' 
	select sName[Параметр], count(*)[Кол-во повторений] from m_Violation inner join ci_ViolationType on vCode = v_id 
	where tr_id = @trId group by v_id,sName order by v_id 
end


--select 10 as nLine, 0,  '',  union
