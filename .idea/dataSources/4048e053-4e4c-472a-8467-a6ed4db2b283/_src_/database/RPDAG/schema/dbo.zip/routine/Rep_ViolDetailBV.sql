
CREATE PROCEDURE [dbo].[Rep_ViolDetailBV]
@drv_id int,
@nFilter int,
@idViol int,
@dtStart DateTime,
@dtFinish DateTime,
@E_Invalidate int,
@V_Invalidate bit,
@IsResidence bit,
@NumRoad int,
@NumTch int,
@IsDateTrains bit


as

--select @idViol = 1, @dtStart = '2004-01-01', @dtFinish = '2005-12-01'

Select m_Trains.train_id, train_num,
(convert(char(11), dateTr, 120) + convert(char(8), dtBegin, 108)) as dateTr,
tb_num, RTRIM(surname) + ' ' + Left([name],1) + ' ' + Left(patronymic,1) as FIO,
[type_name], loc_num,
case kmBegin when Null then '*' else str(kmBegin,6)+'км '+str(pkBegin,2)+'пк'  end as KmPk,
case kmEnd when Null then '*' else str(kmEnd,6)+'км '+str(pkEnd,2)+'пк'  end as KmPkEnd,
xLen,
case dtBegin when Null then '*' else convert(char(8),dtBegin,108)  end +
case dtEnd when Null then '' else + ' - ' + convert(char(8),dtEnd,108)  end as dtInterval,
tLen, aValue1, aValue2, aValue3, aValue4, aValue5, aValue6, aValue7, GoAuto,
E_Invalidate, V.id, isavprt_status, CV.vCode
from m_Trains inner join m_TrainsInfo on m_TrainsInfo.train_id = m_Trains.train_id
inner join m_Violation V on V.tr_id = m_Trains.train_id
inner join ci_ViolationType CV on CV.IdV = V.v_id
inner join ci_Drivers on ci_Drivers.drv_id = m_Trains.drv_id
inner join m_XFiles on m_XFiles.id_image = m_Trains.image_id
left join ci_Locomotiv on ci_Locomotiv.loc_id = m_TrainsInfo.loc_id
left join ci_LocType on ci_LocType.type_id = ci_Locomotiv.loc_type
left join Rep_Filter R1 on R1.nFilter = @nFilter and R1.FCode = 1 and ci_Locomotiv.loc_id = R1.FValue
left join Rep_Filter R2 on R2.nFilter = @nFilter and R2.FCode = 2 and ci_Drivers.drv_id = R2.FValue
where (V.v_id = @idViol) and ((@drv_id < 0) or (ci_Locomotiv.loc_id = @drv_id)) and

--(dateTr between @dtStart and @dtFinish) and

(
(dateTr between @dtStart and @dtFinish and @IsDateTrains > 0) or
(DataLastRead between @dtStart and @dtFinish and @IsDateTrains = 0)
) and

(R1.FValue is NULL) and (R2.FValue is NULL)
and ((@E_Invalidate = -1) or (E_Invalidate = @E_Invalidate)) and
((@NumRoad = 0) or (num_road = @NumRoad)) and
((@NumTch = 0) or (num_tch = @NumTch)) and
V_Invalidate = @V_Invalidate and
((Residence = @IsResidence) or (@IsResidence = 0))
order by dateTr
