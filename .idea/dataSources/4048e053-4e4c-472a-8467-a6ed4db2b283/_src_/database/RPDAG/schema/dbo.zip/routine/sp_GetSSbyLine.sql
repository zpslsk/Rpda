/*****************************************************************
-- Автор:	Сираджи Р.Ф.
-- Описание:	По строке станций, разделенных запятой, возвращает (при отсутствии создает и заполняет)
--   код маршрута (направления)
*****************************************************************/
CREATE PROCEDURE [dbo].[sp_GetSSbyLine]
@stLine varchar(500)

AS

set nocount on

declare @i int, @nOrd int, @ss_id int, @st_id int, @namess_id int,
@nameStFirst varchar(30), @nameStLast varchar(30), @nameSS varchar(60)

select @ss_id = ss_id from ci_ServiceSoulder where sListSt = @stLine

if @ss_id is NULL begin
insert into ci_ServiceSoulder(ss_name, FNeedInit, sListSt) Values('???', 1, @stLine)
set @ss_id = @@IDENTITY

select @nOrd = 0, @nameStFirst = '*', @nameStLast = '*'
while @stLine > '' begin
set @i = CHARINDEX(',', @stLine)
set @nOrd = @nOrd + 1

if @i <= 0 begin
set @st_id = cast(@stLine as int)
set @stLine = ''
end
else begin
set @st_id = cast(SUBSTRING(@stLine, 1, @i - 1) as int)
set @stLine = SUBSTRING(@stLine, @i+1, Len(@stLine))
end

insert into ci_StbySS(ss_id, st_id, nOrd) Values(@ss_id, @st_id, @nOrd)
if @nOrd = 1
select @nameStFirst = stName from ci_Station where st_id = @st_id
end
select @nameStLast = stName from ci_Station where st_id = @st_id
--*******************
set @nameSS = RTRim(@nameStFirst) + '->' + RTRim(@nameStLast)
update ci_ServiceSoulder set ss_name = @nameSS where ss_id = @ss_id
if not Exists (Select * from ci_NameSS where NameSS = @nameSS)
begin
insert into ci_NameSS (NameSS)
values(@nameSS)
set @namess_id = @@IDENTITY
update ci_ServiceSoulder set IdNameSS = @namess_id where ss_id = @ss_id
end else
update ci_ServiceSoulder
set IdNameSS = (select id from ci_NameSS n
where n.NameSS = ci_ServiceSoulder.ss_name)
--*******************
exec sp_InitSSByDefNorma @namess_id
end

select @ss_id
