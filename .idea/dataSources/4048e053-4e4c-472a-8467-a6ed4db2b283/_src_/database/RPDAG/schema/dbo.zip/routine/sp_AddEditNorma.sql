
/*****************************************************************
-- Автор:	Сираджи Р.Ф. 
-- Описание:	Добавляет/обновляет уд.норму по выбранному плечу
*****************************************************************/
CREATE PROCEDURE sp_AddEditNorma
	@ss_id int,
  @idNormaTo int,   -- если >0, то изменить интервал этой нормы, else - добавить новый интервал норм
  @idNormaFrom int, -- для нового интервала инициализировать норму из : <0 - из значений по умолчанию, else - из нормы с id_Norma = @idNormaFrom
  @dtFrom DateTime, 
  @dtTo DateTime

AS

declare @zDateFrom DateTime, @zDateTo DateTime, @idNorma int, @idNormaMin int, @idNormaMax int,
	@n4 float, @n5 float, @n6 float, @n7 float, @n8 float, @n9 float, @n10 float, @n11 float, @n12 float, @n13 float, @n14 float,
	@n15 float, @n16 float, @n17 float, @n18 float, @n19 float, @n20 float, @n21 float, @n22 float, @n23 float, @n24 float, @n25 float 

if not exists(select * from ci_Norma where bDefault = 1)
	exec sp_InitSSByDefNorma -1

if @idNormaTo > 0 set @idNorma = @idNormaTo
else begin
	if @idNormaFrom >= 0 set @idNorma = @idNormaFrom
	else select @idNorma = id_Norma from ci_Norma where bDefault = 1
end

select @n4 = FNorma0_5, @n5 = FNorma5_6, @n6 = FNorma6_7, @n7= FNorma7_8, @n8 = FNorma8_9, @n9 = FNorma9_10, 
	@n10 = FNorma10_11, @n11 = FNorma11_12, @n12 = FNorma12_13, @n13 = FNorma13_14, @n14 = FNorma14_15, @n15 = FNorma15_16, 
	@n16 = FNorma16_17, @n17 = FNorma17_18, @n18 = FNorma18_19, @n19 = FNorma19_20, 
	@n20 = FNorma20_21, @n21 = FNorma21_22, @n22 = FNorma22_23, @n23 = FNorma23_24, @n24 = FNorma24_25, @n25 = FNorma25_99
	from ci_Norma where id_Norma = @idNorma 

--удаляю интервалы лежащие внутри нового интервала
delete from ci_Norma where ss_id = @ss_id and dtBegin >= @dtFrom and dtEnd <= @dtTo
--нахожу интервал (A) снизу с ближайшим началом 
select @idNormaMin = id_Norma, @zDateFrom = dtBegin, @zDateTo = dtEnd from ci_Norma where ss_id = @ss_id 
	and dtBegin = (select max(dtBegin) from ci_Norma where ss_id = @ss_id and dtBegin < @dtFrom)
--устанавливаю конец интервала A = началу нового
update ci_Norma set dtEnd = @dtFrom - 1 where id_Norma = @idNormaMin

if @zDateTo > @dtTo
--если конец интервала A был дальше конца нового интервала, то остаток добавляю сверху отдельным интервалом
	insert into ci_Norma (bDefault, ss_id, dtBegin, dtEnd, 
		FNorma0_5, FNorma5_6, FNorma6_7, FNorma7_8, FNorma8_9, FNorma9_10, FNorma10_11, 
		FNorma11_12, FNorma12_13, FNorma13_14, FNorma14_15, FNorma15_16, FNorma16_17, FNorma17_18, FNorma18_19, FNorma19_20, FNorma20_21, 
		FNorma21_22, FNorma22_23, FNorma23_24, FNorma24_25, FNorma25_99)
		select 0, @ss_id, @dtTo + 1, @zDateTo, 
			FNorma0_5, FNorma5_6, FNorma6_7, FNorma7_8, FNorma8_9, FNorma9_10, FNorma10_11, 
			FNorma11_12, FNorma12_13, FNorma13_14, FNorma14_15, FNorma15_16, FNorma16_17, FNorma17_18, FNorma18_19, FNorma19_20, FNorma20_21, 
			FNorma21_22, FNorma22_23, FNorma23_24, FNorma24_25, FNorma25_99
		from ci_Norma where id_Norma = @idNormaMin
else begin	 
	--нахожу интервал (A) сверху с ближайшим началом 
	select @idNormaMax = id_Norma, @zDateFrom = dtBegin, @zDateTo = dtEnd from ci_Norma where ss_id = @ss_id 
		and dtBegin = (select min(dtBegin) from ci_Norma where ss_id = @ss_id and dtBegin >= @dtFrom)
	if @idNormaMax is not NULL
		update ci_Norma set dtBegin = @dtTo + 1 where id_Norma = @idNormaMax
end

insert into ci_Norma (bDefault, ss_id, dtBegin, dtEnd, 
		FNorma0_5, FNorma5_6, FNorma6_7, FNorma7_8, FNorma8_9, FNorma9_10, FNorma10_11, 
		FNorma11_12, FNorma12_13, FNorma13_14, FNorma14_15, FNorma15_16, FNorma16_17, FNorma17_18, FNorma18_19, FNorma19_20, FNorma20_21, 
		FNorma21_22, FNorma22_23, FNorma23_24, FNorma24_25, FNorma25_99) 
Values(0, @ss_id, @dtFrom, @dtTo, @n4, @n5, @n6, @n7, @n8, @n9, @n10, @n11, @n12, @n13, @n14,
	@n15, @n16, @n17, @n18, @n19, @n20, @n21, @n22, @n23, @n24, @n25)

