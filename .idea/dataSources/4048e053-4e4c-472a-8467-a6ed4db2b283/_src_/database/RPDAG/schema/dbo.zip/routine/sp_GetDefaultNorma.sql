
/*****************************************************************
-- Автор:	Сираджи Р.Ф.
-- Описание:	Возвращает recordset нагрузка на ось - уд.норма
*****************************************************************/
CREATE PROCEDURE [dbo].[sp_GetDefaultNorma]
AS

declare @n4 float, @n5 float, @n6 float, @n7 float, @n8 float, @n9 float, @n10 float, @n11 float, @n12 float, @n13 float, @n14 float,
@n15 float, @n16 float, @n17 float, @n18 float, @n19 float, @n20 float, @n21 float, @n22 float, @n23 float, @n24 float, @n25 float, @n26 float

if not exists(select * from ci_NormaSS where bDefault = 1)
exec sp_InitSSByDefNorma -1

select @n4 = FNorma0_5, @n5 = FNorma5_6, @n6 = FNorma6_7, @n7= FNorma7_8, @n8 = FNorma8_9, @n9 = FNorma9_10,
@n10 = FNorma10_11, @n11 = FNorma11_12, @n12 = FNorma12_13, @n13 = FNorma13_14, @n14 = FNorma14_15, @n15 = FNorma15_16,
@n16 = FNorma16_17, @n17 = FNorma17_18, @n18 = FNorma18_19, @n19 = FNorma19_20,
@n20 = FNorma20_21, @n21 = FNorma21_22, @n22 = FNorma22_23, @n23 = FNorma23_24, @n24 = FNorma24_25, @n25 = FNorma25_99
from ci_NormaSS where bDefault = 1

select  0 as nn, 'меньшше 5 т' as axleLoad, @n4 as Norma union
select  5, '5-6',   @n5  union
select  6, '6-7',   @n6  union
select  7, '7-8',   @n7  union
select  8, '8-9',   @n8  union
select  9, '9-10',  @n9  union
select 10, '10-11', @n10 union
select 11, '11-12', @n11 union
select 12, '12-13', @n12 union
select 13, '13-14', @n13 union
select 14, '14-15', @n14 union
select 15, '15-16', @n15 union
select 16, '16-17', @n16 union
select 17, '17-18', @n17 union
select 18, '18-19', @n18 union
select 19, '19-20', @n19 union
select 20, '20-21', @n20 union
select 21, '21-22', @n21 union
select 22, '22-23', @n22 union
select 23, '23-24', @n23 union
select 24, '24-25', @n24 union
select 25, 'свыше 25 т', @n25 order by nn

