
CREATE PROCEDURE [dbo].[Insert_m_Trains]
@image_id int,
@ss_id int,
@train_num int,
@dateTr datetime,
@drv_id int,
@pDrv1_id int,
@pDrv2_id int,
@isavprt_status int,
@isavprt_addr int,
@num_road int,
@num_tch int,
@verpo varchar(7),
@datemap varchar(10)

as
Insert into m_Trains (image_id, ss_id, train_num, dateTr, drv_id, pDrv1_id, pDrv2_id, isavprt_status, isavprt_addr, num_road, num_tch, verpo, datemap)
Values(@image_id, @ss_id, @train_num, @dateTr, @drv_id, @pDrv1_id, @pDrv2_id, @isavprt_status, @isavprt_addr, @num_road, @num_tch, @verpo, @datemap)
