/*****************************************************************
-- Автор:	Сираджи Р.Ф.
-- Описание:	Возвращает данные по катриджам считанным за интервал времени
*****************************************************************/
CREATE PROCEDURE [dbo].[Rep_CatrijView]
@dtStart DateTime,
@dtFinish DateTime

AS

--select @dtStart = '2005-01-01', @dtFinish = '2006-01-01'

select ID_Image, NumKatr, convert(char(16),DataLastRead,120)DataLastRead,
(select count(*) from m_Trains where image_id = ID_Image) cntTr,
cast(0.001*sum(x_Regim) as Decimal(12,1))xAll,

(case sum(t_Regim) when 0 then 0 else cast(1.0/3600*sum(t_Regim) as Decimal(12,1)) end)tAll,
--cast(1.0/3600*sum(t_Regim) as Decimal(12,1))tAll,

(select cast(0.001*sum(x_Regim) as Decimal(12,1))
from m_RegimInfo where idImage = ID_Image and RegimType > 1)xAuto,

(select case sum(t_Regim) when 0 then 0 else cast(1.0/3600*sum(t_Regim) as Decimal(12,1)) end
from m_RegimInfo where idImage = ID_Image and RegimType > 1)tAuto,

(select sum(ETract) from m_RegimInfo where idImage = ID_Image)ETract,
(select sum(ERecup) from m_RegimInfo where idImage = ID_Image)ERecup,
FileName
from m_XFiles inner join m_RegimInfo on idImage = ID_Image
where DataLastRead between @dtStart and @dtFinish
group by ID_Image, NumKatr, DataLastRead, FileName
