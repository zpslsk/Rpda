---------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Update_ci_Setup_image_to_blob]
@image_to_blob bit

as

Update ci_Setup set image_to_blob = @image_to_blob

