
CREATE PROCEDURE [dbo].[Insert_m_XFiles]
@ID_Map int,
@NumKatr int,
@DataFirstRead datetime,
@DataLastRead datetime,
@FileName nvarchar(255),
@FieldId nvarchar(50)

as

Insert into m_XFiles (ID_Map, NumKatr, DataFirstRead, DataLastRead, FileName, FieldId)
Values (@ID_Map, @NumKatr, @DataFirstRead, @DataLastRead, @FileName, @FieldId)


set ANSI_NULLS OFF
set QUOTED_IDENTIFIER ON
