------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Delete_m_XFiles_all]

as

delete from m_XFiles
where not exists (select *
from m_trains t
where m_XFiles.id_image = t.Image_id)

