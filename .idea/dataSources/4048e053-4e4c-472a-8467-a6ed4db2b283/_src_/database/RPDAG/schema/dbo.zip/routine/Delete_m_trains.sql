------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Delete_m_trains]

as

delete from m_trains
where not exists (select train_num
from m_TrainsInfo ti
where m_trains.train_id = ti.train_id)

