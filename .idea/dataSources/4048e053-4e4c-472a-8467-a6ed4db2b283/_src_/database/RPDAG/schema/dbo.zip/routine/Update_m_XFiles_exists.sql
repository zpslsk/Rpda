---------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Update_m_XFiles_exists]
@EnMan int,
@ID_Image int

as

if exists
(select *
from INFORMATION_SCHEMA.COLUMNS
where table_name = 'm_XFiles' and
column_name = 'EnMan')

update m_XFiles
set EnMan = @EnMan
where id_image = @id_image

