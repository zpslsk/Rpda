
/*****************************************************************
-- Автор:	Сираджи Р.Ф.
-- Описание:	При отсутствии нормы по умолчанию добавляет ее, а также
--  инициализирует новое направление нормой по умолчанию на макс. интервал
*****************************************************************/
CREATE PROCEDURE [dbo].[sp_InitSSByDefNorma]
@id_NameSS int

AS

declare @id_def int

if not exists(select * from ci_NormaSS where bDefault = 1) begin
insert into ci_NormaSS (bDefault, id_NameSS, dtBegin, dtEnd, FNorma0_5, FNorma5_6, FNorma6_7, FNorma7_8, FNorma8_9, FNorma9_10, FNorma10_11,
FNorma11_12, FNorma12_13, FNorma13_14, FNorma14_15, FNorma15_16, FNorma16_17, FNorma17_18, FNorma18_19, FNorma19_20, FNorma20_21,
FNorma21_22, FNorma22_23, FNorma23_24, FNorma24_25, FNorma25_99)
Values(1, NULL, '1980-01-01 00:00:00', '2050-01-01 23:59:00', 112, 112, 112, 92, 92, 76, 76,
65, 65, 56, 56, 50, 50, 45, 45, 41, 41, 38, 38, 37, 37, 37)
end

if (@id_NameSS > 0) and not exists(select * from ci_NormaSS where id_NameSS = @id_NameSS) begin
select @id_def = id from ci_NormaSS where bDefault = 1

insert into ci_NormaSS (bDefault, id_NameSS, dtBegin, dtEnd,
FNorma0_5, FNorma5_6, FNorma6_7, FNorma7_8, FNorma8_9, FNorma9_10, FNorma10_11,
FNorma11_12, FNorma12_13, FNorma13_14, FNorma14_15, FNorma15_16, FNorma16_17, FNorma17_18, FNorma18_19, FNorma19_20, FNorma20_21,
FNorma21_22, FNorma22_23, FNorma23_24, FNorma24_25, FNorma25_99)
select 0, @id_NameSS,
dtBegin, dtEnd, FNorma0_5, FNorma5_6, FNorma6_7, FNorma7_8, FNorma8_9, FNorma9_10, FNorma10_11,
FNorma11_12, FNorma12_13, FNorma13_14, FNorma14_15, FNorma15_16, FNorma16_17, FNorma17_18, FNorma18_19, FNorma19_20, FNorma20_21,
FNorma21_22, FNorma22_23, FNorma23_24, FNorma24_25, FNorma25_99
from ci_NormaSS where id = @id_def
insert into ci_NormaVt (id_NameSS, dtBegin, dtEnd, NormaVt)
values (@id_NameSS, '1980-01-01 00:00:00', '2050-01-01 23:59:00', 50)
end
