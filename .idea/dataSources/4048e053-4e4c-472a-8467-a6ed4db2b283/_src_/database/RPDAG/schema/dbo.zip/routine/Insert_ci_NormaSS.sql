
------------------------------------------------------
CREATE PROCEDURE [dbo].[Insert_ci_NormaSS]
@id int,
@id_NameSS int,
@dtBegin char(20),
@dtEnd char(20)

as

insert into ci_NormaSS (bDefault, id_NameSS, dtBegin, dtEnd,
FNorma0_5, FNorma5_6, FNorma6_7, FNorma7_8, FNorma8_9,
FNorma9_10, FNorma10_11, FNorma11_12, FNorma12_13,
FNorma13_14, FNorma14_15, FNorma15_16, FNorma16_17, FNorma17_18,
FNorma18_19, FNorma19_20, FNorma20_21, FNorma21_22,
FNorma22_23, FNorma23_24, FNorma24_25, FNorma25_99)
select 0, @id_NameSS, @dtBegin, @dtEnd,
FNorma0_5, FNorma5_6, FNorma6_7, FNorma7_8, FNorma8_9,
FNorma9_10, FNorma10_11, FNorma11_12, FNorma12_13,
FNorma13_14, FNorma14_15, FNorma15_16, FNorma16_17, FNorma17_18,
FNorma18_19, FNorma19_20, FNorma20_21, FNorma21_22,
FNorma22_23, FNorma23_24, FNorma24_25, FNorma25_99
from ci_NormaSS
where (@id > 0 and id = @id)  or (@id = 0 and bDefault = 1)

