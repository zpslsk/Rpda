
/*****************************************************************
-- Автор:	Сираджи Р.Ф.
-- Описание:	Возвращает инфо по катриджам считанным за выбранный день
*****************************************************************/
CREATE PROCEDURE Rep_CatrijForDate
@dtStart DateTime

AS

--set @dtStart = '2005-04-13'

select ID_Image, NumKatr, convert(char(10), DataLastRead, 120) as DataLastRead,
convert(char(10), DateMap, 120) as DateMap,
(select count(*) from z_ReadError where ErrLevel < 100 and idImage = m_XFiles.ID_Image) as FError,
(select count(*) from z_ReadError where ErrLevel >= 100 and idImage = m_XFiles.ID_Image) as FWarning,
[FileName]
from m_XFiles
left join ci_Map on ci_Map.id_Map = m_XFiles.ID_Map
where DataFirstRead between @dtStart and @dtStart + 1

