


CREATE PROCEDURE [dbo].[sp_DeleteTrainById]
@trainId int,
@lFullDelete bit

AS

delete from m_Limits where train_id = @trainId
delete from m_Section where train_id = @trainId
delete from m_Sostav where train_id = @trainId
delete from m_Taksirovka where train_id = @trainId
delete from m_TrainsInfo where train_id = @trainId
delete from m_Violation where tr_id = @trainId
delete from m_CountEnergy  where id_Train = @trainId
delete from m_ActionColor  where train_id = @trainId
delete from m_Shedule where id_Train = @trainId
delete from m_FuelCalc where id_Train = @trainId
if exists (select * from dbo.sysobjects
where id = object_id(N'[dbo].[m_PosCtrl]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
delete from m_PosCtrl where Id_train = @trainId

if @lFullDelete = 1
delete from m_Trains where train_id = @trainId
