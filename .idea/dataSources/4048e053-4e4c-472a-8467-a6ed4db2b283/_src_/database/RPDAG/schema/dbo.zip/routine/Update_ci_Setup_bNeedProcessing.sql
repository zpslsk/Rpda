


CREATE PROCEDURE [dbo].[Update_ci_Setup_bNeedProcessing]
@bNeedProcessing bit

as

Update ci_Setup set bNeedProcessing = @bNeedProcessing

