

CREATE PROCEDURE [dbo].[Rep_ItogTxtTep]
@dtStart DateTime,
@dtFinish DateTime,
@E_Invalidate int,
@IsResidence bit,
@NumRoad int,
@NumTch int,
@IsDateTrains bit

AS
declare @countTr int, @runCommon float, @runAuto float, @runPrompt float, @timeCommon float, @timeStop float, @Work Float,
@DrawMeter float, @DrawMeterSpec float, @RecMeter float, @React float, @Norma float, @vUch float, @vTex float, @avgWeigth float, @avgLen float,
@countCLim int,  @avgCountCLim float, @countTLim int, @lenAllTlim float, @avgCountTLim float, @EnMan float,
@cTimeCommon char(20), @cTimeAuto char(20), @cTimeStop char(20), @i int, @sumWeigth float, @sumAxel int, @avgAxelWeigth float,
@FuelConsumpWeight float, @FuelConsumpWeightCalc float, @ReFuelWeight float, @ReFuelCount int

select @countTr = count(*),
@runCommon = sum(x_Common), @runAuto = sum(x_SavpeAuto), @runPrompt = sum(x_SavpePrompt),
@timeCommon = sum(train_time), @timeStop = sum(train_time)-sum(train_time_move),
@Work = sum(trWork), @DrawMeter = sum(DrawMeter),
@DrawMeterSpec = case sum(x_Common * weight) when 0 then 0 else
sum(DrawMeter) *10000 / sum(x_Common * weight) end,
@RecMeter = sum(RecupMeter),
@vUch = case sum(train_time) when 0 then 0 else
sum(x_Common)/sum(train_time)*3600 end,
@vTex = case sum(train_time_move) when 0 then 0 else
sum(x_Common)/sum(train_time_move)*3600 end,

@FuelConsumpWeight = sum(FuelConsumpWeight1) + sum(FuelConsumpWeight2),
@FuelConsumpWeightCalc = sum(FuelConsumpWeightCalc1) + sum(FuelConsumpWeightCalc2),
@ReFuelWeight = sum(ReFuelWeight1) + sum(ReFuelWeight2),
@ReFuelCount = sum(ReFuelCount1) + sum(ReFuelCount2),

@avgWeigth = avg(weight), @avgLen = avg(trLength),
@countCLim = sum(countCLim),
@avgCountCLim = case count(*) when 0 then 0 else sum(1.0*countCLim)/count(*) end,
@countTLim = sum(countTLim),
@avgCountTLim = case count(*) when 0 then 0 else sum(1.0*countTLim)/count(*) end,
@Norma = sum(Norma),
@lenAllTlim = sum(LengthTLim) / 1000,
@sumWeigth = sum(weight), @sumAxel = sum(numAxel)
from m_Trains
inner join m_TrainsInfo on m_TrainsInfo.train_id = m_Trains.train_id
inner join ci_Locomotiv on ci_Locomotiv.loc_id = m_TrainsInfo.loc_id
inner join m_XFiles on m_XFiles.id_image = m_Trains.image_id
inner join ci_LocTYpe on ci_LocTYpe.type_id = ci_Locomotiv.loc_type
where
ci_LocTYpe.type_code in (17, 18, 19, 20) and

(
(dateTr between @dtStart and @dtFinish and @IsDateTrains > 0) or
(DataLastRead between @dtStart and @dtFinish and @IsDateTrains = 0)
) and

((@E_Invalidate = -1) or (E_Invalidate = @E_Invalidate)) and
-- ******************************
(av_speed < 100) and
(av_speed_move < 100) and

((Residence = @IsResidence) or (@IsResidence = 0)) and
((@NumRoad = 0) or (num_road = @NumRoad)) and
((@NumTch = 0) or (num_tch = @NumTch))
/**********************************************************************************************/
select @RecMeter = IsNull(sum(m_TrainsInfo.RecupMeter), 0)
from m_Trains
inner join m_TrainsInfo on m_TrainsInfo.train_id = m_Trains.train_id
inner join ci_Locomotiv on ci_Locomotiv.loc_id = m_TrainsInfo.loc_id
inner join m_XFiles on m_XFiles.id_image = m_Trains.image_id
inner join ci_LocTYpe on ci_LocTYpe.type_id = ci_Locomotiv.loc_type
where   ci_LocTYpe.type_code in (17, 18, 19, 20) and

(
(dateTr between @dtStart and @dtFinish and @IsDateTrains > 0) or
(DataLastRead between @dtStart and @dtFinish and @IsDateTrains = 0)
) and

((@E_Invalidate = -1) or (E_Invalidate = @E_Invalidate)) and

-- ******************************
(av_speed < 100) and
(av_speed_move < 100) and
((Residence = @IsResidence) or (@IsResidence = 0)) and
((@NumRoad = 0) or (num_road = @NumRoad)) and
((@NumTch = 0) or (num_tch = @NumTch))

select @React = IsNull(sum(m_TrainsInfo.RecupMeter), 0)
from m_Trains
inner join m_TrainsInfo on m_TrainsInfo.train_id = m_Trains.train_id
inner join ci_Locomotiv on ci_Locomotiv.loc_id = m_TrainsInfo.loc_id
inner join m_XFiles on m_XFiles.id_image = m_Trains.image_id
inner join ci_LocTYpe on ci_LocTYpe.type_id = ci_Locomotiv.loc_type
where ci_LocTYpe.type_code = 3 and

(
(dateTr between @dtStart and @dtFinish and @IsDateTrains > 0) or
(DataLastRead between @dtStart and @dtFinish and @IsDateTrains = 0)
) and

((@E_Invalidate = -1) or (E_Invalidate = @E_Invalidate)) and
-- ******************************
(av_speed < 100) and
(av_speed_move < 100) and
((Residence = @IsResidence) or (@IsResidence = 0)) and
((@NumRoad = 0) or (num_road = @NumRoad)) and
((@NumTch = 0) or (num_tch = @NumTch))
/**********************************************************************************************/

if exists
(select *
from INFORMATION_SCHEMA.COLUMNS
where	table_name = 'm_XFiles' and
column_name = 'EnMan')
select @EnMan = sum(m_XFiles.EnMan)
from m_XFiles
where exists (Select *
from m_Trains, m_TrainsInfo, ci_Locomotiv
where m_Trains.image_id = m_XFiles.id_image and
m_TrainsInfo.train_id = m_Trains.train_id and
ci_Locomotiv.loc_id = m_TrainsInfo.loc_id and

(
(dateTr between @dtStart and @dtFinish and @IsDateTrains > 0) or
(DataLastRead between @dtStart and @dtFinish and @IsDateTrains = 0)
) and

((@E_Invalidate = -1) or (m_TrainsInfo.E_Invalidate = @E_Invalidate)) and

-- ******************************
(av_speed < 100) and
(av_speed_move < 100) and
((Residence = @IsResidence) or (@IsResidence = 0)) and
((@NumRoad = 0) or (num_road = @NumRoad)) and
((@NumTch = 0) or (num_tch = @NumTch))
)

/**********************************************************************************************/
exec sp_SecInHHMMSS @timeCommon, @cTimeCommon output
exec sp_SecInHHMMSS @timeStop, @cTimeStop output
if @sumAxel = 0 set @avgAxelWeigth = 0.0
else set @avgAxelWeigth = @sumWeigth/@sumAxel

select   0 as iid, -1, N'Эксплуатационные показатели', '' union
select  10 as iid, 0, N'Число маршрутов', LTrim(str(@countTr,10)) union
select  20 as iid, 0, N'Суммарный поездной пробег, км', LTrim(str(@runCommon,15,1)) union
--select  30 as iid, 1, N'Пробег в автоведении, км', LTrim(str(@runAuto,15,1))+' ('+LTrim(str(case @runCommon when 0 then 0 else 100.0*@runAuto/@runCommon end,7,1))+'%)' union
--select  31 as iid, 1, N'Пробег в режиме подсказки, км', LTrim(str(@runPrompt,15,1))+' ('+LTrim(str(case @runCommon when 0 then 0 else 100.0*@runPrompt/@runCommon end,7,1))+'%)' union
select  40 as iid, 0, N'Общее время работы', @cTimeCommon union
select  60 as iid, 1, N'Время простоя', @cTimeStop union
select  70 as iid, 0, N'Суммарная поездная работа, тКм * 10000', LTrim(str(@Work,15,1)) union
select  80 as iid, 0, N'Средняя участковая скорость, км/ч', LTrim(str(@vUch,15,1)) union
select  90 as iid, 0, N'Средняя техническая скорость, км/ч', LTrim(str(@vTex,15,1)) union
--select 100 as iid, 0, N'Средняя масса состава, т', LTrim(str(@avgWeigth,15,1)) union
--select 110 as iid, 0, N'Средняя длина состава, м', LTrim(str(@avgLen,15,1)) union
--select 111 as iid, 0, N'Средняя нагрузка на ось, т', LTrim(str(@avgAxelWeigth,15,1)) union
select 120 as iid, -1, N'Расход топлива', '' union
select 130 as iid, 0, N'Расчетный расход топлива кг.', LTrim(str(@FuelConsumpWeightCalc,15,1)) union
select 140 as iid, 0, N'Фактический расход топлива кг.', LTrim(str(@FuelConsumpWeight,15,1)) union
select 150 as iid, 0, N'Пережог топлива кг.', LTrim(str(@FuelConsumpWeight - @FuelConsumpWeightCalc,15,1)) union
select 155 as iid, 0, N'Удельный расход:', '' union
select 160 as iid, 1, N'кг/ 100 км.', LTrim(str(@FuelConsumpWeight / @runCommon * 100, 15, 1)) union
select 170 as iid, 1, N'кг/ час', LTrim(str(@FuelConsumpWeight / (@timeCommon / 3600), 15, 1)) union
select 180 as iid, 0, N'Количество экипировок', LTrim(str(@ReFuelCount,15,1)) union
select 190 as iid, 0, N'Набор топлива кг.', LTrim(str(@ReFuelWeight,15,1))

order by iid
