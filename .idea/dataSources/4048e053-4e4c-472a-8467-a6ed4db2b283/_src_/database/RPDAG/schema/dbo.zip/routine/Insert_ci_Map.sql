
------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Insert_ci_Map]
@DateMap smalldatetime,
@DateImport smalldatetime,
@DepoId int,
@sPath char(255)

as

Insert into ci_Map (DateMap, DateImport, DepoId, sPath)
Values(@DateMap, @DateImport, @DepoId, @sPath)

