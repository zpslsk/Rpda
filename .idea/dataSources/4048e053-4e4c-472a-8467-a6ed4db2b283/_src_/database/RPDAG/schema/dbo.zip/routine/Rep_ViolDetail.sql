
/*****************************************************************
-- Автор:	Сираджи Р.Ф.
-- Описание:	Возвращает детальный отчет по нарушениям за интервал времени с учетом параметров фильтра в таблице Rep_Filter
*****************************************************************/
CREATE PROCEDURE Rep_ViolDetail
@drv_id int,
@nFilter int,
@idViol int,
@dtStart DateTime,
@dtFinish DateTime

as

--select @idViol = 1, @dtStart = '2004-01-01', @dtFinish = '2005-12-01'

Select m_Trains.train_id, train_num, convert(char(16),dateTr,120)as dateTr,
tb_num, RTRIM(surname) + ' ' + Left([name],1) + ' ' + Left(patronymic,1) as FIO,
[type_name], loc_num,
case kmBegin when Null then '*' else str(kmBegin,6)+'км '+str(pkBegin,2)+'пк'  end +
case kmEnd when Null then '' else + ' - ' + str(kmEnd,6)+'км '+str(pkEnd,2)+'пк'  end as KmPk,
xLen,
case dtBegin when Null then '*' else convert(char(8),dtBegin,108)  end +
case dtEnd when Null then '' else + ' - ' + convert(char(8),dtEnd,108)  end as dtInterval,
tLen, aValue1, aValue2
from m_Trains inner join m_TrainsInfo on m_TrainsInfo.train_id = m_Trains.train_id
inner join m_Violation V on V.tr_id = m_Trains.train_id
inner join ci_Drivers on ci_Drivers.drv_id = m_Trains.drv_id
left join ci_Locomotiv on ci_Locomotiv.loc_id = m_TrainsInfo.loc_id
left join ci_LocType on ci_LocType.type_id = ci_Locomotiv.loc_type
left join Rep_Filter R1 on R1.nFilter = @nFilter and R1.FCode = 1 and ci_Locomotiv.loc_id = R1.FValue
left join Rep_Filter R2 on R2.nFilter = @nFilter and R2.FCode = 2 and ci_Drivers.drv_id = R2.FValue
where (V.v_id = @idViol) and ((@drv_id < 0) or (m_Trains.drv_id = @drv_id))
and (dateTr between @dtStart and @dtFinish)
and (R1.FValue is NULL) and (R2.FValue is NULL)
order by dateTr