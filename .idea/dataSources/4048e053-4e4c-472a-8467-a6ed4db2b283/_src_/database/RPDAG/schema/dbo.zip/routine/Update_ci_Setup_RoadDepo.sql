------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[Update_ci_Setup_RoadDepo]
@RoadName char(50),
@RoadCode char(10),
@DepoName char(50),
@DepoTCH char(10)

as

Update ci_Setup set RoadName = @RoadName, RoadCode = @RoadCode, DepoName = @RoadCode, DepoTCH = @DepoTCH

