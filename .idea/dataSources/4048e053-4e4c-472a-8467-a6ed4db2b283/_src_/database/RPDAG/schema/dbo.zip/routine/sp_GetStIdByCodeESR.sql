
CREATE PROCEDURE sp_GetStIdByCodeESR 
	@codeS int,
	@codeESR int,
	@sName char(30),
	@map_id int

AS

set nocount on

declare @st_id int, @sNameA char(30)

if @codeESR < 0 
	select @st_id = st_id from ci_Station where (codeS = @codeS) and (stName = @sNameA)
else
	select @st_id = st_id from ci_Station where codeESR = @codeESR

if @st_id is Null begin
	insert into ci_Station(codeS, codeESR, stName) Values(@codeS, @codeESR, @sName)
	set @st_id = @@IDENTITY
end

If not exists(select * from ci_StByMap where map_id = @map_id and st_id_inMap = @codeS) 
	Insert into ci_StByMap (map_id, st_id_inMap, st_id) Values(@map_id, @codeS, @st_id) 

select @st_id

