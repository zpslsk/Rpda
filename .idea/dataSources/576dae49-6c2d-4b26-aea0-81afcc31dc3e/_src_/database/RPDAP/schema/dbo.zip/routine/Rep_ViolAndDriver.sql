

/*****************************************************************
-- Описание:	Возвращает нарушения в целом или по машинистам за интервал времени с учетом параметров фильтра в таблице Rep_Filter
*****************************************************************/
CREATE PROCEDURE [dbo].[Rep_ViolAndDriver]
@bByDriver bit,
@nFilter int,
@dtStart DateTime,
@dtFinish DateTime,
-- zap 20.02.2006 *************************************
@TypeRep int,
@idtch int

as

--select @bByDriver =1, @nFilter = -1, @dtStart = '2004-01-01', @dtFinish = '2005-12-01'

if @bByDriver = 0 begin
Select -1 as drv_id, NULL as tb_num, 'Все машинисты в целом' as FIO, count(*)as cnt
from m_Violation v
inner join m_Trains a on v.tr_id = a.train_id and a.id_tch = isnull(@idtch,a.id_tch)
inner join m_TrainsInfo b on b.train_id = a.train_id
-- zap 20.02.2006 *************************************
inner join ci_ViolationType cv on  cv.idV = v.v_id
--***********************************************************
left join Rep_Filter R1 on R1.nFilter = @nFilter and R1.FCode = 2 and loc_id = R1.FValue
left join Rep_Filter R2 on R2.nFilter = @nFilter and R2.FCode = 3 and drv_id = R2.FValue
where dateTr between @dtStart and @dtFinish
and R1.FValue is NULL and R2.FValue is NULL

-- zap 20.02.2006 *************************************
 and     (((cv.vCode >= 100) and (cv.vCode < 200)) and (@TypeRep = 1) ) or
            (((cv.vCode >= 200) and (cv.vCode < 300)) and (@TypeRep = 2) ) or
            (((cv.vCode >= 300) and (cv.vCode < 400)) and (@TypeRep = 3) ) or
            (((cv.vCode >= 400) and (cv.vCode < 500)) and (@TypeRep = 4) ) or
            (((cv.vCode >= 500) and (cv.vCode < 600)) and (@TypeRep = 5) ) or
            (((cv.vCode >= 600) and (cv.vCode < 700)) and (@TypeRep = 6) ) or
            (@TypeRep = 0) 
--**********************************************************
end

else begin
Select dr.drv_id, Min(dr.surname+' '+Left(dr.name,1)+' '+Left(dr.patronymic,1)) as FIO,
Min(dr.tb_num) as tb_num, count(*)as cnt
from ci_Drivers dr
inner join m_Trains a on dr.drv_id = a.drv_id and a.id_tch=isnull(@idtch,a.id_tch)
inner join m_TrainsInfo b on b.train_id = a.train_id
inner join m_Violation v on  v.tr_id = a.train_id
-- zap 20.02.2006 *************************************
inner join ci_ViolationType cv on  cv.idV = v.v_id
--*********************************************************
left join Rep_Filter R1 on R1.nFilter = @nFilter and R1.FCode = 2 and loc_id = R1.FValue
left join Rep_Filter R2 on R2.nFilter = @nFilter and R2.FCode = 3 and dr.drv_id = R2.FValue
where dateTr between @dtStart and @dtFinish
and R1.FValue is NULL and R2.FValue is NULL

-- zap 20.02.2006 *************************************
 and     (((cv.vCode >= 100) and (cv.vCode < 200)) and (@TypeRep = 1) ) or
            (((cv.vCode >= 200) and (cv.vCode < 300)) and (@TypeRep = 2) ) or
            (((cv.vCode >= 300) and (cv.vCode < 400)) and (@TypeRep = 3) ) or
            (((cv.vCode >= 400) and (cv.vCode < 500)) and (@TypeRep = 4) ) or
            (((cv.vCode >= 500) and (cv.vCode < 600)) and (@TypeRep = 5) ) or
            (((cv.vCode >= 600) and (cv.vCode < 700)) and (@TypeRep = 6) ) or
            (@TypeRep = 0) 
--**********************************************************

group by dr.drv_id
order by FIO
end


