-- =============================================
-- Description:	<Запрос Коэффициента для вычисления уд. нормы>
-- =============================================
Create PROCEDURE [dbo].[sp_Get_KoeffNorm] 
@count_vags int
AS
declare @coef float
set @coef=0
Select Top 1 @coef=Coef from ci_WeightCoef where CountVags = @count_vags
select @coef
