-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Web_C_SummLoc]
@dtStart DateTime,
@dtFinish DateTime,
@TypeTrain int,
@idtch int
AS
Select Count(Distinct cil.loc_num)as count
  from m_Trains mt
    inner join m_TrainsInfo mti on mti.train_id = mt.train_id and mt.id_tch=@idtch
	inner join ci_Locomotiv cil on cil.loc_id = mti.loc_id
	where dateTr between @dtStart and @dtFinish and
	cil.loc_type =  isnull(@TypeTrain,cil.loc_type) and mt.train_num<>9999

