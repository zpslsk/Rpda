Create PROCEDURE [dbo].[sp_GetNormSpec] 
@NTrain int,
@date DateTime,
@Loctype int,
@idtch int
AS
declare @NormSpec float
set @NormSpec=0
select @NormSpec=Rate
from ci_Norma inner join ci_LocType on ci_LocType.type_id=ci_Norma.LocType_id
Where(id_tch=@idtch)and(type_code=@Loctype)and(bDefault=0)and(NTrain=@NTrain)and(@date between dtBegin  and dtEnd)
if @NormSpec = 0
 Select @NormSpec=Rate from ci_Norma where bDefault=1
select @NormSpec
