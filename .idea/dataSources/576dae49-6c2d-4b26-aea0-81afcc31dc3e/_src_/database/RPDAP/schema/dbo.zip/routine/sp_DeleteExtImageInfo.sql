Create PROCEDURE [dbo].[sp_DeleteExtImageInfo]
@idImage int
as
delete from z_ReadError where idImage = @idImage
