-- =============================================
-- Description:	<Добавляем инфо. о файле>
-- =============================================
Create PROCEDURE [dbo].[sp_Add_m_XFiles]
@ID_Map int,
@DataFirstRead Datetime,
@DataLastRead Datetime,
@FileName nvarchar(255),
@id_tch int,
@img_full bit
AS
SET NOCOUNT ON
Insert into m_XFiles(ID_Map,DataFirstRead,DataLastRead,[FileName],id_tch,img_full)
 Values(@ID_Map,@DataFirstRead,@DataLastRead,@FileName,@id_tch,@img_full)
select @@IDENTITY 
