










CREATE PROCEDURE sp_DeleteTrain
  @train_num int, 
  @image_id int,
  @dateTr DateTime,
  @lFullDelete bit

AS

declare @train_id int

select @train_id = train_id from m_Trains where image_id = @image_id and train_num = @train_num and dateTr = @dateTr
if not @train_id is NULL 
  exec sp_DeleteTrainById @train_id, @lFullDelete










