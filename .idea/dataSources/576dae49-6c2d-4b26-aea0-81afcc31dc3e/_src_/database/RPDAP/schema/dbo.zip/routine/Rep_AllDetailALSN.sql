
CREATE PROCEDURE [dbo].[Rep_AllDetailALSN]
@idTrain int
AS
select tr_id,vCode,xLen,tLen,sName,pkBegin,aValue1,aValue2,aValue6
from m_Violation mV
left join ci_ViolationType ciV on ciV.idV = mV.v_id
Where tr_id = @idTrain and vCode between 220 and 227
order by sName,xLen
