

-------------------------------------------------------

CREATE PROCEDURE [dbo].[Rep_ItogTxt]
@dtStart DateTime,
@dtFinish DateTime,
@idTch int,
@YdKoof int,
@type_energloc char(1),
@IsHoz int = -1,
@IsStupidDriver int = -1
AS
declare @CountTr int, @RunCommon float, @RunAuto float, @RunPrompt float,
@TimeCommon float, @TimeMove float, @TimeStop float, @Work Float,
@ESum float, @Fuel_kg int,@FreeFuel_kg int, @M_Fuel_kg int,@MFreeFuel_kg int, @EHeat float, @EHelp float,@FreeEHelpYd float,
@ESumSpec float,@TFuel_Spec float,@TMFuel_Spec float, @EHelpSpec float,@ERecup float, @Norma float, @VUch float,
@VTex float, @AvgWeight float, @AvgLen float, @СountCLim  int,  @AvgCountCLim float, @CountTLim int, @LenAllTlim float,
@AvgCountTLim float,@CTimeCommon char(20), @CTimeAuto char(20), @CTimeStop char(20), @I int,
@SumWeight float, @SumAxel int, @AvgAxelWeight float, @EManevr float, @StopCount int, @FreeESumYd float,
@FreetrWork float, @FreeESumYd_M float

select @countTr = count(*),
@runCommon = sum(x_Common), @runAuto = sum(x_SavpeAuto), @runPrompt = sum(x_SavpePrompt),
@timeCommon = sum(train_time), @timeMove = sum(train_time_move),@timeStop = sum(train_time)-sum(train_time_move),
@Work = sum(trWork), @ESum = sum(ESum), @Fuel_kg = sum(TFuel_kg),
@EHeat = sum(EHeat),@EHelp= sum(EHelp),@ERecup= sum(ERecup),
@FreeEHelpYd = sum(CASE WHEN DrawSpec > @YdKoof THEN EHelp ELSE 0  END),
@FreetrWork = sum(CASE WHEN DrawSpec > @YdKoof THEN trWork ELSE 0  END),
@FreeESumYd = sum(CASE WHEN DrawSpec > @YdKoof THEN ESum ELSE 0  END),
@FreeFuel_kg = sum(CASE WHEN DrawSpec > @YdKoof THEN TFuel_kg ELSE 0  END),
@СountCLim = sum(countCLim),
@countTLim = sum(countTLim),
@Norma = sum(Norma),
@lenAllTlim = sum(LengthTLim) ,
@sumWeight = sum(weight), @sumAxel = sum(VagsCount),
@StopCount = sum(stopCount)
from m_Trains
inner join m_TrainsInfo on m_TrainsInfo.train_id = m_Trains.train_id and m_Trains.id_tch = isnull(@idtch,m_Trains.id_tch)
inner join ci_Locomotiv on ci_Locomotiv.loc_id = m_TrainsInfo.loc_id
inner join ci_LocType on ci_LocType.type_id = ci_Locomotiv.loc_type
inner join ci_Drivers on ci_Drivers.drv_id = m_Trains.drv_id --
left join V_ALLCountViol on V_ALLCountViol.tr_id = m_Trains.train_id
where dateTr between @dtStart and @dtFinish and ci_LocType.type_loc = @type_energloc and m_Trains.train_num <> 9999
and(m_TrainsInfo.weight<>0)and(m_TrainsInfo.x_common<>0)
and ((@IsHoz = -1) or
(m_Trains.train_num in (select n_train from ci_HozTrain) and @IsHoz = 1) or
(not m_Trains.train_num in (select n_train from ci_HozTrain) and @IsHoz = 0)
)
and ((@IsStupidDriver = -1) or
(ci_Drivers.tb_num in (select tb_num from ci_StupidDriver) and @IsStupidDriver = 1) or
(not ci_Drivers.tb_num in (select tb_num from ci_StupidDriver) and @IsStupidDriver = 0)
)

select @EManevr=sum(ESum),@M_Fuel_kg=sum(TFuel_kg),
@FreeESumYd_M = sum(CASE WHEN DrawSpec > @YdKoof THEN ESum ELSE 0  END),
@MFreeFuel_kg=sum(CASE WHEN DrawSpec > @YdKoof THEN TFuel_kg ELSE 0  END)
from m_Trains
inner join m_TrainsInfo on m_TrainsInfo.train_id = m_Trains.train_id and m_Trains.id_tch = isnull(@idtch,m_Trains.id_tch)
inner join ci_Locomotiv on ci_Locomotiv.loc_id = m_TrainsInfo.loc_id
inner join ci_LocType on ci_LocType.type_id = ci_Locomotiv.loc_type
where dateTr between @dtStart and @dtFinish and ci_LocType.type_loc = @type_energloc and m_Trains.train_num=9999


exec sp_SecInHHMMSS @timeCommon, @cTimeCommon output
exec sp_SecInHHMMSS @timeStop, @cTimeStop output

/********************************** расчёт удельной ***********************************/
if @FreetrWork<>0 /*если поездная работа не нулевая*/
begin
set @EHelpSpec=@FreeEHelpYd*1.0/@FreetrWork  /*удельный по тяги без маневрушек*/
set @ESumSpec=(@FreeESumYd+@FreeESumYd_M)*1.0/@FreetrWork  /*Общий удельный включая маневр*/
set @TFuel_Spec=@FreeFuel_kg*1.0/@FreetrWork  /*удельный по тяги без маневрушек тепловоз*/
set @TMFuel_Spec =(@FreeFuel_kg+@MFreeFuel_kg)*1.0/@FreetrWork  /*Общий удельный включая маневр тепловоз*/
end
else begin set @EHelpSpec=0 set @ESumSpec=0 set @TFuel_Spec=0 set @TMFuel_Spec=0 end

if @timecommon<>0   /*участковая скорость*/
set @vUch = @runCommon*3600/@timecommon
else set @vUch =0

if @timeMove<>0     /*техн. скорость*/
set @vTex = @runCommon*3600/@timeMove
else
set  @vTex =0

if @CountTr<>0    /*ср. вес и составность*/
begin
set @avgWeight =@sumWeight/@CountTr
set @avgLen=@SumAxel/@CountTr
end
else
begin
set @avgWeight =0
set @avgLen =0
end

set @sumAxel=@sumAxel*4
if @sumAxel = 0    /*ср.нагрузка на ось*/
set @avgAxelWeight = 0.0
else
set @avgAxelWeight = @sumWeight/@sumAxel

if   @countTr<>0  /*пост.огран.*/
set  @avgCountCLim=1.0*@СountCLim/@countTr
else
set  @avgCountCLim=0

if  @countTr<>0  /*врем.огран.*/
set @avgCountTLim=1.0*@countTLim/@countTr
else
set @avgCountTLim=0

set @lenAllTlim =@lenAllTlim/1000

select   0 as iid, -1,'Эксплуатационные показатели',' ','o' union
select  10 as iid, 0,'Проведённых поездов', LTrim(str(@countTr,10)),'o' union
select  20 as iid, 0,'Поездной пробег, км', LTrim(str(@runCommon,15,2)),'o' union
select  30 as iid, 1,'Пробег в автоведении, км', LTrim(str(@runAuto,15,2))+' ('+LTrim(str(100.0*@runAuto/@runCommon,7,2))+'%)','o' union
select  31 as iid, 1,'Пробег в режиме подсказки, км', LTrim(str(@runPrompt,15,2))+' ('+LTrim(str(100.0*@runPrompt/@runCommon,7,2))+'%)','o' union
select  40 as iid, 0,'Общее время работы', @cTimeCommon,'o' union
select  70 as iid, 0,'Суммарная поездная работа, тКм * 10000', LTrim(str(@Work,15,2)),'o' union
select  80 as iid, 0,'Участковая скорость, км/ч', LTrim(str(@vUch,15,1)),'o' union
select  90 as iid, 0,'Техническая скорость, км/ч', LTrim(str(@vTex,15,1)),'o' union
select 100 as iid, 0,'Средняя масса состава, т', LTrim(str(@avgWeight,15,1)),'o' union
select 110 as iid, 0,'Средняя составность, ваг', LTrim(str(@avgLen,15,1)),'o' union
select 111 as iid, 0,'Средняя нагрузка на ось, т', LTrim(str(@avgAxelWeight,15,1)),'o' union
select 115 as iid, 0,'Количество неграфиковых остановок',LTrim(str(@StopCount)),'o' union
/*********************** Энергитические показатели **********************/
/*Електро Тяга*/
select 120 as iid, -1,'Энергетические показатели',' ','e' where @type_energloc='e' union
select 122 as iid, 0,'Общий расход энергии включая манёвр,кВтч', LTrim(str(@ESum+@EManevr,15,1)),'e' where @type_energloc='e' union
select 124 as iid, 0,'Общий удельный расход включая манёвр,кВтч/10000ткм', LTrim(str(@ESumSpec,15,1)),'e' where @type_energloc='e' union
select 125 as iid, 0,'Расход энергии на тягу без учёта манёвра,кВтч', LTrim(str(@EHelp,15,1)),'e' where @type_energloc='e' union
select 130 as iid, 0,'Удельный расход на тягу без учёта манёвра,кВтч/10000ткм', LTrim(str(@EHelpSpec,15,1)),'e' where @type_energloc='e' union
select 140 as iid, 0,'Энергия на отопление без учёта манёвра,кВтч', LTrim(str(@EHeat,15,1)),'e' where @type_energloc='e' union
select 150 as iid, 0,'Рекуперация без учёта манёвра,кВтч', LTrim(str(@ERecup,15,1)),'e' where @type_energloc='e' union
select 155 as iid, 0,'Общий расход энергии на маневровые работы,кВтч', LTrim(str(@EManevr,15,1)),'e' where @type_energloc='e' union
select 160 as iid, 0,'Норма расхода энергии, кВтч', LTrim(str(@Norma,15,1)),'e' where @type_energloc='e' union
/*Тепло тяга*/
select 161 as iid, -1,'Топливные показатели',' ','t' where @type_energloc='t' union
select 162 as iid, 0,'Общий расход включая манёвр,кг', LTrim(str(@Fuel_kg+@M_Fuel_kg)),'t' where @type_energloc='t' union
select 163 as iid, 0,'Общий удельный расход включая манёвр,кг/10000ткм', LTrim(str(@TMFuel_Spec,15,1)),'t' where @type_energloc='t' union
select 164 as iid, 0,'Расход на тягу без учёта манёвра,кг', LTrim(str(@Fuel_kg)),'t' where @type_energloc='t' union
select 165 as iid, 0,'Удельный расход на тягу без учёта манёвра,кг/10000ткм', LTrim(str(@TFuel_Spec,15,1)),'t' where @type_energloc='t' union
select 166 as iid, 0,'Общий расход на маневровые работы,кг', LTrim(str(@M_Fuel_kg)),'t' where @type_energloc='t' union
select 167 as iid, 0,'Норма расхода топлива, кг', LTrim(str(@Norma,15,1)),'t' where @type_energloc='t' union
select 168 as iid, 3,'','','t' where @type_energloc='t' union
select 169 as iid, 3,'','','t' where @type_energloc='t' union
/************************************************************************/
select 170 as iid, -1,'Ограничения скорости',' ','o' union
select 180 as iid, 0,'Общее количество постоянных ограничений', LTrim(str(@СountCLim,8)),'o' union
select 200 as iid, 1,' - среднее количество на маршрут', LTrim(str(@avgCountCLim,15,1)),'o' union
select 210 as iid, 0,'Общее количество предупреждений', LTrim(str(@countTLim,8)),'o' union
select 220 as iid, 1,'Суммарная протяженность, км', LTrim(str(@lenAllTlim,15,1)),'o' union
select 230 as iid, 1,' - среднее количество на маршрут', LTrim(str(@avgCountTLim,15,1)),'o'
order by iid

if exists (select * from dbo.sysobjects
where id = object_id(N'[dbo].[sp_AddInfoUserQuery]') and
OBJECTPROPERTY(id, N'IsProcedure') = 1)
exec sp_AddInfoUserQuery @dtStart, @dtFinish, -1, 'итоговый отчет'
