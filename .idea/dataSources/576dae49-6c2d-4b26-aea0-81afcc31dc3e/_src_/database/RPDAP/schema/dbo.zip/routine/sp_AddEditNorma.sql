











/*****************************************************************
-- Автор:	Сираджи Р.Ф. 
-- Описание:	Добавляет/обновляет уд.норму по выбранному плечу
*****************************************************************/
CREATE PROCEDURE sp_AddEditNorma
/*  @ss_id int,*/
  @NameShoulder char(50),
 @TName char(15),
  @NTrain int,
  @idNormaTo int,   -- если >0, то изменить интервал этой нормы, else - добавить новый интервал норм
  @idNormaFrom int, -- для нового интервала инициализировать норму из : <0 - из значений по умолчанию, else - из нормы с id_Norma = @idNormaFrom
  @dtFrom DateTime, 
  @dtTo DateTime
 


AS
/**/
declare @zDateFrom DateTime, @zDateTo DateTime, @idNorma int, @idNormaMin int, @idNormaMax int,
	@norma  float

if not exists(select * from ci_Norma where bDefault = 1)
	exec sp_InitSSByDefNorma -1

if @idNormaTo > 0 set @idNorma = @idNormaTo
else begin
	if @idNormaFrom >= 0 set @idNorma = @idNormaFrom
	else select @idNorma = id_Norma from ci_Norma where bDefault = 1
end

select @norma =Rate from ci_Norma where id_Norma = @idNorma 

--удаляю интервалы лежащие внутри нового интервала
delete from ci_Norma where NameShoulder= @NameShoulder and dtBegin >= @dtFrom and dtEnd <= @dtTo and NTrain=@NTrain and TypeName=@TName
--нахожу интервал (A) снизу с ближайшим началом 
select @idNormaMin = id_Norma, @zDateFrom = dtBegin, @zDateTo = dtEnd from ci_Norma where NameShoulder = @NameShoulder and NTrain=@NTrain and TypeName=@TName
	and dtBegin = (select max(dtBegin) from ci_Norma where  NameShoulder= @NameShoulder and dtBegin < @dtFrom  and NTrain=@NTrain)
--устанавливаю конец интервала A = началу нового
update ci_Norma set dtEnd = @dtFrom - 1 where id_Norma = @idNormaMin

if @zDateTo > @dtTo
--если конец интервала A был дальше конца нового интервала, то остаток добавляю сверху отдельным интервалом
	insert into ci_Norma (bDefault, ss_id, NameShoulder,TypeName,NTrain,dtBegin, dtEnd, Rate)
		select 0,0,  @NameShoulder,@TName,@NTrain,@dtTo + 1, @zDateTo, Rate
		from ci_Norma where id_Norma = @idNormaMin
else begin	 
	--нахожу интервал (A) сверху с ближайшим началом 
	select @idNormaMax = id_Norma, @zDateFrom = dtBegin, @zDateTo = dtEnd from ci_Norma where  NameShoulder=@NameShoulder and NTrain=@NTrain and TypeName=@TName
		and dtBegin = (select min(dtBegin) from ci_Norma where  NameShoulder= @NameShoulder and dtBegin >= @dtFrom and NTrain=@NTrain)
	if @idNormaMax is not NULL
		update ci_Norma set dtBegin = @dtTo + 1 where id_Norma = @idNormaMax
end

insert into ci_Norma (bDefault, ss_id,  NameShoulder,Typename,NTrain,dtBegin, dtEnd, Rate) 
Values(0,0,@NameShoulder,@TName,@NTrain, @dtFrom, @dtTo, @Norma)










