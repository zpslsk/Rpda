-- ======================================================
-- Author:      < mosian >
-- Version:     < 3.6 >
-- Description:	< Удаление машиниста и всё что связанно с ним по id >
-- ======================================================
Create PROCEDURE [dbo].[sp_DeleteBy_Driver] 
@id_driver int
 AS
DECLARE @train_id int,@image_id int,@Count_trid int,@Count_idim int
DECLARE @Table_Train_id CURSOR

Set @Count_trid = 0;
Set @Count_idim = 0;
   --Выборка Id поездок по id машиниста
   Set @Table_Train_id = CURSOR SCROLL FOR SELECT train_id from m_Trains Where drv_id = @id_driver
   --Открываем курсор--------------------------------
   OPEN @Table_Train_id;
   --Берём первую строку курсора---------------------
   FETCH NEXT FROM @Table_Train_id INTO @train_id;
   WHILE @@FETCH_STATUS = 0 
    begin
      EXEC sp_DeleteTrainById @train_id,1;
      Set @Count_trid = @Count_trid+1;
      FETCH NEXT FROM @Table_Train_id INTO @train_id;
    end;
   --Закрываем курсор--------------------------------
   CLOSE @Table_Train_id;
   DELETE from ci_Drivers where drv_id = @id_driver; /* Удаляем машиниста */
   --Выборка всех имеджей без поездок----------------
   Set @Table_Train_id = CURSOR SCROLL FOR SELECT x.id_image from m_XFiles x
                                            Left join m_Trains t on x.id_image = t.image_id
                                            Where t.image_id is Null
   OPEN @Table_Train_id;
   FETCH NEXT FROM @Table_Train_id INTO @image_id;
   WHILE @@FETCH_STATUS = 0 
    begin
      EXEC sp_DeleteExtImageInfo @image_id;
      DELETE from m_XFiles where Id_Image = @image_id;
      Set @Count_idim = @Count_idim+1;
      FETCH NEXT FROM @Table_Train_id INTO @image_id;
    end;
   CLOSE @Table_Train_id;
   DEALLOCATE @Table_Train_id;
 -------- Выводим кол-во удалённых обьектов -------
 Select @Count_trid as C_trid,@Count_idim as C_imid
