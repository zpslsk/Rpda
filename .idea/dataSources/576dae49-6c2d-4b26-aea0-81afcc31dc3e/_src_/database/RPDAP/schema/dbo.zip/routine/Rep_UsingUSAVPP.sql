

/*****************************************************************
-- Описание:	Возвращает данные о работе УСАВПГ за следующие интервалы :
--	Текущий месяц, Тот же месяц Прошлого года, С начала Текущего года, С начала Прошлого года
*****************************************************************/
CREATE PROCEDURE Rep_UsingUSAVPP
@dtNow DateTime,
@idtch int
AS

set nocount on

declare @dtBegin DateTime, @dtEnd DateTime, @dtTemp DateTime, @i int, @n int, @nRow int,
@aWork float, @ESum1 float, @ERecup1 float,  @aUdRasxod float, @aEconomy float, 
@Norma float, @x_Regim float, @t_Regim int,
@SRes1 varchar(1000), @SRes2 varchar(1000), @SRes3 varchar(1000), @sText char(100)

--set @dtNow = '2005-03-31'
if cast(@dtNow as int) > @dtNow set @dtNow = cast(@dtNow as int)-1
else set @dtNow = cast(@dtNow as int)

select @SRes1 = '', @SRes2 = '', @SRes3 = ''
set @n = day(@dtNow) - 1
set @dtTemp = DATEADD(Day, -@n , @dtNow)

set @i = 1
while @i < 5 begin
if @i = 1 begin
--Текущий месяц
set @dtBegin = @dtTemp
set @dtEnd = @dtNow
end
else if @i = 2 begin
--Тот же месяц Прошлого года
set @dtBegin = DATEADD(Year, -1, @dtTemp)
set @dtEnd = DATEADD(Year, -1, @dtNow)
end
else if @i = 3 begin
--С начала Текущего года
set @n = month(@dtTemp) - 1
set @dtTemp = DATEADD(Month, -@n , @dtTemp)
set @dtBegin = @dtTemp
set @dtEnd = @dtNow
end
else if @i = 4 begin
--С начала Прошлого года
set @dtBegin = DATEADD(Year, -1, @dtTemp)
set @dtEnd = DATEADD(Year, -1, @dtNow)
end
set @dtEnd = @dtEnd + 1 - 0.00001

/************************************************************************************************************************/
select @ESum1= IsNull(sum(m_TrainsInfo.ESum), 0)
from m_Trains
inner join m_TrainsInfo on m_TrainsInfo.train_id = m_Trains.train_id and m_Trains.id_tch=@idtch
inner join ci_Locomotiv on ci_Locomotiv.loc_id = m_TrainsInfo.loc_id 
where dateTr between @dtBegin and @dtEnd  and   m_Trains.train_num<>9999

select @ERecup1=  isNull(sum(R.EAllRecup),0)
from m_RegimInfo R  inner join( m_TrainsInfo T inner join  m_Trains MT on T.train_id =MT.train_id)
on T.train_id=R.IdTrain 
inner join ci_Locomotiv on ci_Locomotiv.loc_id = T.loc_id
where MT.id_tch=@idtch and  aDate between @dtBegin and @dtEnd  and IdTrain is not null  and (MT.train_num<>9999)


select @SRes1 = @SRes1 + str(isNull(sum(0.001*x_Regim),0),15,3) + str(isNull(sum(0.1*t_Regim/360),0),15,3)
from m_RegimInfo R inner join( m_TrainsInfo T inner join  m_Trains MT on T.train_id =MT.train_id)
on T.train_id=R.IdTrain
where MT.id_tch=@idtch and aDate between @dtBegin and @dtEnd and IdTrain is not null   and (MT.train_num<>9999)

set @SRes1 = @SRes1 + str( @ESum1, 15, 3) + str(@ERecup1, 15, 3)

--УСАВПП в режиме подсказки
select @x_Regim = isNull(sum(0.001*x_Regim),0), @t_Regim = isNull(sum(0.1*t_Regim/360),0),
@ESum1 = isNull(sum(EAllSum),0),
@ERecup1 = isNull(sum(EAllRecup),0),
@aWork = isNull(sum(0.001*x_Regim * weight /1000), 0),
@Norma = isNull(sum(Norma * (0.001*x_Regim / x_Common)), 0)
from m_RegimInfo R inner join(m_TrainsInfo T inner join m_trains MT on T.train_id=MT.train_id)
on T.train_id = R.idTrain 
where  MT.id_tch=@idtch and (aDate between @dtBegin and @dtEnd)and (RegimType<>0) and IdTrain is not null and (MT.train_num<>9999)and( x_Common>0)



select @ERecup1 =  isNull(sum(R.EAllRecup),0)
from m_RegimInfo R inner join ( m_TrainsInfo T inner join m_trains MT on T.train_id=MT.train_id)
on T.train_id = R.IdTrain
inner join ci_Locomotiv on ci_Locomotiv.loc_id = T.loc_id
where MT.id_tch=@idtch and aDate between @dtBegin and @dtEnd and (RegimType <>0) and IdTrain is not null and (MT.train_num<>9999)

/************************************************************************************************************************/

if @aWork = 0 set @aUdRasxod = 0  else set @aUdRasxod = (@ESum1 * 10) / @aWork
if @Norma = 0 set @aEconomy = 0  else set @aEconomy = (@ESum1- @Norma) / @Norma * 100
set @SRes2 = @SRes2 + str(@x_Regim,15,3) + str(@t_Regim,15,3) + str(@aWork,15,3)+
str(@ESum1,15,3) + str(@ERecup1,15,3) +
str(@aUdRasxod,15,3) + str(@Norma,15,3) + str(@aEconomy,15,3)

--УСАВПП в режиме автоведения
select @x_Regim = isNull(sum(0.001*x_Regim),0), @t_Regim = isNull(sum(0.1*t_Regim/360),0),
@ESum1= isNull(sum(EAllSum),0), @ERecup1= isNull(sum(EAllRecup),0),
@aWork = isNull(sum(0.001*x_Regim * weight /1000), 0),
@Norma = isNull(sum(Norma * (0.001*x_Regim / x_Common)), 0)
/*from m_RegimInfo R inner join m_TrainsInfo T on T.train_id = R.idTrain*/
from m_RegimInfo R inner join(m_TrainsInfo T inner join m_trains MT on T.train_id=MT.train_id)
on T.train_id = R.idTrain 
where MT.id_tch=@idtch and (aDate between @dtBegin and @dtEnd) and (RegimType =0) and (IdTrain is not null )and(MT.train_num<>9999)and( x_Common>0)

select @ERecup1=  isNull(sum(R.EAllRecup),0)
from m_RegimInfo  R inner join( m_TrainsInfo M inner join m_Trains MT on M.train_id=MT.train_id)
on M.train_id =R.IdTrain
inner join ci_Locomotiv on ci_Locomotiv.loc_id = M.loc_id
where MT.id_tch=@idtch and aDate between @dtBegin and @dtEnd and (RegimType =0) and IdTrain is not null and(MT.train_num<>9999)


if @aWork = 0 set @aUdRasxod = 0  else set @aUdRasxod = (@ESum1* 10) / @aWork
if @Norma = 0 set @aEconomy = 0  else set @aEconomy = (@ESum1- @Norma) / @Norma * 100
set @SRes3 = @SRes3 + str(@x_Regim,15,3) + str(@t_Regim,15,3) + str(@aWork,15,3) 
+ str(@ESum1,15,3) + str(@ERecup1,15,3)+
str(@aUdRasxod,15,3) + str(@Norma,15,3) + str(@aEconomy,15,3)

set @i = @i + 1
end
--print 'SRes1 : ' + @SRes1
--print 'SRes2 : ' + @SRes2
--print 'SRes3 : ' + @SRes3

create table #tmpUS (sText char(100), Param1 float, Param2 float, Param3 float, Param4 float)
select @i = 0, @nRow = 1
while @i < 4 begin
if @i = 0 set @sText = 'Пройденный путь, км'
else if @i = 1 set @sText = 'Затраченное время, час'
else if @i = 2 set @sText = 'Общий расход энергии, кВтч'
else if @i = 3 set @sText = 'Энергия рекуперации, кВтч'
insert into #tmpUS Values(@sText,
cast(SUBSTRING(@SRes1, @i*15+1, 15) as float), cast(SUBSTRING(@SRes1, @i*15+61, 15) as float),
cast(SUBSTRING(@SRes1, @i*15+121, 15) as float), cast(SUBSTRING(@SRes1, @i*15+181,15) as float))
select @nRow = @nRow + 1, @i = @i + 1
end

select * from #tmpUS
truncate table #tmpUS

set @n = 1
while @n < 3 begin
set @i = 0
if @n = 1 set @SRes1 = @SRes2  else set @SRes1 = @SRes3
while @i < 8 begin
if @i = 0 set @sText = 'Пройденный путь, км'
else if @i = 1 set @sText = 'Затраченное время, час'
else if @i = 2 set @sText = 'Работа, тКм * 10000'
else if @i = 3 set @sText = 'Общий расход энергии, кВтч'
else if @i = 4 set @sText = 'Энергия рекуперации, кВтч'
else if @i = 5 set @sText = 'Удельный расход энергии, кВтч х 10000 / т.км.бр'
else if @i = 6 set @sText = 'Норма расхода энергии, кВтч'
else set @sText = 'Отклонение от нормы расхода энергии, %'
insert into #tmpUS Values(@sText,
cast(SUBSTRING(@SRes1, @i*15+1, 15) as float), cast(SUBSTRING(@SRes1, @i*15+121, 15) as float),
cast(SUBSTRING(@SRes1, @i*15+241, 15) as float), cast(SUBSTRING(@SRes1, @i*15+361,15) as float))
select @nRow = @nRow + 1, @i = @i + 1
end
select * from #tmpUS
truncate table #tmpUS
set @n = @n + 1
end

drop table #tmpUS