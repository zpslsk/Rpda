


/*****************************************************************
-- Описание:	Возвращает данные о расходе электроэнергии на тягу и отопление поездов за следующие интервалы :
--	Текущий месяц, Тот же месяц Прошлого года, С начала Текущего года, С начала Прошлого года
*****************************************************************/
CREATE PROCEDURE [dbo].[Rep_RasxodEnergy]
@dtNow DateTime,
@idtch int,
@YdKoof int
AS

set nocount on

declare @dtBegin DateTime, @dtEnd DateTime, @dtTemp DateTime, @i int, @n int,
@aWork float, @aRasxod float, @aUdRasxod float, @aEconomy float, @aTexSpeed float, @aWeigth float, @aCntLim int, @aRecup float,
@nBrigPlus float, @nBrigMinus float, @aNorma float, @cnt int,
@SRes varchar(1000), @sText char(100),@FreeEHelpYd float, @FreetrWork float 

--set @dtNow = '2005-03-31'
set @dtNow = cast(@dtNow as int)

set @n = day(@dtNow) - 1
set @dtTemp = DATEADD(Day, -@n , @dtNow)

select @i = 1, @SRes = ''

while @i < 5 begin
if @i = 1 begin
--Текущий месяц
set @dtBegin = @dtTemp
set @dtEnd = @dtNow
end
else if @i = 2 begin
--Тот же месяц Прошлого года
set @dtBegin = DATEADD(Year, -1, @dtTemp)
set @dtEnd = DATEADD(Year, -1, @dtNow)
end
else if @i = 3 begin
--С начала Текущего года
set @n = month(@dtTemp) - 1
set @dtTemp = DATEADD(Month, -@n , @dtTemp)
set @dtBegin = @dtTemp
set @dtEnd = @dtNow
end
else if @i = 4 begin
--С начала Прошлого года
set @dtBegin = DATEADD(Year, -1, @dtTemp)
set @dtEnd = DATEADD(Year, -1, @dtNow)
end
set @dtEnd = @dtEnd + 1

--print cast(@dtBegin as char(20))+ ' - '+ cast(@dtEnd as char(20))

select @cnt = count(*), @aWork = sum(trWork), @aRasxod = sum(EHelp),
@FreeEHelpYd = sum(CASE WHEN DrawSpec > @YdKoof THEN EHelp ELSE 0  END),
@FreetrWork = sum(CASE WHEN DrawSpec > @YdKoof THEN trWork ELSE 0  END),
@aNorma = sum(Norma),
@aTexSpeed=case sum(train_time_move) when 0 then 0 else sum(x_Common) * 1000 / sum(train_time_move) * 3.6 end,
/*@aTexSpeed = sum(x_Common) * 1000 / sum(train_time_move) * 3.6, */
@aWeigth = avg(weight),
@aRecup = sum(ERecup),
@aCntLim = sum(countCLim)
from m_TrainsInfo inner join m_Trains on m_TrainsInfo.train_id = m_Trains.train_id and 
m_Trains.id_Tch=isnull(@idtch,m_Trains.id_Tch)
where dateTr between @dtBegin and @dtEnd and m_Trains.train_num<>9999


if @aWork > 0 
         set @aUdRasxod = (@aRasxod * 10000) / (@aWork * 1000)  
        else set @aUdRasxod = NULL

/********************************** расчёт удельной ***********************************/
if @FreetrWork<>0 /*если поездная работа не нулевая*/    
 set @aUdRasxod=@FreeEHelpYd*1.0/@FreetrWork  /*удельный по тяги без маневрушек*/
  else set @aUdRasxod = Null

if @aNorma > 0 
        set @aEconomy = (@aRasxod - @aNorma)/@aNorma * 100  
        else set @aEconomy = NULL
if @cnt > 0 begin
select @nBrigPlus = count(*)/@cnt * 100 from m_TrainsInfo inner join m_Trains on m_TrainsInfo.train_id = m_Trains.train_id and 
m_Trains.id_Tch=isnull(@idtch,m_Trains.id_Tch)
where (dateTr between @dtBegin and @dtEnd) and (EHelp < Norma) and (m_Trains.train_num<>9999)
select @nBrigMinus = count(*)/@cnt * 100 from m_TrainsInfo inner join m_Trains on m_TrainsInfo.train_id = m_Trains.train_id and
m_Trains.id_Tch=isnull(@idtch,m_Trains.id_Tch)
where (dateTr between @dtBegin and @dtEnd) and (EHelp > Norma)and (m_Trains.train_num<>9999)
end
                    else begin
            select @nBrigPlus = NULL, @nBrigMinus = NULL
                              end

set @SRes = @SRes + str(IsNull(@aWork, 0),15,3) + str(IsNull(@aRasxod, 0),15,3) + str(IsNull(@aUdRasxod, 0),15,3) +
str(IsNull(@aEconomy, 0),15,3) + str(IsNull(@aTexSpeed, 0),15,3) + str(IsNull(@aWeigth, 0),15,3) + str(IsNull(@aCntLim, 0),15,3) +
str(IsNull(@aRecup, 0),15,3) + str(IsNull(@nBrigPlus, 0),15,3) + str(IsNull(@nBrigMinus, 0),15,3)

set @i = @i + 1
end

create table #tmpEn (sText char(100), Param1 float, Param2 float, Param3 float, Param4 float)
set @i = 0
while @i < 10 begin
if @i = 0 set @sText = 'Фактический объем работы, тКм * 10000'
else if @i = 1 set @sText = 'Фактический расход электроэнергии, квтч'
else if @i = 2 set @sText = 'Удельный расход на тягу, Квт.ч/10 т.км, брутто'
else if @i = 3 set @sText = 'Экономия "-" , пережог "+"'
else if @i = 4 set @sText = 'Техническая скорость, км/ч'
else if @i = 5 set @sText = 'Средний вес поезда, т'
else if @i = 6 set @sText = 'Количество поездопредупреждений'
else if @i = 7 set @sText = 'Рекуперация, квт*ч'
else if @i = 8 set @sText = 'Количество бригад с экономией, %'
else set @sText = 'Количество бригад с пережогом, %'

insert into #tmpEn Values(@sText,
cast(SUBSTRING(@SRes, @i*15+1, 15) as float), cast(SUBSTRING(@SRes, @i*15+151, 15) as float),
cast(SUBSTRING(@SRes, @i*15+301, 15) as float), cast(SUBSTRING(@SRes, @i*15+451,15) as float))
set @i = @i + 1
end

select * from #tmpEn
drop table #tmpEn



