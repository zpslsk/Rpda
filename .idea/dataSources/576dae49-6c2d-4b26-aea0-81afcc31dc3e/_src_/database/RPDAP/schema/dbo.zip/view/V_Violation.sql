
CREATE VIEW [dbo].[V_Violation]
AS
select tr_id,
sum(case when ci_ViolationType.vCode = 226 then 1 else 0 end) stopCount,
sum(case when ci_ViolationType.vCode = 226 then aValue2 else 0 end) StopTime,
sum(case when ci_ViolationType.vCode = 225 then 1 else 0 end) VCount,
sum(case when ci_ViolationType.vCode = 225 then aValue1 else 0 end) VX,
sum(case when ci_ViolationType.vCode = 225 then aValue2 else 0 end) VTime,
sum(case when ci_ViolationType.vCode = 220 then 1 else 0 end) Count_G,
sum(case when ci_ViolationType.vCode = 221 then 1 else 0 end) Count_KG,
sum(case when ci_ViolationType.vCode = 222 then 1 else 0 end) Count_Z,
sum(case when ci_ViolationType.vCode = 223 then 1 else 0 end) Count_B,
sum(case when ci_ViolationType.vCode = 224 then 1 else 0 end) Count_K,
sum(CASE WHEN ci_ViolationType.vCode = 227 THEN 1 ELSE 0 END) AS stopCountInpLight,
sum(case when ci_ViolationType.vCode = 227 then aValue2 else 0 end) StopTimeInpLight
FROM m_Violation inner Join ci_ViolationType on m_Violation.v_id = ci_ViolationType.idv
WHERE ci_ViolationType.vCode in (220,221,222,223,224,225,226,227)
GROUP BY tr_id
