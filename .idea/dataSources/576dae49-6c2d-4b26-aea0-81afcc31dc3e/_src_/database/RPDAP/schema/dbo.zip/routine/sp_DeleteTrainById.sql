
CREATE PROCEDURE [dbo].[sp_DeleteTrainById]
@trainId int,
@lFullDelete bit
AS
delete from m_RegimInfo where idtrain = @trainId   /* Удаляем инф. о режимах автовед.*/
delete from m_Limits where train_id = @trainId     /* Удаляем инф. о пгронечениях скорости */
delete from m_TrainsInfo where train_id = @trainId /* Удаляем инф. о основных параметрах поездки */
delete from m_Violation where tr_id = @trainId     /* Удаляем инф. о диагностики */
delete from m_Schedule where Id_train = @trainId   /* Удаляем инф. о расписании */

if exists (select * from dbo.sysobjects
where id = object_id(N'[dbo].[m_tBlockState]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
delete from m_tBlockState where Id_train = @trainId

if exists (select * from dbo.sysobjects
where id = object_id(N'[dbo].[m_tParamState]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
delete from m_tParamState where Id_train = @trainId

if exists (select * from dbo.sysobjects
where id = object_id(N'[dbo].[m_PosCtrl]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
delete from m_PosCtrl where Id_train = @trainId

if @lFullDelete = 1
delete from m_Trains where train_id = @trainId    /* Удаляем инф. о поезде*/
