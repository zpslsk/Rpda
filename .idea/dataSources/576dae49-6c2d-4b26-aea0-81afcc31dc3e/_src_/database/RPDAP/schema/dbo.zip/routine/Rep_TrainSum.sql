
CREATE PROCEDURE [dbo].[Rep_TrainSum]
@nFilter int,
@dtStart DateTime,
@dtFinish DateTime,
@TypeTrain int,
@idtch int,
@ReadStart DateTime,
@ReadFinish DateTime,
@YdKoof int,
@type_energloc char(1),
@IsHoz int = -1,
@IsStupidDriver int = -1
AS
Select train_num, count(*)as cnt,
cast(sum(x_Common) as decimal(12,3)) as x_Common,
--cast(sum(x_CommonR) as decimal(12,3)) as x_CommonR,
cast(sum( CASE WHEN x_CommonR < 999999 THEN x_CommonR ELSE 1  END )as decimal(12,1))as x_CommonR,
cast(sum(x_SavpeAuto) as decimal(12,3)) as x_Auto,
cast(sum(x_SavpePrompt)as decimal(12,3)) as x_Prompt,
cast(sum(trWork)as decimal(15,1)) as trWork,
cast(sum(CASE WHEN DrawSpec > @YdKoof THEN EHelp ELSE 0  END) as decimal(12,2))as free_EHelp,
cast(sum(CASE WHEN DrawSpec > @YdKoof THEN trWork ELSE 0  END) as decimal(12,2))as free_trWork,
sum(CASE WHEN DrawSpec > @YdKoof THEN TFuel_kg ELSE 0 END) as Free_SFuel_kg,
sum(TFuel_l)as SFuel_l,
sum(TFuel_kg)as SFuel_kg,
sum(train_time) as train_time,
sum(train_time_move) as  train_time_move,
sum(time_R) as time_R,
sum(1) as time_moveR,
cast(sum(ESum)as decimal(12,1))as ESum,
cast(sum(EHelp)as decimal(12,1))as EHelp,
cast(sum(EHeat)as decimal(12,1))as EHeat,
cast(sum(ERecup)as decimal(12,1))as ERecup,
cast(sum(E1B1)as decimal(12,1))as E1B1,
cast(sum(E1B2)as decimal(12,1))as E1B2,
cast(sum(E2B1)as decimal(12,1))as E2B1,
cast(sum(E2B2)as decimal(12,1))as E2B2,
cast(sum(DrawSpec)as decimal(12,1))as DrawSpec,
sum(countTLim) as countTLim,

--cast(avg(R_)as decimal(12,1))as R_,
(
Select cast(avg(R_)as decimal(12,1))
from m_Trains tr1
inner join m_TrainsInfo ti1 on ti1.train_id = tr1.train_id
inner join ci_Locomotiv loc1 on loc1.loc_id = ti1.loc_id
inner join ci_LocType lt1 on lt1.type_id = loc1.loc_type
inner join ci_Drivers dr1 on dr1.drv_id = tr1.drv_id
left join m_XFiles xf1 on xf1.id_image = tr1.image_id
where tr1.train_num = a.train_num
and ti1.R_ > 3 and ti1.R_ < 100
and dateTr between @dtStart and @dtFinish
and ((@IsHoz = -1) or
(tr1.train_num in (select n_train from ci_HozTrain) and @IsHoz = 1) or
(not tr1.train_num in (select n_train from ci_HozTrain) and @IsHoz = 0)
)
and ((@IsStupidDriver = -1) or
(dr1.tb_num in (select tb_num from ci_StupidDriver) and @IsStupidDriver = 1) or
(not dr1.tb_num in (select tb_num from ci_StupidDriver) and @IsStupidDriver = 0)
)
) as R_,

--cast(avg(IVen_)as decimal(12,1))as IVen_,
(
Select cast(avg(IVen_)as decimal(12,1))
from m_Trains tr1
inner join m_TrainsInfo ti1 on ti1.train_id = tr1.train_id
inner join ci_Locomotiv loc1 on loc1.loc_id = ti1.loc_id
inner join ci_LocType lt1 on lt1.type_id = loc1.loc_type
inner join ci_Drivers dr1 on dr1.drv_id = tr1.drv_id
left join m_XFiles xf1 on xf1.id_image = tr1.image_id
where tr1.train_num = a.train_num
and ti1.IVen_ > 5 and ti1.IVen_ < 100
and dateTr between @dtStart and @dtFinish
and ((@IsHoz = -1) or
(tr1.train_num in (select n_train from ci_HozTrain) and @IsHoz = 1) or
(not tr1.train_num in (select n_train from ci_HozTrain) and @IsHoz = 0)
)
and ((@IsStupidDriver = -1) or
(dr1.tb_num in (select tb_num from ci_StupidDriver) and @IsStupidDriver = 1) or
(not dr1.tb_num in (select tb_num from ci_StupidDriver) and @IsStupidDriver = 0)
)
) as IVen_,

--cast(avg(Ikom_)as decimal(12,1))as Ikom_,
(
Select cast(avg(Ikom_)as decimal(12,1))
from m_Trains tr1
inner join m_TrainsInfo ti1 on ti1.train_id = tr1.train_id
inner join ci_Locomotiv loc1 on loc1.loc_id = ti1.loc_id
inner join ci_LocType lt1 on lt1.type_id = loc1.loc_type
inner join ci_Drivers dr1 on dr1.drv_id = tr1.drv_id
left join m_XFiles xf1 on xf1.id_image = tr1.image_id
where tr1.train_num = a.train_num
and ti1.Ikom_ > 5 and ti1.Ikom_ < 100
and dateTr between @dtStart and @dtFinish
and ((@IsHoz = -1) or
(tr1.train_num in (select n_train from ci_HozTrain) and @IsHoz = 1) or
(not tr1.train_num in (select n_train from ci_HozTrain) and @IsHoz = 0)
)
and ((@IsStupidDriver = -1) or
(dr1.tb_num in (select tb_num from ci_StupidDriver) and @IsStupidDriver = 1) or
(not dr1.tb_num in (select tb_num from ci_StupidDriver) and @IsStupidDriver = 0)
)
) as Ikom_,

--cast(avg(Ivsp_)as decimal(12,1))as Ivsp_
(
Select cast(avg(Ivsp_)as decimal(12,1))
from m_Trains tr1
inner join m_TrainsInfo ti1 on ti1.train_id = tr1.train_id
inner join ci_Locomotiv loc1 on loc1.loc_id = ti1.loc_id
inner join ci_LocType lt1 on lt1.type_id = loc1.loc_type
inner join ci_Drivers dr1 on dr1.drv_id = tr1.drv_id
left join m_XFiles xf1 on xf1.id_image = tr1.image_id
where tr1.train_num = a.train_num
and ti1.Ivsp_ > 5 and ti1.Ivsp_ < 100
and dateTr between @dtStart and @dtFinish
and ((@IsHoz = -1) or
(tr1.train_num in (select n_train from ci_HozTrain) and @IsHoz = 1) or
(not tr1.train_num in (select n_train from ci_HozTrain) and @IsHoz = 0)
)
and ((@IsStupidDriver = -1) or
(dr1.tb_num in (select tb_num from ci_StupidDriver) and @IsStupidDriver = 1) or
(not dr1.tb_num in (select tb_num from ci_StupidDriver) and @IsStupidDriver = 0)
)
) as Ivsp_,
SUM(RBrake) AS RBrake, SUM(NormaEn) AS NormaEn

from m_Trains a
inner join m_TrainsInfo b on b.train_id = a.train_id and a.id_tch=isnull(@idtch,a.id_tch)
inner join ci_Locomotiv loc on loc.loc_id = b.loc_id
inner join ci_LocType on ci_LocType.type_id = loc.loc_type
inner join ci_Drivers on ci_Drivers.drv_id = a.drv_id --
left join m_XFiles on m_XFiles.id_image = a.image_id
where ci_LocType.type_loc = @type_energloc and
dateTr between isnull(@dtStart,dateTr) and isnull(@dtFinish,dateTr) and
DataFirstRead between isnull(@ReadStart,DataFirstRead) and isnull(@ReadFinish,DataFirstRead)
and loc.loc_type =  isnull(@TypeTrain,loc.loc_type)
and ((@IsHoz = -1) or
(a.train_num in (select n_train from ci_HozTrain) and @IsHoz = 1) or
(not a.train_num in (select n_train from ci_HozTrain) and @IsHoz = 0)
)
and ((@IsStupidDriver = -1) or
(ci_Drivers.tb_num in (select tb_num from ci_StupidDriver) and @IsStupidDriver = 1) or
(not ci_Drivers.tb_num in (select tb_num from ci_StupidDriver) and @IsStupidDriver = 0)
)

group by train_num
order by train_num

if exists (select * from dbo.sysobjects
where id = object_id(N'[dbo].[sp_AddInfoUserQuery]') and
OBJECTPROPERTY(id, N'IsProcedure') = 1)
begin
if @type_energloc = 't' set @TypeTrain = 118;
exec sp_AddInfoUserQuery @dtStart, @dtFinish, @TypeTrain, 'отчет по поездам'
end
