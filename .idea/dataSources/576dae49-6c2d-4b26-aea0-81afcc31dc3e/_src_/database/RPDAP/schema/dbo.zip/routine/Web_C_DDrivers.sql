
CREATE PROCEDURE [dbo].[Web_C_DDrivers]
@driv_id int,
@dtStart DateTime,
@dtFinish DateTime,
@TypeTrain int,
@idtch int
AS

Select Count(m_Trains.drv_id)as [count]
from m_Trains
inner join m_TrainsInfo on m_TrainsInfo.train_id = m_Trains.train_id and m_Trains.id_tch=@idtch
inner join ci_Drivers on ci_Drivers.drv_id = m_Trains.drv_id
inner join ci_Locomotiv on ci_Locomotiv.loc_id = m_TrainsInfo.loc_id
where m_Trains.drv_id = @driv_id and dateTr between @dtStart and @dtFinish 
and ci_Locomotiv.loc_type =  isnull(@TypeTrain,ci_Locomotiv.loc_type) and m_Trains.train_num<>9999
Group by m_Trains.drv_id

