





CREATE PROCEDURE sp_WriteError 
  @iLevelError int,
  @idImage int,
  @ordError int,
  @sTextError varchar(250)

AS

  declare @id int
  select @id = idErr from z_ListError where ErrText = @sTextError
  if @id is NULL begin
    insert into z_ListError (ErrText) Values(@sTextError)
    select @id = @@IDENTITY
  end

  if not exists(select idErr from z_ReadError where idImage = @idImage and ErrCode = @id) 
    insert into z_ReadError (idImage, ordErr, ErrLevel, ErrCode) Values(@idImage, @ordError, @iLevelError, @id) 



