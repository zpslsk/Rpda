-- =============================================
-- Description:	<Проверяем есть ли такой лок. если нет то добавляем его>
-- =============================================
Create PROCEDURE [dbo].[sp_Add_ci_Locomotiv]
@idtch int,
@numLoc int,
@CodLoc int,
@NameDepo int,
@CodeDepo int,
@sec_count int
AS
Declare
@idLoc int,
@id_LocType int
SET NOCOUNT ON;
Select @id_LocType = type_id From ci_LocType where type_code = @CodLoc
if @id_LocType is not null -- Если в справочнике такой тип локомотива есть 
 begin
   Select Top 1 @idLoc=loc.loc_id
   from ci_Locomotiv loc 
   inner join m_TrainsInfo tri on loc.loc_id = tri.loc_id
   inner join m_Trains tr on tr.train_id = tri.train_id and tr.id_tch=@idtch
   Where loc.loc_type = @id_LocType and loc.loc_num = @numLoc
   if @idLoc is null --Если такого локоматива есщё нет 
    begin
      Insert into ci_Locomotiv (loc_type,NameDepo,CodeDepo,sec_count,loc_num)
      Values(@id_LocType,@NameDepo,@CodeDepo,@sec_count,@numLoc)
      select @@IDENTITY 
    end Select @idLoc 
 end else Select -1
