
CREATE PROCEDURE [dbo].[Rep_DetailALSN]
@nFilter int,
@train_num int,
@dtStart DateTime,
@dtFinish DateTime,
@TypeTrain int,
@idtch int
AS
Select m_Trains.train_id, train_num,convert(char(10),dateTr,101)+' '+convert(char(8),dateTr,108) as dateTr,
tb_num, RTRIM(surname) + ' ' + Left([name],1) + ' ' + Left(patronymic,1) as FIO,
[type_name], loc_num,time_moveR, time_R,x_CommonR, train_time,VagsCount,Weight,av_speed,
cast(x_Common as decimal(12,3)) as x_Common, cast(x_SavpeAuto as decimal(12,3)) as x_Auto,
cast(x_SavpePrompt as decimal(12,3)) as x_Prompt,
cast(EHelp as decimal(12,1))as EHelp,
SMoveG,
cast(STimeG as decimal(12,2))as ST_G,
SMoveKG,
cast(STimeKG as decimal(12,2))as ST_KG,
SMoveGreen,
cast(STimeGreen as decimal(12,2))as ST_Green,
SMoveGreenN,
cast(STimeGreenN as decimal(12,2))as ST_GreenN,
SMoveWhite as SM_White,
cast(STimeWhite as decimal(12,2))as ST_White,
SMoveK as SM_K,
cast(STimeK as decimal(12,2))as ST_K,
cast(av_speed_move AS decimal(12,2))as av_speed_move,
m_Trains.NameShoulder,[FileName],Sch.MaxArrival,Sch.MinArrival,Sch.KArrival,Sch.KDeparture,
vv.stopCount,vv.StopTime, vv.stopCountInpLight,vv.StopTimeInpLight,
vv.vCount,vv.vx,vv.vtime,Count_G,Count_KG,Count_Z,Count_B,Count_K,
m_TrainsInfo.MaxSpeed, m_TrainsInfo.MaxSpeedP
from m_Trains
inner join m_TrainsInfo on m_TrainsInfo.train_id = m_Trains.train_id
and m_Trains.id_tch=isnull(@idtch,m_Trains.id_tch)
inner join ci_Drivers on ci_Drivers.drv_id = m_Trains.drv_id
left join ci_Locomotiv on ci_Locomotiv.loc_id = m_TrainsInfo.loc_id
left join ci_LocType on ci_LocType.type_id = ci_Locomotiv.loc_type
left join m_XFiles on m_XFiles.id_image= m_Trains.image_id
left join V_Schedule Sch on Sch.id_train = m_TrainsInfo.train_id
left join V_Violation vv on vv.tr_id = m_TrainsInfo.train_id
left join Rep_Filter R1 on R1.nFilter = @nFilter and R1.FCode = 1 and ci_Locomotiv.loc_id = R1.FValue
left join Rep_Filter R2 on R2.nFilter = @nFilter and R2.FCode = 2 and ci_Drivers.drv_id = R2.FValue
where ((@train_num = -1) or  (train_num = @train_num)) and
dateTr between @dtStart and @dtFinish and
R1.FValue is NULL and R2.FValue is NULL and
ci_Locomotiv.loc_type =  isnull(@TypeTrain,ci_Locomotiv.loc_type)
order by dateTr
