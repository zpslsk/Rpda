CREATE PROCEDURE [dbo].[sp_Selected_Station]
@numTrain int,
@dtStart DateTime,
@dtFinish DateTime,
@TypeTrain int,
@id_tch int
AS
     Select [Name],Min(ESR)as CodeMap
      from m_Trains
       inner join m_TrainsInfo on m_Trains.train_id = m_TrainsInfo.train_id
       and m_Trains.id_tch=isnull(@id_tch,m_Trains.id_tch)
       inner join m_Schedule on m_Trains.train_id = m_Schedule.id_train
       inner join m_StationStop on m_StationStop.id_station = m_Schedule.id_station
       left join ci_Locomotiv on ci_Locomotiv.loc_id = m_TrainsInfo.loc_id
      where dateTr between @dtStart and @dtFinish and ((ci_Locomotiv.loc_type =  @TypeTrain)or(@TypeTrain = 99))
            and ((m_Trains.train_num = @numTrain)or(@numTrain=-1))
    Group by [Name]


