
CREATE PROCEDURE [dbo].[sp_AddSchedule_train] 
@CodeESR int,
@Name_st char(50),
@Codmape int,
@IdTrainSQL int,
@Darrival int, 
@Ddeparture int,
@Darrival_Rasp int,
@Ddeparture_Rasp int,
@TypeStation char(1),
@XAuto int
AS
declare @Id_Station int
set nocount on
if @CodeESR <> 0 Select @Id_Station=Id_Station from m_StationStop Where ESR = @CodeESR
else Select @Id_Station=Id_Station from m_StationStop Where m_StationStop.[Name]=@Name_st
if @id_Station is Null 
 begin
     Insert into m_StationStop (ESR, CodeMap,[Name]) Values(@CodeESR,@Codmape,@Name_st)
     select @id_Station=@@IDENTITY
 end
if @id_Station is not null
 begin
   Insert into m_Schedule (Id_Station,Id_train,Darrival,Ddeparture,Darrival_Rasp,Ddeparture_Rasp,TypeStation,XAuto) 
   Values (@id_Station,@IdTrainSQL,@Darrival,@Ddeparture,@Darrival_Rasp,@Ddeparture_Rasp,@TypeStation,@XAuto)
 end
