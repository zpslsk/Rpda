-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Web_C_SummTrains]
@dtStart DateTime,
@dtFinish DateTime,
@TypeTrain int,
@idtch int
AS
select Count(Distinct a.train_num)as count
 from m_Trains a
  inner join m_TrainsInfo b on b.train_id = a.train_id and a.id_tch=@idtch
  left join ci_Locomotiv loc on loc.loc_id = b.loc_id
	where dateTr between @dtStart and @dtFinish and loc.loc_type = isnull(@TypeTrain,loc.loc_type)

