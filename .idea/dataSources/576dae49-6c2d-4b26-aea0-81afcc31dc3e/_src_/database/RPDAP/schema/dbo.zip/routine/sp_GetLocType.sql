










CREATE PROCEDURE sp_GetLocType 
@bDef int,
@locname char(30)

 AS
if @bDef=0 
   begin
      select type_name, type_code from  ci_LocType
  end
           else
  begin
      select  type_code from  ci_LocType where   type_name=@locname
  end










