-- =============================================
-- Description:	<Добавляем запись в табл. m_Trains и возвращаем идент.>
-- =============================================
Create PROCEDURE [dbo].[sp_Add_m_Trains]
@image_id int,
@id_tch int,
@train_num int,
@tabnumber int,
@dateTr DateTime,
@drv_id int,
@V_PO char(7),
@V_BBD char(6),
@Date_PO char(6),
@NameShoulder char(50)
AS
SET NOCOUNT ON
Insert into m_Trains(image_id,id_tch,train_num,tabnumber,dateTr,drv_id,V_PO,V_BBD,Date_PO,NameShoulder)
Values(@image_id,@id_tch,@train_num,@tabnumber,@dateTr,@drv_id,@V_PO,@V_BBD,@Date_PO,@NameShoulder)
select @@IDENTITY
