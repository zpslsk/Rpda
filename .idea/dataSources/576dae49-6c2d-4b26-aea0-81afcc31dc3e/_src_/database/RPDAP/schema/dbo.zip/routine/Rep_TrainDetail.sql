
CREATE PROCEDURE [dbo].[Rep_TrainDetail]
@nFilter int,
@train_num int,
@dtStart DateTime,
@dtFinish DateTime,
@TypeTrain int,
@idtch int,
@ReadStart DateTime,
@ReadFinish DateTime,
@type_energloc char(1),
@IsHoz int = -1,
@IsStupidDriver int = -1
AS
Select m_Trains.train_id, train_num,convert(char(10),dateTr,101)+' '+convert(char(8),dateTr,108) as dateTr,
tb_num, RTRIM(surname) + ' ' + Left([name],1) + ' ' + Left(patronymic,1) as FIO,
[type_name], loc_num,time_moveR,time_R,x_CommonR,
cast(x_Common as decimal(12,3)) as x_Common,
cast(x_SavpeAuto as decimal(12,3)) as x_Auto,
cast(CASE WHEN x_Common > 0 THEN x_SavpeAuto/x_Common*100  ELSE 0  END as decimal(12,2)) as x_Auto_proc,
cast(DrawSpec as decimal(12,2)) as Yd_Energ,
cast(x_SavpePrompt as decimal(12,3)) as x_Prompt,
cast(trWork as decimal(15,1)) as trWork, train_time,
TFuel_l as Fuel_l,TFuel_kg as Fuel_kg,
cast(ESum as decimal(12,1))as ESum,
cast(EHelp as decimal(12,1))as EHelp,
cast(EHeat as decimal(12,1))as EHeat,
cast(ERecup as decimal(12,1))as ERecup,
cast(EHelp1 as decimal(12,1))as EHelp1,
cast(EHelp2 as decimal(12,1))as EHelp2,
cast(E1B1 as decimal(12,1))as E1B1,
cast(E1B2 as decimal(12,1))as E1B2,
cast(E2B1 as decimal(12,1))as E2B1,
cast(E2B2 as decimal(12,1))as E2B2,
cast(Edop1 as decimal(12,1))as Edop1,
cast(Edop2 as decimal(12,1))as Edop2,
SMoveGreenN,
cast(STimeGreenN as decimal(12,2))as ST_GreenN,
cast(Norma  as decimal(12,1))as Norma, cast(DifNorma as decimal(12,2))as DifNorma,
cast(av_speed AS decimal(12,2))as av_speed, cast(av_speed_move AS decimal(12,2))as av_speed_move,
countTLim,Weight,VagsCount,m_Trains.NameShoulder,stName,type_code,[FileName],DataFirstRead,
posCalc_s, posCalcT_s, R_, IVen_, Ikom_, Ivsp_, eneff_4_15_tmp, eneff_1_15_tmp, RBrake, NormaEn
from m_Trains
inner join m_TrainsInfo on m_TrainsInfo.train_id = m_Trains.train_id
and m_Trains.id_tch=isnull(@idtch,m_Trains.id_tch)
inner join ci_Drivers on ci_Drivers.drv_id = m_Trains.drv_id
inner join ci_Locomotiv on ci_Locomotiv.loc_id = m_TrainsInfo.loc_id
inner join ci_LocType on ci_LocType.type_id = ci_Locomotiv.loc_type
left join m_PosCtrl on m_PosCtrl.id_train = m_Trains.train_id
left join m_XFiles on m_XFiles.id_image= m_Trains.image_id
where ci_LocType.type_loc = @type_energloc and ((@train_num = -1) or  (train_num = @train_num)) and
dateTr between isnull(@dtStart,dateTr) and isnull(@dtFinish,dateTr) and
DataFirstRead between isnull(@ReadStart,DataFirstRead) and isnull(@ReadFinish,DataFirstRead) and
ci_Locomotiv.loc_type = isnull(@TypeTrain,ci_Locomotiv.loc_type)
and ((@IsHoz = -1) or
(m_Trains.train_num in (select n_train from ci_HozTrain) and @IsHoz = 1) or
(not m_Trains.train_num in (select n_train from ci_HozTrain) and @IsHoz = 0)
)
and ((@IsStupidDriver = -1) or
(ci_Drivers.tb_num in (select tb_num from ci_StupidDriver) and @IsStupidDriver = 1) or
(not ci_Drivers.tb_num in (select tb_num from ci_StupidDriver) and @IsStupidDriver = 0)
)
order by dateTr
