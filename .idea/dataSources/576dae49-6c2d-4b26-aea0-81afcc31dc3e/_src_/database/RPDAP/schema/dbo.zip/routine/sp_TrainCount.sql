-- =============================================
-- Description:	<Список проведённых поездов>
-- =============================================
CREATE PROCEDURE [dbo].[sp_TrainCount] 
@BeginD DateTime,
@EndD DateTime,
@id_tch int
AS
Select Distinct(tr.train_num)
from ci_tch tch 
inner join m_trains tr on tch.tch_id = tr.id_tch and tch.tch_id = isnull(@id_tch,tch.tch_id)
Where  tr.dateTr between @BeginD and @EndD and tr.train_num <> 9999
