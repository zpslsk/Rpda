




/*****************************************************************
-- Автор:	Сираджи Р.Ф.
-- Описание:	Возвращает recordset нагрузка на ось - уд.норма
*****************************************************************/
CREATE PROCEDURE sp_GetDefaultNorma 
AS

declare @nrm float,@NSh char(50)

if not exists(select * from ci_Norma where bDefault = 1)
	exec sp_InitSSByDefNorma -1

select @NSh=NameShoulder, @nrm=Rate from ci_Norma where bDefault = 1

select @nrm










