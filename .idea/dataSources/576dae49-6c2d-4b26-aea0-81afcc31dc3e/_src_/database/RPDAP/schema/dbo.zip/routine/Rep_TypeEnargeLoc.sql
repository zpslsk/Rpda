




CREATE PROCEDURE Rep_TypeEnargeLoc
@NumberLoc int
AS
select e.E1B1,e.E2B1,e.E1B2,e.E2B2,e.Dop1,e.Dop2
 from ci_EnergLoc e, ci_LocType l
  Where l.type_id = @NumberLoc and l.EnergLoc_id = e.EnergLoc_id




