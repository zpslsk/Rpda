-- =============================================
-- Author:      < mosian >
-- Version:     < 3.6 >
-- Description:	< Запись лога в базу >
-- ========================================
Create PROCEDURE [dbo].[sp_ADD_LogMessage]
@id_error int,
@id_th int,
@IP nChar(15),
@Date DateTime
AS
declare @Text_Infoid int
select @Text_Infoid = id_TextMess from ci_TextMess Where id_error =@id_error
Insert Into m_LogMess(id_tch,id_TextMess,Deta_Now,IP)Values(@id_th,@Text_Infoid,@Date,@IP) 
