
CREATE PROCEDURE [dbo].[sp_Choice_of_routes] 
@dtStart DateTime,
@dtFinish DateTime,
@TypeTrain int,
@id_tch int
AS
SELECT NameShoulder,max(train_num) from m_Trains
inner join m_TrainsInfo on m_Trains.train_id = m_TrainsInfo.train_id
       and m_Trains.id_tch=isnull(@id_tch,m_Trains.id_tch)
inner join ci_Locomotiv on ci_Locomotiv.loc_id = m_TrainsInfo.loc_id
Where dateTr between @dtStart and @dtFinish and (m_Trains.train_num<>9999)
and(NameShoulder <> '''')
and ((ci_Locomotiv.loc_type =  @TypeTrain)or(@TypeTrain = 99))
Group by NameShoulder

