CREATE PROCEDURE [dbo].[sp_Train_all_count] 
@BeginD DateTime,
@EndD DateTime,
@id_tch int
AS
 SET NOCOUNT ON;
 Select tr.train_num,count(*)as [count]
 from ci_tch tch 
 inner join m_trains tr on tch.tch_id = tr.id_tch and tch.tch_id = isnull(@id_tch,tch.tch_id)
 inner join m_trainsInfo tri on tr.train_id = tri.train_id 
 Where  tr.dateTr between @BeginD and @EndD and tr.train_num <> 9999 and tri.VagsCount > 2
Group by tr.train_num
