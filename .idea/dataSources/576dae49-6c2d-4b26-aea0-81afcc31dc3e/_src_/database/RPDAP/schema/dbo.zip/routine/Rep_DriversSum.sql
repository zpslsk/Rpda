
CREATE PROCEDURE [dbo].[Rep_DriversSum]
@nFilter int,
@dtStart DateTime,
@dtFinish DateTime,
@TypeTrain int,
@nDrvCol int,
@idtch int,
@YdKoof int,
@type_energloc char(1),
@IsHoz int = -1,
@IsStupidDriver int = -1
AS
Select ci_Drivers.drv_id, Min(ci_Drivers.surname+' '+Left(ci_Drivers.name,1)+' '+Left(ci_Drivers.patronymic,1)) as FIO,
Min(ci_Drivers.tb_num) as tb_num, count(*) as cnt,
cast(sum(x_Common) as decimal(12,3)) as x_Common,
cast(sum(x_SavpeAuto) as decimal(12,3)) as x_Auto, cast(sum(x_SavpePrompt)as decimal(12,3)) as x_Prompt,
cast(sum(trWork) as decimal(15,1)) as trWork,
sum(train_time) as train_time,
cast(sum(CASE WHEN DrawSpec > @YdKoof THEN EHelp ELSE 0  END) as decimal(12,2))as free_EHelp,
cast(sum(CASE WHEN DrawSpec > @YdKoof THEN trWork ELSE 0  END) as decimal(12,2))as free_trWork,
sum(CASE WHEN DrawSpec > @YdKoof THEN TFuel_kg ELSE 0 END) as Free_SFuel_kg,
sum(TFuel_l)as SFuel_l,
sum(TFuel_kg)as SFuel_kg,
sum(train_time_move)as train_time_move,
cast(sum(ESum)as decimal(12,1))as ESum,
cast(sum(EHeat) as decimal(12,1))as EHeat,
cast(sum(EHelp) as decimal(12,1))as EHelp,
cast(sum(ERecup) as decimal(12,1))as ERecup,
cast(sum(E1B1)as decimal(12,1))as E1B1,
cast(sum(E1B2)as decimal(12,1))as E1B2,
cast(sum(E2B1)as decimal(12,1))as E2B1,
cast(sum(E2B2)as decimal(12,1))as E2B2,
cast(sum(Norma) as decimal(12,1)) as Norma,
cast(sum(DrawSpec) as decimal(12,1)) as DrawSpec,
DifNorma=case sum(Norma) when 0 then 0 else( (sum(EHelp)-sum(Norma))/sum(Norma)*100) end,
sum(countTLim) as countTLim,
SUM(RBrake) as RBrake, SUM(NormaEn) AS NormaEn
from m_Trains
inner join m_TrainsInfo on m_TrainsInfo.train_id = m_Trains.train_id and m_Trains.id_tch=isnull(@idtch,m_Trains.id_tch)
inner join ci_Drivers on ci_Drivers.drv_id = m_Trains.drv_id
inner join ci_Locomotiv on ci_Locomotiv.loc_id = m_TrainsInfo.loc_id
inner join ci_LocType on ci_LocType.type_id = ci_Locomotiv.loc_type
where dateTr between @dtStart and @dtFinish and ci_LocType.type_loc = @type_energloc and
ci_Locomotiv.loc_type =  isnull(@TypeTrain,ci_Locomotiv.loc_type)and
m_Trains.train_num<>9999 and ((ci_Drivers.DrvCol = @nDrvCol) or (1000 = @nDrvCol))

and ((@IsHoz = -1) or
(m_Trains.train_num in (select n_train from ci_HozTrain) and @IsHoz = 1) or
(not m_Trains.train_num in (select n_train from ci_HozTrain) and @IsHoz = 0)
)
and ((@IsStupidDriver = -1) or
(ci_Drivers.tb_num in (select tb_num from ci_StupidDriver) and @IsStupidDriver = 1) or
(not ci_Drivers.tb_num in (select tb_num from ci_StupidDriver) and @IsStupidDriver = 0)
)

group by ci_Drivers.drv_id,
ci_Drivers.surname, ci_Drivers.name, ci_Drivers.patronymic
order by ci_Drivers.surname+' '+Left(ci_Drivers.name,1)+' '+Left(ci_Drivers.patronymic,1)

if exists (select * from dbo.sysobjects
where id = object_id(N'[dbo].[sp_AddInfoUserQuery]') and
OBJECTPROPERTY(id, N'IsProcedure') = 1)
begin
if @type_energloc = 't' set @TypeTrain = 118;
exec sp_AddInfoUserQuery @dtStart, @dtFinish, @TypeTrain, 'отчет по машинистам'
end
