/*****************************************************************
-- Описание:	Возвращает данные по катриджам считанным за интервал времени
*****************************************************************/
CREATE PROCEDURE [dbo].[Rep_CatrijView]
@dtStart DateTime,
@dtFinish DateTime,
@idtch int
AS

select ID_Image, convert(char(10),DataLastRead,104)+' '+convert(char(8),DataLastRead,108)DataLastRead,
(select count(*) from m_Trains where image_id = ID_Image) cntTr,
cast(0.001*sum(x_Regim) as Decimal(12,1))xAll, cast(1.0*sum(t_Regim)/3600 as Decimal(12,1))tAll,
(select cast(0.001*sum(x_Regim) as Decimal(12,1)) from m_RegimInfo where idImage = ID_Image and RegimType > 1)xAuto,
(select cast(1.0*sum(t_Regim)/3600 as Decimal(12,1)) from m_RegimInfo where idImage = ID_Image and RegimType > 1)tAuto,
(select sum(EAllHelp) from m_RegimInfo where idImage = ID_Image)EAllHelp,
(select sum(EAllRecup) from m_RegimInfo where idImage = ID_Image)EAllRecup,
[FileName]
from m_XFiles 
inner join m_RegimInfo on idImage = ID_Image and m_xfiles.id_tch=isnull(@idtch,m_xfiles.id_tch)
where DataLastRead between @dtStart and @dtFinish
group by ID_Image, DataLastRead, [FileName]


