


/*****************************************************************
-- Описание:	Возвращает суммарный отчет по нарушениям за интервал времени с учетом параметров фильтра в таблице Rep_Filter
*****************************************************************/
CREATE PROCEDURE [dbo].[Rep_ViolSum]
@drv_id int,
@nFilter int,
@dtStart DateTime,
@dtFinish DateTime,
@TypeRep int,
@idtch int

as

--select @nFilter = -1, @dtStart = '2004-01-01', @dtFinish = '2005-12-01'

create table #tblV (idV int, cnt int)

insert into #tblV
Select cv.idV, count(*)as cnt
from ci_ViolationType cv left join m_Violation v on v.v_id = cv.idV
inner join m_Trains a on v.tr_id = a.train_id and a.id_tch=isnull(@idtch,a.id_tch)
inner join m_TrainsInfo b on b.train_id = a.train_id
left join Rep_Filter R1 on R1.nFilter = @nFilter and R1.FCode = 2 and loc_id = R1.FValue
left join Rep_Filter R2 on R2.nFilter = @nFilter and R2.FCode = 3 and drv_id = R2.FValue
where (dateTr between @dtStart and @dtFinish) and ((@drv_id < 0) or (a.drv_id = @drv_id))
and (R1.FValue is NULL) and (R2.FValue is NULL)
group by cv.idV, vCode, sName

select cv.idV, cv.vCode, sName, isNull(cnt,0) cnt,
(select count(*)
from m_Violation v1, m_trains tr
where tr.id_tch=isnull(@idtch,tr.id_tch) and v1.v_id = t.idV
and v1.GoAuto = 1 and v1.tr_id = tr.train_id and tr.dateTr
between @dtStart and @dtFinish and
((@drv_id < 0) or (tr.drv_id = @drv_id))
) as autocnt
-- *************************************
from ci_ViolationType cv
left join #tblV t on t.idV = cv.idV
-- zap 20.02.2006 *************************************
where  (((cv.vCode >= 100) and (cv.vCode < 200)) and (@TypeRep = 1) ) or
(((cv.vCode >= 200) and (cv.vCode < 300)) and (@TypeRep = 2) ) or
(((cv.vCode >= 300) and (cv.vCode < 400)) and (@TypeRep = 3) ) or
(((cv.vCode >= 400) and (cv.vCode < 500)) and (@TypeRep = 4) ) or
(((cv.vCode >= 500) and (cv.vCode < 600)) and (@TypeRep = 5) ) or
(((cv.vCode >= 600) and (cv.vCode < 700)) and (@TypeRep =6) ) or
(@TypeRep = 0)
--**********************************************************
order by cv.vCode

drop table #tblV


