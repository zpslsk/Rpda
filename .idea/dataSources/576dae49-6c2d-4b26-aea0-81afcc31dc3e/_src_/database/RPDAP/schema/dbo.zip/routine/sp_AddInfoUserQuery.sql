
CREATE PROCEDURE [dbo].[sp_AddInfoUserQuery]
@DateTimeBegin	DateTime,
@DateTimeEnd	DateTime,
@TypeTrain		int,
@Act			nvarchar(50)
AS
declare @DateTimeQuery DateTime;
set @DateTimeQuery = (select GETDATE());

declare @Lgn nvarchar(50);
set @Lgn = (select SUSER_NAME());

declare @SerLoc nvarchar(50);
set @SerLoc = (select type_name
from ci_LocType
where type_id = @TypeTrain)

if @SerLoc IS NULL
set @SerLoc = 'все серии';

declare @id_lgn int;
set @id_lgn = (select Id
from m_ListUsers
where Lgn = @Lgn)

SET NOCOUNT ON;
Insert	into m_LogUsers(DateTimeQuery, DateTimeBegin, DateTimeEnd, SerLoc, id_lgn, Act)
Values(@DateTimeQuery, @DateTimeBegin, @DateTimeEnd, @SerLoc, @id_lgn, @Act)
select @@IDENTITY
