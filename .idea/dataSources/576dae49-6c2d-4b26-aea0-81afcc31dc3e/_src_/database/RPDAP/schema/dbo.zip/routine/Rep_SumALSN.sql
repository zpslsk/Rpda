CREATE PROCEDURE [dbo].[Rep_SumALSN]
@nFilter int,
@dtStart DateTime,
@dtFinish DateTime,
@TypeTrain int,
@idtch int
AS
Select train_num, count(*)as cnt,
             sum(SMoveG)as SM_G,
             cast(sum(STimeG)/60 as decimal(12,2))as ST_G,
             sum(SMoveKG)as SM_KG,
             cast(sum(STimeKG)/60 as decimal(12,2))as ST_KG,
             sum(SMoveGreen)as SM_Green,
             cast(sum(STimeGreen)/60 as decimal(12,2))as ST_Green,
             sum(SMoveGreenN)as SM_GreenN,
             cast(sum(STimeGreenN)/60 as decimal(12,2))as ST_GreenN,
             sum(SMoveWhite)as SM_White,
             cast(sum(STimeWhite)/60 as decimal(12,2))as ST_White,
             sum(SMoveK)as SM_K,
             cast(sum(STimeK)/60 as decimal(12,2))as ST_K
	from m_Trains a
	inner join m_TrainsInfo b on b.train_id = a.train_id and a.id_tch=isnull(@idtch,a.id_tch)
	left join ci_Locomotiv loc on loc.loc_id = b.loc_id
	left join Rep_Filter R1 on R1.nFilter = @nFilter and R1.FCode = 2 and b.loc_id = R1.FValue
	left join Rep_Filter R2 on R2.nFilter = @nFilter and R2.FCode = 3 and drv_id = R2.FValue
	where dateTr between @dtStart and @dtFinish and
	R1.FValue is NULL and R2.FValue is NULL and
	loc.loc_type =  isnull(@TypeTrain,loc.loc_type)
	group by train_num
	order by train_num


