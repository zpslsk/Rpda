CREATE PROCEDURE [dbo].[Web_select_loc] 
AS
select lt.type_name, l.loc_type 
from ci_Locomotiv l
inner join ci_LocType lt on(l.loc_type = lt.type_code)
group by lt.type_name, loc_type

