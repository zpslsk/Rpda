
/*****************************************************************
-- Type: 	Stored Procedure
-- Name: 	sp_GetDriverId
-- Автор:	Сираджи Р.Ф. 
-- Описание:	Возвращает (при необходимости создает) id машиниста с таб.номером @tab_num
*****************************************************************/

CREATE PROCEDURE sp_GetDriverId 
  @tab_num Integer,
  @idtch int
AS
  declare @drv_id int
  set nocount on

  select @drv_id = drv_id from ci_Drivers where id_tch=@idtch and tb_num = @tab_num 
  if @drv_id is Null begin
    insert into ci_Drivers (tb_num, surname, [name], patronymic, id_tch) 
      Values(@tab_num, 'Таб.номер - '+ltrim(str(@tab_num)), '', '',@idtch)
    select @@IDENTITY
  end
  else
    select @drv_id