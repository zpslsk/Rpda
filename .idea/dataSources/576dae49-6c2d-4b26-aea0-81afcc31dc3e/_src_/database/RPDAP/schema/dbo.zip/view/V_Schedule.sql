

CREATE VIEW dbo.V_Schedule
AS
SELECT d.id_train, d.MaxArrival, d.MinArrival, v.KArrival, n.KDeparture
FROM  (SELECT id_train, MAX(DArrival - DArrival_Rasp) AS MaxArrival, MIN(DArrival - DArrival_Rasp) AS MinArrival
               FROM   m_Schedule
               WHERE (TypeStation <> 'K') AND (DArrival_Rasp > 0) AND (DDeparture_Rasp > 0)
               GROUP BY id_train) d FULL OUTER JOIN
                   (SELECT id_train,Max (DArrival - DArrival_Rasp) AS KArrival
                    FROM   m_Schedule
                    WHERE (TypeStation = 'K') AND (DArrival_Rasp > 0) AND ((DArrival - DArrival_Rasp) >= 0)
                    GROUP BY id_train) v ON d.id_train = v.id_train FULL OUTER JOIN
                   (SELECT id_train, Max(DDeparture - DDeparture_Rasp) AS KDeparture
                    FROM   m_Schedule
                    WHERE (TypeStation = 'K') AND (DDeparture_Rasp > 0) AND ((DDeparture - DDeparture_Rasp) >= 0)
                     GROUP BY id_train) n ON d.id_train = n.id_train






