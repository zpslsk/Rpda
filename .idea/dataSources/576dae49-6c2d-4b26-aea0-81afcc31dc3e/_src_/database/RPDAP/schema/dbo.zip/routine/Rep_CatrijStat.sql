/*****************************************************************
-- Описание:	Возвращает статистику по считанным катриджам
*****************************************************************/
CREATE PROCEDURE [dbo].[Rep_CatrijStat]
@dtStart DateTime,
@dtFinish DateTime,
@idtch int
AS
CREATE TABLE #T (DataFirstRead Char(19), FError int, FWarning int)
insert into #T
select convert(char(10),DataFirstRead,104)+' '+convert(char(8),DataFirstRead,108) as DataFirstRead, --NumKatr,
(select count(*) from z_ReadError where ErrLevel < 100 and idImage = m_XFiles.ID_Image),
(select count(*) from z_ReadError where ErrLevel >= 100 and idImage = m_XFiles.ID_Image)
from m_XFiles
where m_XFiles.id_tch=isnull(@idtch,m_XFiles.id_tch) and DataFirstRead between @dtStart and @dtFinish
select DataFirstRead, count(*) as cnt, sum(FError) as FError, sum(FWarning) as FWarning from #T
group by DataFirstRead
order by DataFirstRead
DROP TABLE #T


