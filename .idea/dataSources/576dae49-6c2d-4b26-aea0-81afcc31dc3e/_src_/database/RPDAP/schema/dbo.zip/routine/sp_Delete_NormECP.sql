-- =============================================
-- Description:	<Удаляем норму по лок. либо по номеру поезда либо всё>
-- =============================================
Create PROCEDURE [dbo].[sp_Delete_NormECP]
@TypeLoc int,
@NumTr int
AS
SET NOCOUNT ON;
delete from ci_NormaECP
 where(id_Loc = isnull(@TypeLoc,id_Loc))and(NumTr = isnull(@NumTr,NumTr))     
