

/*****************************************************************
-- Описание:	Возвращает инфо по катриджам считанным за выбранный день
*****************************************************************/
CREATE PROCEDURE [dbo].[Rep_CatrijForDate]
@dtStart DateTime,
@idtch int
AS

select ID_Image, convert(char(10),DataLastRead,104)+' '+convert(char(8),DataLastRead,108) as DataLastRead,
(select count(*) from z_ReadError where ErrLevel < 100 and idImage = m_XFiles.ID_Image) as FError,
(select count(*) from z_ReadError where ErrLevel >= 100 and idImage = m_XFiles.ID_Image) as FWarning,
[FileName]
from m_XFiles
where m_XFiles.id_tch=isnull(@idtch,m_XFiles.id_tch) and DataFirstRead between @dtStart and @dtStart + 1


