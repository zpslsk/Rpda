
CREATE VIEW dbo.V_ALLCountViol
AS
SELECT tr_id, SUM(CASE WHEN ci_ViolationType.vCode = 226 THEN 1 ELSE 0 END) stopCount, 
               SUM(CASE WHEN ci_ViolationType.vCode = 225 THEN 1 ELSE 0 END) VCount
FROM  m_Violation INNER JOIN
               ci_ViolationType ON m_Violation.v_id = ci_ViolationType.idv
WHERE ci_ViolationType.vCode IN (226, 225)
GROUP BY tr_id


