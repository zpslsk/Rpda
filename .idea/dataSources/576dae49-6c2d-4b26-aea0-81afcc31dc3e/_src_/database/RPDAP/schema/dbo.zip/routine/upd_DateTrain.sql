
CREATE PROCEDURE [dbo].[upd_DateTrain]
@idt int,
@newdate DateTime
AS
    Update m_Trains Set dateTr = @newdate
    Where train_id = @idt

