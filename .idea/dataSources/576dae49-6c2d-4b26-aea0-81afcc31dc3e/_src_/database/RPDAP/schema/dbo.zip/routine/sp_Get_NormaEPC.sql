Create PROCEDURE [dbo].[sp_Get_NormaEPC] 
@id_tch int,
@id_loc int,
@Date DateTime
AS
SELECT id, id_tch, id_Loc, Begin_ECP, End_ECP, TimeBegin, TimeEnd, Norma,NumTr
FROM ci_NormaECP
WHERE (@Date between TimeBegin and TimeEnd)and(id_tch = @id_tch)AND(id_Loc = @id_loc)
