/*****************************************************************/
CREATE PROCEDURE [dbo].[sp_NameStation_OneTrain]
@idtrain int
AS
Select CodeMap,[Name],ESR
 from m_Trains
  inner join m_TrainsInfo on m_Trains.train_id = m_TrainsInfo.train_id and  m_Trains.train_id = @idtrain
  inner join m_Schedule on m_Trains.train_id = m_Schedule.id_train
  inner join m_StationStop on m_StationStop.id_station = m_Schedule.id_station
order by id_Schedule
