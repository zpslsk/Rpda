Create PROCEDURE [dbo].[Rep_Schedule_Trains]
@dtStart Datetime,
@dtFinish Datetime,
@numTrain int,
@id_tch int,
@TypeTrain int,
@odd int
 AS
Select CodeMap,id_train,dateTr,vagsCount,XAuto,EHelp,x_common,x_CommonR,time_moveR,time_R,Weight,
cast(x_SavpeAuto as decimal(12,3)) as x_Auto, cast(x_SavpePrompt as decimal(12,3)) as x_prompt,
cast(av_speed AS decimal(12,2))as av_speed, cast(av_speed_move AS decimal(12,2))as av_speed_move,
SMoveG,
cast(STimeG as decimal(12,2))as ST_G,
SMoveKG,
cast(STimeKG as decimal(12,2))as ST_KG,
SMoveGreen,
cast(STimeGreen as decimal(12,2))as ST_Green,
SMoveGreenN,
cast(STimeGreenN as decimal(12,2))as ST_GreenN,
SMoveWhite as SM_White,
cast(STimeWhite as decimal(12,2))as ST_White,
SMoveK as SM_K,
cast(STimeK as decimal(12,2))as ST_K,
stopCount,StopTime,VCount,Vx,VTime,
Count_G,Count_KG,Count_Z,Count_B,Count_K,
train_num,tb_num,[type_name], loc_num,m_Trains.NameShoulder,Darrival,Ddeparture,Darrival_Rasp,Ddeparture_Rasp,TypeStation,m_StationStop.[Name],
ESR
 from m_Trains
  inner join m_TrainsInfo on m_Trains.train_id = m_TrainsInfo.train_id 
  and m_Trains.id_tch=isnull(@id_tch,m_Trains.id_tch)
  inner join m_Schedule on m_Trains.train_id = m_Schedule.id_train
  inner join m_StationStop on m_StationStop.id_station = m_Schedule.id_station
  left join ci_Drivers on ci_Drivers.drv_id = m_Trains.drv_id
  left join ci_Locomotiv on ci_Locomotiv.loc_id = m_TrainsInfo.loc_id
  left join ci_LocType on ci_LocType.type_id = ci_Locomotiv.loc_type
  left join V_Violation on V_Violation.tr_id = m_Trains.train_id
where dateTr between @dtStart and @dtFinish and  ((ci_Locomotiv.loc_type =  @TypeTrain)or(@TypeTrain =99))
and(m_Trains.train_num <> 9999)and((m_Trains.train_num = @numTrain)or(@numTrain=-1))and(m_TrainsInfo.vagsCount>2)
and(Darrival is not NULL)and(Ddeparture is not NULL)
order by id_Schedule
