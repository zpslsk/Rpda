
CREATE PROCEDURE [dbo].[Rep_DriversDetail]
@nFilter int,
@driv_id int,
@dtStart DateTime,
@dtFinish DateTime,
@TypeTrain int,
@idtch int,
@type_energloc char(1),
@IsHoz int = -1,
@IsStupidDriver int = -1
AS
Select m_Trains.train_id, convert(char(10),dateTr,101)+' '+convert(char(8),dateTr,108)as dateTr,
train_num,[type_name], loc_num,
cast(x_Common as decimal(12,3)) as x_Common,
cast(x_SavpeAuto as decimal(12,3)) as x_Auto, cast(x_SavpePrompt as decimal(12,3)) as x_Prompt,
cast(trWork as decimal(15,1)) as trWork, train_time,
cast(DrawSpec as decimal(12,2)) as Yd_Energ,
TFuel_l as Fuel_l,TFuel_kg as Fuel_kg,
cast(ESum as decimal(12,1))as ESum,
cast(EHeat as decimal(12,1))as EHeat,
cast(EHelp as decimal(12,1))as EHelp,
cast(ERecup as decimal(12,1))as ERecup,
cast(EHelp1 as decimal(12,1))as EHelp1,
cast(EHelp2 as decimal(12,1))as EHelp2,
cast(Norma as decimal(12,1)) as Norma, cast(DifNorma as decimal(12,2)) as DifNorma,
cast(av_speed AS decimal(12,2))as av_speed, cast(av_speed_move AS decimal(12,2))as av_speed_move,
countTLim,type_code,[FileName],DataFirstRead, RBrake, NormaEn
from m_Trains inner join m_TrainsInfo on m_TrainsInfo.train_id = m_Trains.train_id
and m_Trains.id_tch=isnull(@idtch,m_Trains.id_tch)
inner join ci_Drivers on ci_Drivers.drv_id = m_Trains.drv_id
inner join ci_Locomotiv on ci_Locomotiv.loc_id = m_TrainsInfo.loc_id
inner join ci_LocType on ci_LocType.type_id = ci_Locomotiv.loc_type
left join m_XFiles on m_XFiles.id_image= m_Trains.image_id
where m_Trains.drv_id = @driv_id and
ci_LocType.type_loc = @type_energloc and
dateTr between @dtStart and @dtFinish and
ci_Locomotiv.loc_type = isnull(@TypeTrain,ci_Locomotiv.loc_type) and
m_Trains.train_num<>9999

and ((@IsHoz = -1) or
(m_Trains.train_num in (select n_train from ci_HozTrain) and @IsHoz = 1) or
(not m_Trains.train_num in (select n_train from ci_HozTrain) and @IsHoz = 0)
)
and ((@IsStupidDriver = -1) or
(ci_Drivers.tb_num in (select tb_num from ci_StupidDriver) and @IsStupidDriver = 1) or
(not ci_Drivers.tb_num in (select tb_num from ci_StupidDriver) and @IsStupidDriver = 0)
)

order by dateTr
