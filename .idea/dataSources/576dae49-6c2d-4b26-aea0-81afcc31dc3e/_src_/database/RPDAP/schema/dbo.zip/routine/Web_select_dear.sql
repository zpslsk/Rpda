CREATE PROCEDURE  [dbo].[Web_select_dear]
@tch_name char(50)
AS
select tch_id,NaneTch as NameTch,ShortName as NameDear,CodeDear
from ci_tch
left join ci_Dear ON ci_tch.id_dear=ci_Dear.dear_id
Where LoginName=@tch_name


