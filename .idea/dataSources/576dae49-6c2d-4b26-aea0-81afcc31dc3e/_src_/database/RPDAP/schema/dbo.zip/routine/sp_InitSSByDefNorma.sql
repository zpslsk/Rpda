











/*****************************************************************
-- Автор:	Сираджи Р.Ф. 
-- Описание:	При отсутствии нормы по умолчанию добавляет ее, а также 
--  инициализирует новое направление нормой по умолчанию на макс. интервал
*****************************************************************/
CREATE PROCEDURE sp_InitSSByDefNorma 
	@ss_id int

AS

declare @id_def int

if not exists(select * from ci_Norma where bDefault = 1) begin
  insert into ci_Norma (bDefault, ss_id,NameShoulder,NTrain,dtBegin,dtEnd,Rate)
	Values(1, NULL,'',0, '2000-01-01','2010-01-01', 112)
end

if (@ss_id > 0) and not exists(select * from ci_Norma where ss_id = @ss_id) begin
	select @id_def = id_Norma from ci_Norma where bDefault = 1

	insert into ci_Norma (bDefault, ss_id,NameShoulder,NTrain,dtbegin,dtEnd,Rate)
		select 0,@ss_id,NameShoulder,NTrain,dtbegin,dtEnd,Rate
		from ci_Norma where id_Norma = @id_def
end










