Create PROCEDURE [dbo].[sp_Get_NormForTrain]
@Date DateTime,
@LocType int,
@id_tch int,
@numTr int
as
declare
@nt int
 if exists(Select id from ci_NormaECP
           where(id_tch = @id_tch)and(@LocType = id_Loc)and(@Date between TimeBegin and TimeEnd)and(@numTr = NumTr))
  set @nt=@numTr
 else set @nt=-1

 Select Begin_Ecp,End_Ecp,Norma from ci_NormaECP
   where(id_tch = @id_tch)and(@LocType = id_Loc)and 
        (@Date between TimeBegin and TimeEnd)and(NumTr=@nt)
