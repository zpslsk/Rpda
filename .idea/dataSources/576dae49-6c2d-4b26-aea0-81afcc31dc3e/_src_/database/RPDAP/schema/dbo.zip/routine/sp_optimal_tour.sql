
CREATE PROCEDURE [dbo].[sp_optimal_tour]
@dtStart DateTime,
@dtFinish DateTime,
@TypeTrain int,
@id_tch int,
@Name_rout varchar(50)
AS
Select Count(x_common)as col,max(m_Trains.train_id) as id from m_Trains
inner join m_TrainsInfo on m_TrainsInfo.train_id = m_Trains.train_id 
           and m_Trains.id_tch=isnull(@id_tch,m_Trains.id_tch)
inner join ci_Locomotiv on ci_Locomotiv.loc_id = m_TrainsInfo.loc_id
Where dateTr between @dtStart and @dtFinish and (m_Trains.train_num<>9999)
and ((ci_Locomotiv.loc_type =  @TypeTrain)or(@TypeTrain = 99))
and(NameShoulder = @Name_rout)
Group by cast(x_Common as decimal(12,0))
Order by Count(x_common) Desc

