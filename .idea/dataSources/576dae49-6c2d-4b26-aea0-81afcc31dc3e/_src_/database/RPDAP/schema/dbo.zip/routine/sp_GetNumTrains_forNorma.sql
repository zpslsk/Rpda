-- =============================================
-- Description:	<Получение номеров поездов в заданный интервал времени
--               к которым индивидуально введенна норма расхода >
-- =============================================
Create PROCEDURE [dbo].[sp_GetNumTrains_forNorma] 
@LocType int,
@Interval DateTime
AS
SELECT DISTINCT NumTr FROM ci_NormaECP 
WHERE @Interval between TimeBegin and TimeEnd and (id_Loc = @LocType)and(NumTr <> - 1)
