CREATE FUNCTION Insert_ci_Locomotiv_ifexists_old ("@LocType" integer, "@LocNum" integer, "@SecCount" integer, "@koefNorma" real) RETURNS integer
	LANGUAGE plpgsql
AS $$
begin

if not exists
(select *
from "DIRECTORY_SERIES_TRAINS"
where "TYPE_SERIES_TRAIN_ID" = "@LocType" and
"CODE_CLASSIFIER" = "@LocNum") then
insert into DIRECTORY_SERIES_TRAINS(TYPE_SERIES_TRAIN_ID, COUNT_SECTIONS, CODE_CLASSIFIER, COEFFICIENT_NORM_CONSUMPTION_SECTION_ON_SERIES10000)
values (@LocType, @SecCount, @LocNum, @koefNorma);
end if;



return 0;








end;
$$
