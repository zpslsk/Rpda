CREATE FUNCTION S_DEL_SERIES1 ("@RAILROAD_ID" integer, "@DEPOT_ID" integer, "@SERIES_TRAIN_ID" integer) RETURNS integer
	LANGUAGE plpgsql
AS $$
declare n1 integer :=-1;
begin
select COALESCE("SERIES_TRAIN_ID",0) into n1 from "DIRECTORY_SERIES_TRAINS"
 where "RAILROAD_ID"="@RAILROAD_ID" and "DEPOT_ID"="@DEPOT_ID" and "SERIES_TRAIN_ID"="@SERIES_TRAIN_ID";
IF (n1>0)
  Then
    delete from "DIRECTORY_SERIES_TRAINS"
     where "SERIES_TRAIN_ID" = n1;
    return 0;
    else
    return -3;
END IF;

end; 
$$
