CREATE FUNCTION S_WU_STATIONS ("@ESR_CODE_STATION" integer, "@CODE_STATION_INTERNAL_DATABASE" integer, "@STATION_NAME" character varying) RETURNS integer
	LANGUAGE plpgsql
AS $$
declare n1 integer :=-1;
declare _new_id integer;
begin

if "@ESR_CODE_STATION">0 then
  begin



select COALESCE("STATION_ID",0) into n1 from "DIRECTORY_STATIONS"
  where "ESR_CODE_STATION"="@ESR_CODE_STATION";
IF (n1>0)
  Then
    begin
        Update "DIRECTORY_STATIONS" set "STATION_NAME"="@STATION_NAME","CODE_STATION_INTERNAL_DATABASE"="@CODE_STATION_INTERNAL_DATABASE"
          where "STATION_ID" = n1;
    return n1;
    end;
    else
     begin
      insert into "DIRECTORY_STATIONS"("ESR_CODE_STATION","CODE_STATION_INTERNAL_DATABASE","STATION_NAME")  Values("@ESR_CODE_STATION","@CODE_STATION_INTERNAL_DATABASE","@STATION_NAME"); --RETURNING  "STATION_ID";
	    --RETURNING  "STATION_ID";
	    _new_id := currval('"DIRECTORY_STATIONS_STATION_ID_seq"');
return _new_id;

     end;
    
END IF;
 
  end;
else
 return -1;

END IF;
 
end; 
$$
