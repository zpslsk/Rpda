CREATE FUNCTION M_DEL_TRAINS ("@RAILROAD_ID" integer, "@DEPOT_ID" integer, "@UNIT_ROUTE_ID" integer, "@dattim" timestamp with time zone) RETURNS integer
	LANGUAGE plpgsql
AS $$
declare n1 integer :=-1;
begin

if "@RAILROAD_ID">1 then
begin

select COALESCE("UNIT_ROUTE_ID",0) into n1 from "SPECIFICATION_ROUTE_UNITS"
 where "RAILROAD_ID"="@RAILROAD_ID" and "DEPOT_ID"="@DEPOT_ID" and "UNIT_ROUTE_ID"="@UNIT_ROUTE_ID" and "DATE_TIME_TRIP_BEGIN"<"@dattim";
IF (n1>0)
  Then
   begin
    delete from "SPECIFICATION_TROUBLES" where "UNIT_ROUTE_ID"=n1;
        delete from "SPECIFICATION_CONSTANT_TEMPORARY_SPEED_LIMITS" where "UNIT_ROUTE_ID"=n1;
        delete from "SPECIFICATION_TRAIN_SCHEDULES" where "UNIT_ROUTE_ID"=n1;
        --delete from M_WAGS where T_ID=@id_
        delete from "SPECIFICATION_ROUTE_UNITS_INFO_RPDAE" where "UNIT_ROUTE_ID"=n1;
        delete from "SPECIFICATION_ROUTE_UNITS" where "UNIT_ROUTE_ID"=n1;
    end;
    return 0;
    else
    return -2;
END IF;

end;
else
begin
return -1;
end;
end if;


end; 
$$
