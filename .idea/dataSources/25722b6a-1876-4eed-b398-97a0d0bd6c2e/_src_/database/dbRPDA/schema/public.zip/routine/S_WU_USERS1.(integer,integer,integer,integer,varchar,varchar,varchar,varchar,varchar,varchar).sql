CREATE FUNCTION S_WU_USERS1 ("@RAILROAD_ID" integer, "@DEPOT_ID" integer, "@USER_ID" integer, "@USER_TYPE" integer, "@USER_LOGIN" character varying, "@USER_FULL_NAME" character varying, "@USER_POST" character varying, "@USER_OFFICE" character varying, "@USER_PHONE" character varying, "@USER_MAIL" character varying) RETURNS integer
	LANGUAGE plpgsql
AS $$
declare n1 integer :=-1;
declare _new_id integer;
declare y1 integer;
begin



select COALESCE("USER_ID",0) into n1 from "DIRECTORY_USERS"
  where ("RAILROAD_ID"<>"@RAILROAD_ID" or "DEPOT_ID"<>"@DEPOT_ID")and Upper("USER_LOGIN")=Upper("@USER_LOGIN");
IF (n1>0)
  Then

 begin
	return -5;
  end;
else

 begin


select COALESCE("USER_ID",0) into n1 from "DIRECTORY_USERS"
  where "RAILROAD_ID"="@RAILROAD_ID" and "DEPOT_ID"="@DEPOT_ID" and(Upper("USER_LOGIN")=Upper("@USER_LOGIN") or "USER_ID"="@USER_ID");

  IF (n1>0) then
    begin
        Update "DIRECTORY_USERS" set "USER_TYPE"="@USER_TYPE","USER_FULL_NAME"="@USER_FULL_NAME","USER_POST"="@USER_POST","USER_OFFICE"="@USER_OFFICE","USER_PHONE"="@USER_PHONE","USER_MAIL"="@USER_MAIL"
		  where "USER_ID" = "@USER_ID";
    return n1;
    end;
    else
     begin
      insert into "DIRECTORY_USERS"("RAILROAD_ID","DEPOT_ID","USER_TYPE","USER_PROFILE","USER_LOGIN","USER_FULL_NAME","USER_POST","USER_OFFICE","USER_PHONE","USER_MAIL")
          Values("@RAILROAD_ID","@DEPOT_ID","@USER_TYPE",0,"@USER_LOGIN","@USER_FULL_NAME","@USER_POST","@USER_OFFICE","@USER_PHONE","@USER_MAIL")
	    RETURNING  "USER_ID" INTO y1;
	    return y1;
	   -- _new_id := currval('"DIRECTORY_STATIONS_STATION_ID_seq"');
--return _new_id;

     end;
  end if;

 end;   
END IF;
 


 
end; 
$$
