CREATE FUNCTION INS_MONITOR ("@USER_ID" integer, "@CONNECTION_TYPE" integer, "@DATE_TIME_BEGIN_WORK" timestamp without time zone, "@DATE_TIME_END_WORK" timestamp without time zone, "@IP_ADDRESS" character varying) RETURNS integer
	LANGUAGE sql
AS $$

INSERT INTO "USER_MONITOR"
           ("USER_ID"
           ,"DATE_TIME_BEGIN_WORK"
           ,"DATE_TIME_END_WORK"
           ,"IP_ADDRESS"
           ,"CONNECTION_TYPE")
     VALUES
          ("@USER_ID"
           ,"@DATE_TIME_BEGIN_WORK"
           ,"@DATE_TIME_END_WORK"
          ,"@IP_ADDRESS"
           ,"@CONNECTION_TYPE");

  SELECT 1;
     
     
$$
