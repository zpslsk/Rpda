CREATE FUNCTION B_WU_UPDATE1 ("@bid" integer, "@typfil" integer, "@filname" character varying, "@data" bytea, "@lenfil" integer, "@vmajor" integer, "@vminor" integer, "@vrelea" integer, "@vbuild" integer) RETURNS integer
	LANGUAGE plpgsql
AS $$
declare n1 integer :=-1;
declare _new_id integer;
begin




select COALESCE("BLOB_FILE_UPDATE_AWS_ID",0) into n1 from "BLOB_UPDATE"
 where "BLOB_FILE_UPDATE_AWS_ID"="@bid" or ("TYPE_BLOB_FILE_UPDATE_AWS"="@typfil" and "NAME_BLOB_FILE_UPDATE_AWS"="@filname");
IF (n1>0)
  Then
    begin
        Update "BLOB_UPDATE" set "BLOB_FILE_UPDATE_AWS"="@data","LenFile"="@lenfil","MAJOR_VERSION_BLOB_FILE_UPDATE_AWS"="@vmajor","MINOR_VERSION_BLOB_FILE_UPDATE_AWS"="@vminor","RELEASE_VERSION_BLOB_FILE_UPDATE_AWS"="@vrelea","BUILD_VERSION_BLOB_FILE_UPDATE_AWS"="@vbuild"
                  
          where "BLOB_FILE_UPDATE_AWS_ID" = n1;
    return n1;
    end;
    else
     begin
     insert into "BLOB_UPDATE"("TYPE_BLOB_FILE_UPDATE_AWS","NAME_BLOB_FILE_UPDATE_AWS","BLOB_FILE_UPDATE_AWS","LenFile","MAJOR_VERSION_BLOB_FILE_UPDATE_AWS","MINOR_VERSION_BLOB_FILE_UPDATE_AWS","RELEASE_VERSION_BLOB_FILE_UPDATE_AWS","BUILD_VERSION_BLOB_FILE_UPDATE_AWS")
          Values("@typfil","@filname","@data","@lenfil","@vmajor","@vminor","@vrelea","@vbuild");
	   -- RETURNING "DRIVER_ID";
_new_id := currval('public.auto_id_users3');
return _new_id;


     end;
    
END IF;
 
  

 
end; 
$$
