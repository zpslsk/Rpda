CREATE FUNCTION S_WU_NASTR ("@RAILROAD_ID" integer, "@LENGTH_BLOCK_SETTING_AWS" integer, "@DATE_TIME_SETTING_AWS" timestamp with time zone) RETURNS integer
	LANGUAGE plpgsql
AS $$
declare n1 integer :=-1;
declare _new_id integer;
begin

if "@RAILROAD_ID">1 then
  begin



select COALESCE("SETTING_AWS_ID",0) into n1 from "DIRECTORY_SETTING_AWS"
 where "RAILROAD_ID"="@RAILROAD_ID";
IF (n1>0)
  Then
    begin
        Update "DIRECTORY_SETTING_AWS" set "LENGTH_BLOCK_SETTING_AWS"="@LENGTH_BLOCK_SETTING_AWS","DATE_TIME_SETTING_AWS"="@DATE_TIME_SETTING_AWS"
          where "SETTING_AWS_ID" = n1;
    return n1;
    end;
    else
     begin
     insert into "DIRECTORY_SETTING_AWS"("RAILROAD_ID","LENGTH_BLOCK_SETTING_AWS","DATE_TIME_SETTING_AWS")
          Values("@RAILROAD_ID","@LENGTH_BLOCK_SETTING_AWS","@DATE_TIME_SETTING_AWS");
	    --RETURNING "SETTING_AWS_ID";
_new_id := currval('public.auto_id_users13');
return _new_id;


     end;
    
END IF;
 
  end;
else
 return -1;

END IF;
 
end; 
$$
