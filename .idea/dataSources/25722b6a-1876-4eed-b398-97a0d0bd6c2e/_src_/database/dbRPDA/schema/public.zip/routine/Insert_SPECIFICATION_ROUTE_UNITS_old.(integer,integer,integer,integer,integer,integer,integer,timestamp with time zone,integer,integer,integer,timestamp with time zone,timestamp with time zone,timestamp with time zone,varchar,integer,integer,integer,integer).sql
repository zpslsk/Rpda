CREATE FUNCTION Insert_SPECIFICATION_ROUTE_UNITS_old ("@num_road" integer, "@num_tch" integer, "@RAILROAD_DIRECTION_ID" integer, "@image_id" integer, "@USER_ID" integer, "@PERSON_NUMBER_DRIVER" integer, "@NUMBER_ROUTE" integer, "@dateTr" timestamp with time zone, "@drv_id" integer, "@COUNT_ITEMS_SPECIFICATION_TRAIN_SCHEDULES" integer, "@FULL_NUMBER_CARTRIDGE" integer, "@DATE_READ_FILE_CARTRIDGE" timestamp with time zone, "@DATE_SCHEDULE_MAP" timestamp with time zone, "@DATE_TIME_RECORD_DATA_ROUTE" timestamp with time zone, "@verpo" character varying, "@INFO_RPDA_NUMBER_BLOCK_BR" integer, "@isavprt_status" integer, "@isavprt_addr" integer, "@TYPE_MOVEMENT" integer) RETURNS integer
	LANGUAGE plpgsql
AS $$
declare RAILROAD_ID integer;
declare DEPOT_ID integer;
declare y1 integer;

begin

select "RAILROAD_ID" into RAILROAD_ID from "DIRECTORY_RAILROADS" where "CODE_RAILROAD"="@num_road";
select "DEPOT_ID" into DEPOT_ID from "DIRECTORY_DEPOT" where "CODE_DEPOT"="@num_tch" and "RAILROAD_ID"=RAILROAD_ID;

INSERT INTO "SPECIFICATION_ROUTE_UNITS"(
             "RAILROAD_ID", "DEPOT_ID", "RAILROAD_DIRECTION_ID", 
            "FILE_CARTRIDGE_ID", "USER_ID", "PERSON_NUMBER_DRIVER", "NUMBER_ROUTE", 
            "DATE_TIME_TRIP_BEGIN", "COUNT_ITEMS_SPECIFICATION_TRAIN_SCHEDULES", 
            "FULL_NUMBER_CARTRIDGE", "DATE_READ_FILE_CARTRIDGE", "DATE_SCHEDULE_MAP", 
            "DATE_TIME_RECORD_DATA_ROUTE", "TYPE_MOVEMENT", "DRIVER_ID", 
            "INFO_RPDA_VERSION_BLOCK_BR", "INFO_RPDA_NUMBER_BLOCK_BR", isavprt_status, 
            isavprt_addr)
            VALUES(RAILROAD_ID,DEPOT_ID,"@RAILROAD_DIRECTION_ID","@image_id","@USER_ID","@PERSON_NUMBER_DRIVER","@NUMBER_ROUTE","@dateTr","@COUNT_ITEMS_SPECIFICATION_TRAIN_SCHEDULES",
            "@FULL_NUMBER_CARTRIDGE","@DATE_READ_FILE_CARTRIDGE","@DATE_SCHEDULE_MAP","@DATE_TIME_RECORD_DATA_ROUTE","@TYPE_MOVEMENT","@drv_id","@verpo","@INFO_RPDA_NUMBER_BLOCK_BR","@isavprt_status","@isavprt_addr")
RETURNING  "UNIT_ROUTE_ID" INTO y1;

return y1;









end;
$$
