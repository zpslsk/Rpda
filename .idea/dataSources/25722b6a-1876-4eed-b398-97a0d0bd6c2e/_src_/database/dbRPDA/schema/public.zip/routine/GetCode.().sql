CREATE FUNCTION GetCode () RETURNS integer
	LANGUAGE plpgsql
AS $$
declare i integer:=0;

begin
FOR j IN 1..16 LOOP
   i:=i+1;
insert into "DIRECTORY_TYPE_SERIES_TRAINS"("NAME_SERIES_TYPE_UNIT_TRAIN","type_code","podtype_code","id_cnsi_code")
 values(null,154,i,0);  
END LOOP;
return 0;
end;
$$
