CREATE FUNCTION sp_SecInHHMMSS ("@timeIn" double precision, OUT "@timeOut" character varying) RETURNS character varying
	LANGUAGE plpgsql
AS $$
declare  nHour integer;
declare nMin integer;
declare nSec integer;
declare cMin varchar(2);
declare cSec varchar(2);
begin

if "@timeIn" < 1 then
  "@timeOut" := '00:00:00';
 else

 begin
 nHour := div(cast("@timeIn" as numeric),3600);
nMin := div(cast("@timeIn" - nHour *3600 as numeric),60);
nSec := abs(cast("@timeIn" - nHour *3600 - nMin * 60 as integer));
--"@timeOut":=cast(nHour as varchar)||' '||cast(nMin as varchar) ||' '|| cast(nSec as varchar);
 if nHour < 10 then  "@timeOut" := '0' || cast(nHour as varchar(1));
  else  "@timeOut":=Trim(cast(nHour as varchar(10)));
  end if;

if nMin < 10 then cMin := '0' || cast(nMin as varchar(1));
  else  cMin := cast(nMin as varchar(2));
end if;
  
if nSec < 10 then cSec := '0' || cast(nSec as varchar(1));
  else  cSec = cast(nSec as varchar(2));
end if;

"@timeOut" := "@timeOut" || ':' || cMin || ':' || cSec;

 end;
end if;












end;
$$
