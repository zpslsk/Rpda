CREATE FUNCTION S_WU_DEPO1 () RETURNS integer
	LANGUAGE plpgsql
AS $$
begin
insert into "DIRECTORY_DEPOT"("RAILROAD_ID","NAME_DEPOT","DESCRIPTION_DEPOT","CODE_DEPOT")
      Values(4,'ТЧ-9','',9);
      return 0;

      end;
$$
