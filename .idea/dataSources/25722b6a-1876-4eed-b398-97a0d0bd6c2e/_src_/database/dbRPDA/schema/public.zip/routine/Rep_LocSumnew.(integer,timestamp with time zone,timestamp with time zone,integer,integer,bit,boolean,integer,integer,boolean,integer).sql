CREATE FUNCTION Rep_LocSumnew ("@nFilter" integer, "@dtStart" timestamp with time zone, "@dtFinish" timestamp with time zone, "@TypeTrain" integer, "@E_Invalidate" integer, "@EmptyLoc" bit, "@IsResidence" boolean, "@NumRoad" integer, "@NumTch" integer, "@IsDateTrains" boolean, "@TipDv" integer) RETURNS TABLE("SERIES_TRAIN_ID" integer, "CODE_CLASSIFIER" integer, "NAME_TYPE_TRAIN" character varying, cnt integer, "x_Common" numeric, "x_Auto" numeric, "x_Prompt" numeric, "trWork" numeric, train_time integer, train_time_move integer, "DrawMeter" numeric, "RecupMeter" numeric, "EBack" numeric, "ERBack" numeric, "FuelConsumpWeight" numeric, "FuelConsumpWeightCalc" numeric, "ReFuelWeight" numeric, "ReFuelCount" numeric, "Norma" numeric, "DifNorma" numeric, av_speed numeric, av_speed_move numeric, "LOCOMOTIVE_IS_RESIDENT_DEPOT" boolean, "LOCOMOTIVE_USE_AVP" bit, date_to timestamp with time zone)
	LANGUAGE plpgsql
AS $$
begin
RETURN QUERY
select 

 "DIRECTORY_SERIES_TRAINS"."SERIES_TRAIN_ID",cast("DIRECTORY_SERIES_TRAINS"."CODE_CLASSIFIER" as integer),
 "DIRECTORY_SERIES_TRAINS"."NAME_TYPE_TRAIN",cast(case when sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."x_SavpeAuto") IS NULL then 0 else count(*) end as integer) as cnt,
cast(sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."x_Common") as decimal(12,1)) as "x_Common",
cast(sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."x_SavpeAuto") as decimal(12,3)) as "x_Auto",
cast(sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."x_SavpePrompt") as decimal(12,3)) as "x_Prompt",
cast(sum("SPECIFICATION_GEN_DIAGNOSTICS"."WORK_TRAIN_tn10000Km") as decimal(15,1)) as "trWork",
cast(sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."train_time") as integer) as "train_time",
cast(sum("SPECIFICATION_DIAGNOSTICS_MOVING"."TIME_MOVING_s") as integer) as "train_time_move",
cast(sum("SPECIFICATION_SECTIONS"."ENERGY_ACTIVE") as decimal(12,1))as "DrawMeter",
cast(sum("SPECIFICATION_SECTIONS"."ENERGY_REACTIVE") as decimal(12,1))as "RecupMeter",
cast(sum("SPECIFICATION_SECTIONS"."EBack") as decimal(12,1))as "EBack",
cast(sum("SPECIFICATION_SECTIONS"."ERBack") as decimal(12,1))as "ERBack",
cast(sum("SPECIFICATION_DIAGNOSTICS_DIESEL"."REAL_CONSUMPTION_FUEL_WORK_Kg")as decimal(12,1))as FuelConsumpWeight,
cast(sum("SPECIFICATION_DIAGNOSTICS_DIESEL"."CALCULATED_CONSUMPTION_FUEL_WORK_Kg")as decimal(12,1))as FuelConsumpWeightCalc,
cast(sum("SPECIFICATION_DIAGNOSTICS_DIESEL"."EQUIP_FUEL_Kg")as decimal(12,1))as ReFuelWeight,
cast(sum("SPECIFICATION_DIAGNOSTICS_DIESEL"."ReFuelCount")as decimal(12,1))as ReFuelCount,
cast(sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."Norma") as decimal(12,1)) as Norma,
(case sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."Norma") when 0 then 0 else
cast((sum("SPECIFICATION_SECTIONS"."ENERGY_ACTIVE")-sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."Norma"))/sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."Norma")*100 as decimal(12,1)) end) as DifNorma,
cast(avg("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."av_speed") AS decimal(12,2))as "av_speed",
cast(avg("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."av_speed_move") AS decimal(12,2))as "av_speed_move",
"DIRECTORY_SERIES_TRAINS"."LOCOMOTIVE_IS_RESIDENT_DEPOT","DIRECTORY_SERIES_TRAINS"."LOCOMOTIVE_USE_AVP","DIRECTORY_SERIES_TRAINS"."DATE_TIME_SAVE_IN_AWS" as date_to






from "SPECIFICATION_ROUTE_UNITS"
inner join "SPECIFICATION_ROUTE_UNITS_GEN_INFO" on "SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS_GEN_INFO"."UNIT_ROUTE_ID"
inner join "DIRECTORY_DRIVERS" on "DIRECTORY_DRIVERS"."DRIVER_ID"="SPECIFICATION_ROUTE_UNITS"."DRIVER_ID"
inner join "FILELIST_CARTRIDGES" on "FILELIST_CARTRIDGES"."FILE_CARTRIDGE_ID"="SPECIFICATION_ROUTE_UNITS"."FILE_CARTRIDGE_ID"
inner join "DIRECTORY_RAILROADS" on "DIRECTORY_RAILROADS"."RAILROAD_ID"="SPECIFICATION_ROUTE_UNITS"."RAILROAD_ID"
inner join "DIRECTORY_DEPOT" on "SPECIFICATION_ROUTE_UNITS"."DEPOT_ID"="DIRECTORY_DEPOT"."DEPOT_ID"
inner join "SPECIFICATION_GEN_DIAGNOSTICS" on "SPECIFICATION_GEN_DIAGNOSTICS"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"
inner join "SPECIFICATION_DIAGNOSTICS_MOVING" on "SPECIFICATION_DIAGNOSTICS_MOVING"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"
inner join "SPECIFICATION_SECTIONS" on "SPECIFICATION_SECTIONS"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"
inner join "SPECIFICATION_DIAGNOSTICS_DIESEL" on "SPECIFICATION_SECTIONS"."SECTION_ID"="SPECIFICATION_DIAGNOSTICS_DIESEL"."SECTION_ID"
full join "DIRECTORY_SERIES_TRAINS" on "DIRECTORY_SERIES_TRAINS"."DEPOT_ID"="DIRECTORY_DEPOT"."DEPOT_ID" and "DIRECTORY_SERIES_TRAINS"."RAILROAD_ID"="DIRECTORY_RAILROADS"."RAILROAD_ID"
left join "DIRECTORY_TYPE_SERIES_TRAINS" on "DIRECTORY_TYPE_SERIES_TRAINS"."TYPE_SERIES_TRAIN_ID"="DIRECTORY_SERIES_TRAINS"."TYPE_SERIES_TRAIN_ID"
left join "Rep_Filter" R1 on R1."nFilter" = "@nFilter" and R1."FCode" = 1 and "DIRECTORY_SERIES_TRAINS"."SERIES_TRAIN_ID" = R1."FValue"
left join "Rep_Filter" R2 on R2."nFilter" = "@nFilter" and R2."FCode" = 2 and "DIRECTORY_DRIVERS"."DRIVER_ID" = R2."FValue"

--left join "DIRECTORY_RAILROAD_DIRECTIONS" on "DIRECTORY_RAILROAD_DIRECTIONS"."RAILROAD_DIRECTION_ID"="SPECIFICATION_ROUTE_UNITS"."RAILROAD_DIRECTION_ID" 
--left join "DIRECTORY_STATIONS" on "DIRECTORY_STATIONS"."STATION_ID"="DIRECTORY_RAILROAD_DIRECTIONS"."STATION_ID"
--left join "SPECIFICATION_TRAIN_SCHEDULES" on "SPECIFICATION_TRAIN_SCHEDULES"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"

where 
(
((("SPECIFICATION_ROUTE_UNITS"."DATE_TIME_TRIP_BEGIN" between "@dtStart" and "@dtFinish") or (1 = cast("@EmptyLoc" as integer))) and "@IsDateTrains" =true) or
((("SPECIFICATION_ROUTE_UNITS"."DATE_READ_FILE_CARTRIDGE" between "@dtStart" and "@dtFinish") or (1 = cast("@EmptyLoc" as integer))) and "@IsDateTrains" = false)
) and

"SPECIFICATION_ROUTE_UNITS"."ID_TYPE_MOVING"="@TipDv" and
R1."FValue" is NULL and R2."FValue" is NULL 
 and

 (
(("DIRECTORY_SERIES_TRAINS"."TYPE_SERIES_TRAIN_ID" =  "@TypeTrain") and (("DIRECTORY_SERIES_TRAINS"."TYPE_SERIES_TRAIN_ID" < 5) or ("DIRECTORY_SERIES_TRAINS"."TYPE_SERIES_TRAIN_ID"  > 14))) or
((("@TypeTrain" >= 5) and ("@TypeTrain" <= 14)) and (("DIRECTORY_SERIES_TRAINS"."TYPE_SERIES_TRAIN_ID" >= 5) and ("DIRECTORY_SERIES_TRAINS"."TYPE_SERIES_TRAIN_ID" <= 14)) )
)

and (("@E_Invalidate" = -1) or ("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."E_Invalidate" =cast("@E_Invalidate" as bit)))
and (("DIRECTORY_SERIES_TRAINS"."LOCOMOTIVE_IS_RESIDENT_DEPOT" = "@IsResidence") or ("@IsResidence" = false))
and (("@NumRoad" = 0) or ("DIRECTORY_RAILROADS"."CODE_RAILROAD" = "@NumRoad"))
and (("@NumTch" = 0) or ("DIRECTORY_DEPOT"."CODE_DEPOT" = "@NumTch"))

group by "DIRECTORY_SERIES_TRAINS"."SERIES_TRAIN_ID",cast("DIRECTORY_SERIES_TRAINS"."CODE_CLASSIFIER" as integer),
 "DIRECTORY_SERIES_TRAINS"."NAME_TYPE_TRAIN","DIRECTORY_SERIES_TRAINS"."LOCOMOTIVE_IS_RESIDENT_DEPOT";

end;
$$
