CREATE FUNCTION Rep_ItogTxt1 ("@dtStart" timestamp with time zone, "@dtFinish" timestamp with time zone, "@E_Invalidate" integer, "@IsResidence" boolean, "@NumRoad" integer, "@NumTch" integer, "@IsDateTrains" boolean) RETURNS TABLE(iid integer, iid1 integer, pokname character varying, result character varying)
	LANGUAGE plpgsql
AS $$
declare countTr integer;
declare runCommon float;
declare runAuto float;
declare runPrompt float;
declare timeCommon float;
declare timeStop float;
declare Work1 Float;
declare DrawMeter float;
declare DrawMeterSpec float;
declare RecMeter float;
declare React float;
declare Norma float;
declare vUch float;
declare vTex float;
declare avgWeigth float;
declare avgLen float;
declare countCLim integer;
declare avgCountCLim float;
declare countTLim integer;
declare lenAllTlim float;
declare avgCountTLim float;
declare EnMan float;
declare cTimeCommon varchar(20);
declare  cTimeAuto varchar(20);
declare cTimeStop varchar(20);
declare i integer;
declare sumWeigth float;
declare sumAxel integer;
declare avgAxelWeigth float;
/* runPrompt float, timeCommon float, timeStop float, Work1 Float,
DrawMeter float, DrawMeterSpec float, RecMeter float, React float, Norma float, vUch float, vTex float, avgWeigth float, avgLen float,
countCLim int,  avgCountCLim float, countTLim int, lenAllTlim float, avgCountTLim float, EnMan float,
cTimeCommon varchar(20), cTimeAuto varchar(20), cTimeStop varchar(20), i int, sumWeigth float, sumAxel int, avgAxelWeigth float;*/
begin
select count(*), sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."x_Common"),sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."x_SavpeAuto"),sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."x_SavpePrompt"),
sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."train_time"),sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."train_time")-sum("SPECIFICATION_DIAGNOSTICS_MOVING"."TIME_MOVING_s"),sum("SPECIFICATION_GEN_DIAGNOSTICS"."WORK_TRAIN_tn10000Km"),
sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."DrawMeter"),
case sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."x_Common" * "SPECIFICATION_ROUTE_UNITS_GEN_INFO"."NET_WEIGHT_TRAIN_Kg") when 0 then 0 else
sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."DrawMeter") *10000 / sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."x_Common" * "SPECIFICATION_ROUTE_UNITS_GEN_INFO"."NET_WEIGHT_TRAIN_Kg") end,
sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."RecupMeter"),
case sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."train_time") when 0 then 0 else
sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."x_Common")/sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."train_time")*3600 end,
case sum("SPECIFICATION_DIAGNOSTICS_MOVING"."TIME_MOVING_s") when 0 then 0 else
sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."x_Common")/sum("SPECIFICATION_DIAGNOSTICS_MOVING"."TIME_MOVING_s")*3600 end,
avg("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."NET_WEIGHT_TRAIN_Kg"),avg("SPECIFICATION_DIAGNOSTICS_MOVING"."LENGTH_TRAIN_m"),
sum("SPECIFICATION_DIAGNOSTICS_MOVING"."COUNTER_EXCEEDANCES_CONSTANT_SPEED_LIMITS"),
case count(*) when 0 then 0 else sum(1.0*"SPECIFICATION_DIAGNOSTICS_MOVING"."COUNTER_EXCEEDANCES_CONSTANT_SPEED_LIMITS")/count(*) end,
sum("SPECIFICATION_DIAGNOSTICS_MOVING"."COUNTER_EXCEEDANCES_TEMPORARY_SPEED_LIMITS"),
case count(*) when 0 then 0 else sum(1.0*"SPECIFICATION_DIAGNOSTICS_MOVING"."COUNTER_EXCEEDANCES_TEMPORARY_SPEED_LIMITS")/count(*) end,
sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."Norma"),sum("SUM_LENGTH_TIME_LIMIT_m") / 1000,sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."NET_WEIGHT_TRAIN_Kg"),sum("SPECIFICATION_DIAGNOSTICS_MOVING"."COUNT_AXLES_TRAIN")

 into countTr,runCommon,runAuto,runPrompt,timeCommon,timeStop,Work1,DrawMeter,DrawMeterSpec,RecMeter,vUch,vTex,avgWeigth,avgLen,countCLim,avgCountCLim,countTLim,avgCountTLim,Norma,lenAllTlim,sumWeigth,sumAxel






from "SPECIFICATION_ROUTE_UNITS" 
inner join "SPECIFICATION_ROUTE_UNITS_GEN_INFO" on "SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS_GEN_INFO"."UNIT_ROUTE_ID"
inner join "DIRECTORY_RAILROADS" on "DIRECTORY_RAILROADS"."RAILROAD_ID"="SPECIFICATION_ROUTE_UNITS"."RAILROAD_ID"
inner join "DIRECTORY_DEPOT" on "SPECIFICATION_ROUTE_UNITS"."DEPOT_ID"="DIRECTORY_DEPOT"."DEPOT_ID"
inner join "DIRECTORY_SERIES_TRAINS" on "DIRECTORY_SERIES_TRAINS"."DEPOT_ID"="DIRECTORY_DEPOT"."DEPOT_ID" and "DIRECTORY_SERIES_TRAINS"."RAILROAD_ID"="DIRECTORY_RAILROADS"."RAILROAD_ID"
inner join "FILELIST_CARTRIDGES" on "FILELIST_CARTRIDGES"."FILE_CARTRIDGE_ID"="SPECIFICATION_ROUTE_UNITS"."FILE_CARTRIDGE_ID"
inner join "DIRECTORY_TYPE_SERIES_TRAINS" on "DIRECTORY_TYPE_SERIES_TRAINS"."TYPE_SERIES_TRAIN_ID"="DIRECTORY_SERIES_TRAINS"."TYPE_SERIES_TRAIN_ID"
inner join "SPECIFICATION_DIAGNOSTICS_MOVING" on "SPECIFICATION_DIAGNOSTICS_MOVING"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"
inner join "SPECIFICATION_GEN_DIAGNOSTICS" on "SPECIFICATION_GEN_DIAGNOSTICS"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"
where
"DIRECTORY_TYPE_SERIES_TRAINS"."type_code" not in (17, 18, 19, 20) and

(
("SPECIFICATION_ROUTE_UNITS"."DATE_TIME_TRIP_BEGIN" between "@dtStart" and "@dtFinish" and "@IsDateTrains" =true) or
("SPECIFICATION_ROUTE_UNITS"."DATE_READ_FILE_CARTRIDGE" between "@dtStart" and "@dtFinish" and "@IsDateTrains" = false)
) 

and (("@E_Invalidate" = -1) or ("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."E_Invalidate" =cast("@E_Invalidate" as bit)))
and (("DIRECTORY_SERIES_TRAINS"."LOCOMOTIVE_IS_RESIDENT_DEPOT" = "@IsResidence") or ("@IsResidence" = false))
and (("@NumRoad" = 0) or ("DIRECTORY_RAILROADS"."CODE_RAILROAD" = "@NumRoad"))
and (("@NumTch" = 0) or ("DIRECTORY_DEPOT"."CODE_DEPOT" = "@NumTch"));



select 
coalesce(sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."RecupMeter"), 0) into RecMeter



from "SPECIFICATION_ROUTE_UNITS" 
inner join "SPECIFICATION_ROUTE_UNITS_GEN_INFO" on "SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS_GEN_INFO"."UNIT_ROUTE_ID"
inner join "DIRECTORY_RAILROADS" on "DIRECTORY_RAILROADS"."RAILROAD_ID"="SPECIFICATION_ROUTE_UNITS"."RAILROAD_ID"
inner join "DIRECTORY_DEPOT" on "SPECIFICATION_ROUTE_UNITS"."DEPOT_ID"="DIRECTORY_DEPOT"."DEPOT_ID"
inner join "DIRECTORY_SERIES_TRAINS" on "DIRECTORY_SERIES_TRAINS"."DEPOT_ID"="DIRECTORY_DEPOT"."DEPOT_ID" and "DIRECTORY_SERIES_TRAINS"."RAILROAD_ID"="DIRECTORY_RAILROADS"."RAILROAD_ID"
inner join "FILELIST_CARTRIDGES" on "FILELIST_CARTRIDGES"."FILE_CARTRIDGE_ID"="SPECIFICATION_ROUTE_UNITS"."FILE_CARTRIDGE_ID"
inner join "DIRECTORY_TYPE_SERIES_TRAINS" on "DIRECTORY_TYPE_SERIES_TRAINS"."TYPE_SERIES_TRAIN_ID"="DIRECTORY_SERIES_TRAINS"."TYPE_SERIES_TRAIN_ID"
inner join "SPECIFICATION_DIAGNOSTICS_MOVING" on "SPECIFICATION_DIAGNOSTICS_MOVING"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"

where
"DIRECTORY_TYPE_SERIES_TRAINS"."type_code" =2 and

(
("SPECIFICATION_ROUTE_UNITS"."DATE_TIME_TRIP_BEGIN" between "@dtStart" and "@dtFinish" and "@IsDateTrains" =true) or
("SPECIFICATION_ROUTE_UNITS"."DATE_READ_FILE_CARTRIDGE" between "@dtStart" and "@dtFinish" and "@IsDateTrains" = false)
) and

 (("@E_Invalidate" = -1) or ("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."E_Invalidate" =cast("@E_Invalidate" as bit)))
and (("DIRECTORY_SERIES_TRAINS"."LOCOMOTIVE_IS_RESIDENT_DEPOT" = "@IsResidence") or ("@IsResidence" = false))
and (("@NumRoad" = 0) or ("DIRECTORY_RAILROADS"."CODE_RAILROAD" = "@NumRoad"))
and (("@NumTch" = 0) or ("DIRECTORY_DEPOT"."CODE_DEPOT" = "@NumTch"));




select

coalesce(sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."RecupMeter"), 0) into React



from "SPECIFICATION_ROUTE_UNITS" 
inner join "SPECIFICATION_ROUTE_UNITS_GEN_INFO" on "SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS_GEN_INFO"."UNIT_ROUTE_ID"
inner join "DIRECTORY_RAILROADS" on "DIRECTORY_RAILROADS"."RAILROAD_ID"="SPECIFICATION_ROUTE_UNITS"."RAILROAD_ID"
inner join "DIRECTORY_DEPOT" on "SPECIFICATION_ROUTE_UNITS"."DEPOT_ID"="DIRECTORY_DEPOT"."DEPOT_ID"
inner join "DIRECTORY_SERIES_TRAINS" on "DIRECTORY_SERIES_TRAINS"."DEPOT_ID"="DIRECTORY_DEPOT"."DEPOT_ID" and "DIRECTORY_SERIES_TRAINS"."RAILROAD_ID"="DIRECTORY_RAILROADS"."RAILROAD_ID"
inner join "FILELIST_CARTRIDGES" on "FILELIST_CARTRIDGES"."FILE_CARTRIDGE_ID"="SPECIFICATION_ROUTE_UNITS"."FILE_CARTRIDGE_ID"
inner join "DIRECTORY_TYPE_SERIES_TRAINS" on "DIRECTORY_TYPE_SERIES_TRAINS"."TYPE_SERIES_TRAIN_ID"="DIRECTORY_SERIES_TRAINS"."TYPE_SERIES_TRAIN_ID"
inner join "SPECIFICATION_DIAGNOSTICS_MOVING" on "SPECIFICATION_DIAGNOSTICS_MOVING"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"

where
"DIRECTORY_TYPE_SERIES_TRAINS"."type_code" =3 and

(
("SPECIFICATION_ROUTE_UNITS"."DATE_TIME_TRIP_BEGIN" between "@dtStart" and "@dtFinish" and "@IsDateTrains" =true) or
("SPECIFICATION_ROUTE_UNITS"."DATE_READ_FILE_CARTRIDGE" between "@dtStart" and "@dtFinish" and "@IsDateTrains" = false)
) and

 (("@E_Invalidate" = -1) or ("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."E_Invalidate" =cast("@E_Invalidate" as bit)))
and (("DIRECTORY_SERIES_TRAINS"."LOCOMOTIVE_IS_RESIDENT_DEPOT" = "@IsResidence") or ("@IsResidence" = false))
and (("@NumRoad" = 0) or ("DIRECTORY_RAILROADS"."CODE_RAILROAD" = "@NumRoad"))
and (("@NumTch" = 0) or ("DIRECTORY_DEPOT"."CODE_DEPOT" = "@NumTch"));


if exists(select * from INFORMATION_SCHEMA.COLUMNS where table_name='FILELIST_CARTRIDGES' and

column_name = 'EnMan')
then

begin
select sum("FILELIST_CARTRIDGES"."EnMan") into EnMan
from "FILELIST_CARTRIDGES" where exists(Select *
from "SPECIFICATION_ROUTE_UNITS" 
inner join "SPECIFICATION_ROUTE_UNITS_GEN_INFO" on "SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS_GEN_INFO"."UNIT_ROUTE_ID"
inner join "DIRECTORY_RAILROADS" on "DIRECTORY_RAILROADS"."RAILROAD_ID"="SPECIFICATION_ROUTE_UNITS"."RAILROAD_ID"
inner join "DIRECTORY_DEPOT" on "SPECIFICATION_ROUTE_UNITS"."DEPOT_ID"="DIRECTORY_DEPOT"."DEPOT_ID"
inner join "DIRECTORY_SERIES_TRAINS" on "DIRECTORY_SERIES_TRAINS"."DEPOT_ID"="DIRECTORY_DEPOT"."DEPOT_ID" and "DIRECTORY_SERIES_TRAINS"."RAILROAD_ID"="DIRECTORY_RAILROADS"."RAILROAD_ID"
where "SPECIFICATION_ROUTE_UNITS"."FILE_CARTRIDGE_ID" = "FILELIST_CARTRIDGES"."FILE_CARTRIDGE_ID"  and
 (
("SPECIFICATION_ROUTE_UNITS"."DATE_TIME_TRIP_BEGIN" between "@dtStart" and "@dtFinish" and "@IsDateTrains" =true) or
("SPECIFICATION_ROUTE_UNITS"."DATE_READ_FILE_CARTRIDGE" between "@dtStart" and "@dtFinish" and "@IsDateTrains" = false)
) and

 (("@E_Invalidate" = -1) or ("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."E_Invalidate" =cast("@E_Invalidate" as bit)))
and (("DIRECTORY_SERIES_TRAINS"."LOCOMOTIVE_IS_RESIDENT_DEPOT" = "@IsResidence") or ("@IsResidence" = false))
and (("@NumRoad" = 0) or ("DIRECTORY_RAILROADS"."CODE_RAILROAD" = "@NumRoad"))
and (("@NumTch" = 0) or ("DIRECTORY_DEPOT"."CODE_DEPOT" = "@NumTch")));

end;
END IF;


SELECT cTimeCommon ="sp_SecInHHMMSS"(
    timeCommon
);

SELECT cTimeStop="sp_SecInHHMMSS"(
    timeStop 
);

if sumAxel=0 then avgAxelWeigth := 0.0;

else  avgAxelWeigth := sumWeigth/sumAxel;
end if;

RETURN QUERY
select   0 as iid, -1, N'Эксплуатационные показатели', '' union
select  10 as iid, 0, N'Число маршрутов', LTrim(str(countTr,10)) union
select  20 as iid, 0, N'Суммарный поездной пробег, км', LTrim(str(runCommon,15,1)) union
select  30 as iid, 1, N'Пробег в автоведении, км', LTrim(str(runAuto,15,1))+' ('+LTrim(str(case runCommon when 0 then 0 else 100.0*runAuto/runCommon end,7,1))+'%)' union
select  31 as iid, 1, N'Пробег в режиме подсказки, км', LTrim(str(runPrompt,15,1))+' ('+LTrim(str(case runCommon when 0 then 0 else 100.0*runPrompt/runCommon end,7,1))+'%)' union
select  40 as iid, 0, N'Общее время работы', cTimeCommon union
select  60 as iid, 1, N'Время простоя', cTimeStop union
select  70 as iid, 0, N'Суммарная поездная работа, тКм * 10000', LTrim(str(Work1,15,1)) union
select  80 as iid, 0, N'Средняя участковая скорость, км/ч', LTrim(str(vUch,15,1)) union
select  90 as iid, 0, N'Средняя техническая скорость, км/ч', LTrim(str(vTex,15,1)) union
select 100 as iid, 0, N'Средняя масса состава, т', LTrim(str(avgWeigth,15,1)) union
select 110 as iid, 0, N'Средняя длина состава, м', LTrim(str(avgLen,15,1)) union
select 111 as iid, 0, N'Средняя нагрузка на ось, т', LTrim(str(avgAxelWeigth,15,1)) union
select 120 as iid, -1, N'Энергетические показатели', '' union
select 130 as iid, 0, N'Общий расход энергии по счетчикам, кВт*ч', LTrim(str(DrawMeter,15,1)) union
select 140 as iid, 0, N'Удельный расход по счетчикам, кВт.ч х 10000 / т.км.бр', LTrim(str(DrawMeterSpec,15,1)) union
select 150 as iid, 0, N'Общая энергия рекуперации, кВт*ч', LTrim(str(RecMeter,15,1)) union
select 160 as iid, 0, N'Норма расхода энергии, кВт*ч', LTrim(str(Norma,15,1)) union
/**/
select 161 as iid, 0, N'Реактивная энергия, кВт*ч', LTrim(str(React,15,1)) union
select 162 as iid, 0, N'Маневровые работы, кВт*ч', LTrim(str(EnMan,15,1)) union
/**/
select 170 as iid, -1, N'Ограничения скорости', '' union
select 180 as iid, 0, N'Общее кол-во постоянных ограничений', LTrim(str(countCLim,8)) union
select 200 as iid, 1, N'Среднее кол-во на маршрут', LTrim(str(avgCountCLim,15,1)) union
select 210 as iid, 0, N'Общее кол-во предупреждений', LTrim(str(countTLim,8)) union
select 220 as iid, 1, N'Суммарная протяженность, км', LTrim(str(lenAllTlim,15,1)) union
select 230 as iid, 1, N'Среднее кол-во на маршрут', LTrim(str(avgCountTLim,15,1))
order by iid;

end;
$$
