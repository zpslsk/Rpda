CREATE FUNCTION Rep_ItogTxtTep ("@dtStart" timestamp with time zone, "@dtFinish" timestamp with time zone, "@E_Invalidate" integer, "@IsResidence" boolean, "@NumRoad" integer, "@NumTch" integer, "@IsDateTrains" boolean, "@TipDv" integer) RETURNS TABLE("IID" integer, "IID1" integer, "POKNAME" character varying, "RESULT" character varying)
	LANGUAGE plpgsql
AS $$
declare countTr integer;
declare runCommon float;
declare runAuto float;
declare runPrompt float;
declare timeCommon float;
declare timeStop float;
declare Work1 Float;
declare DrawMeter float;
declare DrawMeterSpec float;
declare RecMeter float;
declare React float;
declare Norma float;
declare vUch float;
declare vTex float;
declare avgWeigth float;
declare avgLen float;
declare countCLim integer;
declare avgCountCLim float;
declare countTLim integer;
declare lenAllTlim float;
declare avgCountTLim float;
declare EnMan float;
declare cTimeCommon varchar(20);
declare  cTimeAuto varchar(20);
declare cTimeStop varchar(20);
declare i integer;
declare sumWeigth float;
declare sumAxel integer;
declare avgAxelWeigth float;
declare FuelConsumpWeight float;
declare FuelConsumpWeightCalc float;
declare ReFuelWeight float;
declare ReFuelCount integer;
/* runPrompt float, timeCommon float, timeStop float, Work1 Float,
DrawMeter float, DrawMeterSpec float, RecMeter float, React float, Norma float, vUch float, vTex float, avgWeigth float, avgLen float,
countCLim int,  avgCountCLim float, countTLim int, lenAllTlim float, avgCountTLim float, EnMan float,
cTimeCommon varchar(20), cTimeAuto varchar(20), cTimeStop varchar(20), i int, sumWeigth float, sumAxel int, avgAxelWeigth float;*/
begin
select count(*), sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."x_Common"),sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."x_SavpeAuto"),sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."x_SavpePrompt"),
sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."train_time"),sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."train_time")-sum("SPECIFICATION_DIAGNOSTICS_MOVING"."TIME_MOVING_s"),sum("SPECIFICATION_GEN_DIAGNOSTICS"."WORK_TRAIN_tn10000Km"),
sum("SPECIFICATION_SECTIONS"."ENERGY_ACTIVE"),
case sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."x_Common" * "SPECIFICATION_ROUTE_UNITS_GEN_INFO"."NET_WEIGHT_TRAIN_Kg") when 0 then 0 else
sum("SPECIFICATION_SECTIONS"."ENERGY_ACTIVE") *10000 / sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."x_Common" * "SPECIFICATION_ROUTE_UNITS_GEN_INFO"."NET_WEIGHT_TRAIN_Kg") end,
sum("SPECIFICATION_SECTIONS"."ENERGY_REACTIVE"),
case sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."train_time") when 0 then 0 else
sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."x_Common")/sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."train_time")*3600 end,
case sum("SPECIFICATION_DIAGNOSTICS_MOVING"."TIME_MOVING_s") when 0 then 0 else
sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."x_Common")/sum("SPECIFICATION_DIAGNOSTICS_MOVING"."TIME_MOVING_s")*3600 end,
avg("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."NET_WEIGHT_TRAIN_Kg"),avg("SPECIFICATION_DIAGNOSTICS_MOVING"."LENGTH_TRAIN_m"),
sum("SPECIFICATION_DIAGNOSTICS_MOVING"."COUNTER_EXCEEDANCES_CONSTANT_SPEED_LIMITS"),
case count(*) when 0 then 0 else sum(1.0*"SPECIFICATION_DIAGNOSTICS_MOVING"."COUNTER_EXCEEDANCES_CONSTANT_SPEED_LIMITS")/count(*) end,
sum("SPECIFICATION_DIAGNOSTICS_MOVING"."COUNTER_EXCEEDANCES_TEMPORARY_SPEED_LIMITS"),
case count(*) when 0 then 0 else sum(1.0*"SPECIFICATION_DIAGNOSTICS_MOVING"."COUNTER_EXCEEDANCES_TEMPORARY_SPEED_LIMITS")/count(*) end,
sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."Norma"),sum("SUM_LENGTH_TIME_LIMIT_m") / 1000,sum("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."NET_WEIGHT_TRAIN_Kg"),sum("SPECIFICATION_DIAGNOSTICS_MOVING"."COUNT_AXLES_TRAIN")--,
--sum("SPECIFICATION_DIAGNOSTICS_DIESEL"."REAL_CONSUMPTION_FUEL_WORK_Kg"),sum("SPECIFICATION_DIAGNOSTICS_DIESEL"."CALCULATED_CONSUMPTION_FUEL_WORK_Kg"),
--sum("SPECIFICATION_DIAGNOSTICS_DIESEL"."EQUIP_FUEL_Kg"),sum("SPECIFICATION_DIAGNOSTICS_DIESEL"."ReFuelCount")

 into countTr,runCommon,runAuto,runPrompt,timeCommon,timeStop,Work1,DrawMeter,DrawMeterSpec,RecMeter,vUch,vTex,avgWeigth,avgLen,countCLim,avgCountCLim,countTLim,avgCountTLim,Norma,lenAllTlim,sumWeigth,sumAxel--,FuelConsumpWeight,FuelConsumpWeightCalc,ReFuelWeight,ReFuelCount






from "SPECIFICATION_ROUTE_UNITS" 
inner join "SPECIFICATION_ROUTE_UNITS_GEN_INFO" on "SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS_GEN_INFO"."UNIT_ROUTE_ID"
inner join "DIRECTORY_RAILROADS" on "DIRECTORY_RAILROADS"."RAILROAD_ID"="SPECIFICATION_ROUTE_UNITS"."RAILROAD_ID"
inner join "DIRECTORY_DEPOT" on "SPECIFICATION_ROUTE_UNITS"."DEPOT_ID"="DIRECTORY_DEPOT"."DEPOT_ID"
inner join "DIRECTORY_SERIES_TRAINS" on "DIRECTORY_SERIES_TRAINS"."DEPOT_ID"="DIRECTORY_DEPOT"."DEPOT_ID" and "DIRECTORY_SERIES_TRAINS"."RAILROAD_ID"="DIRECTORY_RAILROADS"."RAILROAD_ID"
inner join "FILELIST_CARTRIDGES" on "FILELIST_CARTRIDGES"."FILE_CARTRIDGE_ID"="SPECIFICATION_ROUTE_UNITS"."FILE_CARTRIDGE_ID"
inner join "DIRECTORY_TYPE_SERIES_TRAINS" on "DIRECTORY_TYPE_SERIES_TRAINS"."TYPE_SERIES_TRAIN_ID"="DIRECTORY_SERIES_TRAINS"."TYPE_SERIES_TRAIN_ID"
inner join "SPECIFICATION_DIAGNOSTICS_MOVING" on "SPECIFICATION_DIAGNOSTICS_MOVING"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"
inner join "SPECIFICATION_GEN_DIAGNOSTICS" on "SPECIFICATION_GEN_DIAGNOSTICS"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"
inner join "SPECIFICATION_SECTIONS" on "SPECIFICATION_SECTIONS"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"
--inner join "SPECIFICATION_DIAGNOSTICS_DIESEL" on "SPECIFICATION_DIAGNOSTICS_DIESEL"."SECTION_ID"="SPECIFICATION_SECTIONS"."SECTION_ID"

where
"DIRECTORY_TYPE_SERIES_TRAINS"."TYPE_SERIES_TRAIN_ID"  in (513, 514, 515, 516,517,518,519,520,521,522,523,524,525,526,527,528,529,530,531,532,533,534,535,536,537,538,539) and

(
("SPECIFICATION_ROUTE_UNITS"."DATE_TIME_TRIP_BEGIN" between "@dtStart" and "@dtFinish" and "@IsDateTrains" =true) or
("SPECIFICATION_ROUTE_UNITS"."DATE_READ_FILE_CARTRIDGE" between "@dtStart" and "@dtFinish" and "@IsDateTrains" = false)
) 
  and ("SPECIFICATION_ROUTE_UNITS"."ID_TYPE_MOVING"="@TipDv" or "@TipDv"=1000)
 and (("@E_Invalidate" = -1) or ("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."E_Invalidate" =cast("@E_Invalidate" as bit)))
and "SPECIFICATION_ROUTE_UNITS_GEN_INFO"."av_speed"<100 
and "SPECIFICATION_ROUTE_UNITS_GEN_INFO"."av_speed_move"<100
and (("DIRECTORY_SERIES_TRAINS"."LOCOMOTIVE_IS_RESIDENT_DEPOT" = "@IsResidence") or ("@IsResidence" = false))
and (("@NumRoad" = 0) or ("DIRECTORY_RAILROADS"."CODE_RAILROAD" = "@NumRoad"))
and (("@NumTch" = 0) or ("DIRECTORY_DEPOT"."CODE_DEPOT" = "@NumTch"));







select 
sum("SPECIFICATION_DIAGNOSTICS_DIESEL"."REAL_CONSUMPTION_FUEL_WORK_Kg"),sum("SPECIFICATION_DIAGNOSTICS_DIESEL"."CALCULATED_CONSUMPTION_FUEL_WORK_Kg"),
sum("SPECIFICATION_DIAGNOSTICS_DIESEL"."EQUIP_FUEL_Kg"),sum("SPECIFICATION_DIAGNOSTICS_DIESEL"."ReFuelCount")

 into FuelConsumpWeight,FuelConsumpWeightCalc,ReFuelWeight,ReFuelCount






from "SPECIFICATION_ROUTE_UNITS" 
inner join "SPECIFICATION_ROUTE_UNITS_GEN_INFO" on "SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS_GEN_INFO"."UNIT_ROUTE_ID"
inner join "DIRECTORY_RAILROADS" on "DIRECTORY_RAILROADS"."RAILROAD_ID"="SPECIFICATION_ROUTE_UNITS"."RAILROAD_ID"
inner join "DIRECTORY_DEPOT" on "SPECIFICATION_ROUTE_UNITS"."DEPOT_ID"="DIRECTORY_DEPOT"."DEPOT_ID"
inner join "DIRECTORY_SERIES_TRAINS" on "DIRECTORY_SERIES_TRAINS"."DEPOT_ID"="DIRECTORY_DEPOT"."DEPOT_ID" and "DIRECTORY_SERIES_TRAINS"."RAILROAD_ID"="DIRECTORY_RAILROADS"."RAILROAD_ID"
inner join "FILELIST_CARTRIDGES" on "FILELIST_CARTRIDGES"."FILE_CARTRIDGE_ID"="SPECIFICATION_ROUTE_UNITS"."FILE_CARTRIDGE_ID"
inner join "DIRECTORY_TYPE_SERIES_TRAINS" on "DIRECTORY_TYPE_SERIES_TRAINS"."TYPE_SERIES_TRAIN_ID"="DIRECTORY_SERIES_TRAINS"."TYPE_SERIES_TRAIN_ID"
inner join "SPECIFICATION_DIAGNOSTICS_MOVING" on "SPECIFICATION_DIAGNOSTICS_MOVING"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"
inner join "SPECIFICATION_GEN_DIAGNOSTICS" on "SPECIFICATION_GEN_DIAGNOSTICS"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"
inner join "SPECIFICATION_SECTIONS" on "SPECIFICATION_SECTIONS"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"
inner join "SPECIFICATION_DIAGNOSTICS_DIESEL" on "SPECIFICATION_DIAGNOSTICS_DIESEL"."SECTION_ID"="SPECIFICATION_SECTIONS"."SECTION_ID"

where
"DIRECTORY_TYPE_SERIES_TRAINS"."TYPE_SERIES_TRAIN_ID"  in (513, 514, 515, 516,517,518,519,520,521,522,523,524,525,526,527,528,529,530,531,532,533,534,535,536,537,538,539) and

(
("SPECIFICATION_ROUTE_UNITS"."DATE_TIME_TRIP_BEGIN" between "@dtStart" and "@dtFinish" and "@IsDateTrains" =true) or
("SPECIFICATION_ROUTE_UNITS"."DATE_READ_FILE_CARTRIDGE" between "@dtStart" and "@dtFinish" and "@IsDateTrains" = false)
) 
 and ("SPECIFICATION_ROUTE_UNITS"."ID_TYPE_MOVING"="@TipDv" or "@TipDv"=1000)

and (("@E_Invalidate" = -1) or ("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."E_Invalidate" =cast("@E_Invalidate" as bit)))
and "SPECIFICATION_ROUTE_UNITS_GEN_INFO"."av_speed"<100 
and "SPECIFICATION_ROUTE_UNITS_GEN_INFO"."av_speed_move"<100
and (("DIRECTORY_SERIES_TRAINS"."LOCOMOTIVE_IS_RESIDENT_DEPOT" = "@IsResidence") or ("@IsResidence" = false))
and (("@NumRoad" = 0) or ("DIRECTORY_RAILROADS"."CODE_RAILROAD" = "@NumRoad"))
and (("@NumTch" = 0) or ("DIRECTORY_DEPOT"."CODE_DEPOT" = "@NumTch"));






select 
coalesce(sum("SPECIFICATION_SECTIONS"."ENERGY_REACTIVE"), 0) into RecMeter



from "SPECIFICATION_ROUTE_UNITS" 
inner join "SPECIFICATION_ROUTE_UNITS_GEN_INFO" on "SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS_GEN_INFO"."UNIT_ROUTE_ID"
inner join "DIRECTORY_RAILROADS" on "DIRECTORY_RAILROADS"."RAILROAD_ID"="SPECIFICATION_ROUTE_UNITS"."RAILROAD_ID"
inner join "DIRECTORY_DEPOT" on "SPECIFICATION_ROUTE_UNITS"."DEPOT_ID"="DIRECTORY_DEPOT"."DEPOT_ID"
inner join "DIRECTORY_SERIES_TRAINS" on "DIRECTORY_SERIES_TRAINS"."DEPOT_ID"="DIRECTORY_DEPOT"."DEPOT_ID" and "DIRECTORY_SERIES_TRAINS"."RAILROAD_ID"="DIRECTORY_RAILROADS"."RAILROAD_ID"
inner join "FILELIST_CARTRIDGES" on "FILELIST_CARTRIDGES"."FILE_CARTRIDGE_ID"="SPECIFICATION_ROUTE_UNITS"."FILE_CARTRIDGE_ID"
inner join "DIRECTORY_TYPE_SERIES_TRAINS" on "DIRECTORY_TYPE_SERIES_TRAINS"."TYPE_SERIES_TRAIN_ID"="DIRECTORY_SERIES_TRAINS"."TYPE_SERIES_TRAIN_ID"
inner join "SPECIFICATION_DIAGNOSTICS_MOVING" on "SPECIFICATION_DIAGNOSTICS_MOVING"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"
inner join "SPECIFICATION_SECTIONS" on "SPECIFICATION_SECTIONS"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"
where
"DIRECTORY_TYPE_SERIES_TRAINS"."TYPE_SERIES_TRAIN_ID"  in (513, 514, 515, 516,517,518,519,520,521,522,523,524,525,526,527,528,529,530,531,532,533,534,535,536,537,538,539) and

(
("SPECIFICATION_ROUTE_UNITS"."DATE_TIME_TRIP_BEGIN" between "@dtStart" and "@dtFinish" and "@IsDateTrains" =true) or
("SPECIFICATION_ROUTE_UNITS"."DATE_READ_FILE_CARTRIDGE" between "@dtStart" and "@dtFinish" and "@IsDateTrains" = false)
) and
     ("SPECIFICATION_ROUTE_UNITS"."ID_TYPE_MOVING"="@TipDv" or "@TipDv"=1000)  and
 (("@E_Invalidate" = -1) or ("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."E_Invalidate" =cast("@E_Invalidate" as bit)))
and
("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."av_speed" < 100) and
("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."av_speed_move" < 100) 
 
and (("DIRECTORY_SERIES_TRAINS"."LOCOMOTIVE_IS_RESIDENT_DEPOT" = "@IsResidence") or ("@IsResidence" = false))
and (("@NumRoad" = 0) or ("DIRECTORY_RAILROADS"."CODE_RAILROAD" = "@NumRoad"))
and (("@NumTch" = 0) or ("DIRECTORY_DEPOT"."CODE_DEPOT" = "@NumTch"));




select

coalesce(sum("SPECIFICATION_SECTIONS"."ENERGY_REACTIVE"), 0) into React



from "SPECIFICATION_ROUTE_UNITS" 
inner join "SPECIFICATION_ROUTE_UNITS_GEN_INFO" on "SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS_GEN_INFO"."UNIT_ROUTE_ID"
inner join "DIRECTORY_RAILROADS" on "DIRECTORY_RAILROADS"."RAILROAD_ID"="SPECIFICATION_ROUTE_UNITS"."RAILROAD_ID"
inner join "DIRECTORY_DEPOT" on "SPECIFICATION_ROUTE_UNITS"."DEPOT_ID"="DIRECTORY_DEPOT"."DEPOT_ID"
inner join "DIRECTORY_SERIES_TRAINS" on "DIRECTORY_SERIES_TRAINS"."DEPOT_ID"="DIRECTORY_DEPOT"."DEPOT_ID" and "DIRECTORY_SERIES_TRAINS"."RAILROAD_ID"="DIRECTORY_RAILROADS"."RAILROAD_ID"
inner join "FILELIST_CARTRIDGES" on "FILELIST_CARTRIDGES"."FILE_CARTRIDGE_ID"="SPECIFICATION_ROUTE_UNITS"."FILE_CARTRIDGE_ID"
inner join "DIRECTORY_TYPE_SERIES_TRAINS" on "DIRECTORY_TYPE_SERIES_TRAINS"."TYPE_SERIES_TRAIN_ID"="DIRECTORY_SERIES_TRAINS"."TYPE_SERIES_TRAIN_ID"
inner join "SPECIFICATION_DIAGNOSTICS_MOVING" on "SPECIFICATION_DIAGNOSTICS_MOVING"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"
inner join "SPECIFICATION_SECTIONS" on "SPECIFICATION_SECTIONS"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"
where
"DIRECTORY_TYPE_SERIES_TRAINS"."type_code" =3 and

(
("SPECIFICATION_ROUTE_UNITS"."DATE_TIME_TRIP_BEGIN" between "@dtStart" and "@dtFinish" and "@IsDateTrains" =true) or
("SPECIFICATION_ROUTE_UNITS"."DATE_READ_FILE_CARTRIDGE" between "@dtStart" and "@dtFinish" and "@IsDateTrains" = false)
) and ("SPECIFICATION_ROUTE_UNITS"."ID_TYPE_MOVING"="@TipDv" or "@TipDv"=1000)  and  

 (("@E_Invalidate" = -1) or ("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."E_Invalidate" =cast("@E_Invalidate" as bit)))

and
("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."av_speed" < 100) and
("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."av_speed_move" < 100) 
 
 
and (("DIRECTORY_SERIES_TRAINS"."LOCOMOTIVE_IS_RESIDENT_DEPOT" = "@IsResidence") or ("@IsResidence" = false))
and (("@NumRoad" = 0) or ("DIRECTORY_RAILROADS"."CODE_RAILROAD" = "@NumRoad"))
and (("@NumTch" = 0) or ("DIRECTORY_DEPOT"."CODE_DEPOT" = "@NumTch"));


if exists(select * from INFORMATION_SCHEMA.COLUMNS where table_name='FILELIST_CARTRIDGES' and

column_name = 'EnMan')
then

begin
select sum("FILELIST_CARTRIDGES"."EnMan") into EnMan
from "FILELIST_CARTRIDGES" where exists(Select *
from "SPECIFICATION_ROUTE_UNITS" 
inner join "SPECIFICATION_ROUTE_UNITS_GEN_INFO" on "SPECIFICATION_ROUTE_UNITS"."UNIT_ROUTE_ID"="SPECIFICATION_ROUTE_UNITS_GEN_INFO"."UNIT_ROUTE_ID"
inner join "DIRECTORY_RAILROADS" on "DIRECTORY_RAILROADS"."RAILROAD_ID"="SPECIFICATION_ROUTE_UNITS"."RAILROAD_ID"
inner join "DIRECTORY_DEPOT" on "SPECIFICATION_ROUTE_UNITS"."DEPOT_ID"="DIRECTORY_DEPOT"."DEPOT_ID"
inner join "DIRECTORY_SERIES_TRAINS" on "DIRECTORY_SERIES_TRAINS"."DEPOT_ID"="DIRECTORY_DEPOT"."DEPOT_ID" and "DIRECTORY_SERIES_TRAINS"."RAILROAD_ID"="DIRECTORY_RAILROADS"."RAILROAD_ID"
where "SPECIFICATION_ROUTE_UNITS"."FILE_CARTRIDGE_ID" = "FILELIST_CARTRIDGES"."FILE_CARTRIDGE_ID"  and
 (
("SPECIFICATION_ROUTE_UNITS"."DATE_TIME_TRIP_BEGIN" between "@dtStart" and "@dtFinish" and "@IsDateTrains" =true) or
("SPECIFICATION_ROUTE_UNITS"."DATE_READ_FILE_CARTRIDGE" between "@dtStart" and "@dtFinish" and "@IsDateTrains" = false)
) and ("SPECIFICATION_ROUTE_UNITS"."ID_TYPE_MOVING"="@TipDv" or "@TipDv"=1000)  and 

 (("@E_Invalidate" = -1) or ("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."E_Invalidate" =cast("@E_Invalidate" as bit)))

and
("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."av_speed" < 100) and
("SPECIFICATION_ROUTE_UNITS_GEN_INFO"."av_speed_move" < 100) 
 

 
and (("DIRECTORY_SERIES_TRAINS"."LOCOMOTIVE_IS_RESIDENT_DEPOT" = "@IsResidence") or ("@IsResidence" = false))
and (("@NumRoad" = 0) or ("DIRECTORY_RAILROADS"."CODE_RAILROAD" = "@NumRoad"))
and (("@NumTch" = 0) or ("DIRECTORY_DEPOT"."CODE_DEPOT" = "@NumTch")));

end;
END IF;


select "sp_SecInHHMMSS"(
    timeCommon
) as d into cTimeCommon;

SELECT "sp_SecInHHMMSS"(
    timeStop 
)  as d1 into cTimeStop;

if sumAxel=0 then avgAxelWeigth := 0.0;

else  avgAxelWeigth := sumWeigth/sumAxel;
end if;

RETURN QUERY
select   0 as "IID", -1 as "IID1", cast('Эксплуатационные показатели' as varchar(100)) as "POKNAME", cast(' ' as varchar(100)) as "RESULT" union
select  10 as "IID", 0 as "IID1", cast('Число маршрутов' as varchar(100)) as "POKNAME", LTrim(cast(countTr as varchar(10))) as "RESULT" union
select  20 as "IID", 0, cast('Суммарный поездной пробег, км' as varchar(100)), LTrim(cast(round(cast(runCommon as numeric),1) as varchar(15))) union
--select  30 as "IID", 1, cast('Пробег в автоведении, км' as varchar(100)), LTrim(cast(round(cast(runAuto as numeric),1) as varchar(15)))||' ('||LTrim(cast(round(cast(case runCommon when 0 then 0 else 100.0*runAuto/runCommon end as numeric),1) as varchar(7)))||'%)' union
--select  31 as "IID", 1, cast('Пробег в режиме подсказки, км' as varchar(100)), LTrim(cast(round(cast(runPrompt as numeric),1) as varchar(15))||' ('||LTrim(cast(round(cast(case runCommon when 0 then 0 else 100.0*runPrompt/runCommon end as numeric),1) as varchar(7))))||'%)' union
select  40 as "IID", 0, cast('Общее время работы' as varchar(100)), cTimeCommon union
select  60 as "IID", 1, cast('Время простоя' as varchar(100)), cTimeStop union
select  70 as "IID", 0, N'Суммарная поездная работа, тКм * 10000', LTrim(cast(round(cast(Work1 as numeric),1) as varchar(15))) union
select  80 as "IID", 0, N'Средняя участковая скорость, км/ч', LTrim(cast(round(cast(vUch as numeric),1) as varchar(15))) union
select  90 as "IID", 0, N'Средняя техническая скорость, км/ч', LTrim(cast(round(cast(vTex as numeric),1) as varchar(15))) union
--select 100 as "IID", 0, N'Средняя масса состава, т', LTrim(cast(round(cast(avgWeigth as numeric),1) as varchar(15))) union
--select 110 as "IID", 0, N'Средняя длина состава, м', LTrim(cast(round(cast(avgLen as numeric),1) as varchar(15))) union
--select 111 as "IID", 0, N'Средняя нагрузка на ось, т', LTrim(cast(round(cast(avgAxelWeigth as numeric),1) as varchar(15))) union
select 120 as "IID", -1, N'Расход топлива', ' ' union
select 130 as "IID", 0, N'Расчетный расход топлива кг.', LTrim(cast(round(cast(FuelConsumpWeightCalc as numeric),1) as varchar(15))) union
select 140 as "IID", 0, N'Фактический расход топлива кг.', LTrim(cast(round(cast(FuelConsumpWeight as numeric),1) as varchar(15))) union
select 150 as "IID", 0, N'Пережог топлива кг.', LTrim(cast(round(cast(FuelConsumpWeight - FuelConsumpWeightCalc as numeric),1) as varchar(15))) union
select 155 as "IID", 0, N'Удельный расход:', ' ' union
select 160 as "IID", 1, N'кг/ 100 км.', LTrim(cast(round(cast(FuelConsumpWeight / runCommon * 100 as numeric),1) as varchar(15))) union
select 170 as "IID", 1, N'кг/ час', LTrim(cast(round(cast(FuelConsumpWeight / (timeCommon / 3600) as numeric),1) as varchar(15))) union
select 180 as "IID", 0, N'Количество экипировок', LTrim(cast(round(cast(ReFuelCount as numeric),1) as varchar(15))) union
select 190 as "IID", 0, N'Набор топлива кг.', LTrim(cast(round(cast(ReFuelWeight as numeric),1) as varchar(15)))
/*select 120 as "IID", -1, N'Энергетические показатели', ' ' union
select 130 as "IID", 0, N'Общий расход энергии по счетчикам, кВт*ч', LTrim(cast(round(cast(DrawMeter as numeric),1) as varchar(15))) union
select 140 as "IID", 0, N'Удельный расход по счетчикам, кВт.ч х 10000 / т.км.бр', LTrim(cast(round(cast(DrawMeterSpec as numeric),1) as varchar(15))) union
select 150 as "IID", 0, N'Общая энергия рекуперации, кВт*ч', LTrim(cast(round(cast(RecMeter as numeric),1) as varchar(15))) union
select 160 as "IID", 0, N'Норма расхода энергии, кВт*ч', LTrim(cast(round(cast(Norma as numeric),1) as varchar(15))) union

select 161 as "IID", 0, N'Реактивная энергия, кВт*ч', LTrim(cast(round(cast(React as numeric),1) as varchar(15))) union
select 162 as "IID", 0, N'Маневровые работы, кВт*ч', LTrim(cast(round(cast(EnMan as numeric),1) as varchar(15))) union

select 170 as "IID", -1, N'Ограничения скорости', ' ' union
select 180 as "IID", 0, N'Общее кол-во постоянных ограничений', LTrim(cast(countCLim as varchar(8))) union
select 200 as "IID", 1, N'Среднее кол-во на маршрут', LTrim(cast(round(cast(avgCountCLim as numeric),1) as varchar(15))) union
select 210 as "IID", 0, N'Общее кол-во предупреждений', LTrim(cast(countTLim as varchar(8))) union
select 220 as "IID", 1, N'Суммарная протяженность, км', LTrim(cast(round(cast(lenAllTlim as numeric),1) as varchar(15))) union
select 230 as "IID", 1, N'Среднее кол-во на маршрут', LTrim(cast(round(cast(avgCountTLim as numeric),1) as varchar(15)))*/
order by "IID";

end;
$$
