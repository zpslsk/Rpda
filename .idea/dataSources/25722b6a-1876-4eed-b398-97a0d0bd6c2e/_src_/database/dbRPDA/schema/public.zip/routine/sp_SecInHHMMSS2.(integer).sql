CREATE FUNCTION sp_SecInHHMMSS2 ("@timeIn" integer, OUT "@timeOut" character varying) RETURNS character varying
	LANGUAGE plpgsql
AS $$
declare  nHour integer;
declare nMin integer;
declare nSec integer;
declare cMin varchar(2);
declare cSec varchar(2);
begin

if "@timeIn" < 1 then
  "@timeOut" := '00:00:00';
 else

 begin
 nHour := "@timeIn"/3600;
nMin := ("@timeIn" - nHour *3600)/60;
nSec := "@timeIn" - nHour *3600 - nMin * 60;

 if nHour < 10 then  "@timeOut" := '0' + str(nHour,1);
  else  "@timeOut":=Trim(Str(nHour,10,0));
  end if;

if nMin < 10 then cMin := '0' + str(nMin,1);
  else  cMin := str(nMin,2);
end if;
  
if nSec < 10 then cSec := '0' + str(nSec,1);
  else  cSec = str(nSec,2);
end if;

"@timeOut" := "@timeOut" || ':' || cMin || ':' || cSec;

 end;
end if;












end;
$$
