CREATE FUNCTION S_DEL_DRIVERS ("@RAILROAD_ID" integer, "@DEPOT_ID" integer, "@PERSON_NUMBER_DRIVER" integer) RETURNS integer
	LANGUAGE plpgsql
AS $$
declare n1 integer :=-1;
begin
select COALESCE("DRIVER_ID",0) into n1 from "DIRECTORY_DRIVERS"
 where "RAILROAD_ID"="@RAILROAD_ID" and "DEPOT_ID"="@DEPOT_ID" and "PERSON_NUMBER_DRIVER"="@PERSON_NUMBER_DRIVER";
IF (n1>0)
  Then
  begin
    delete from "DIRECTORY_DRIVERS"
     where "DRIVER_ID" = n1;
    return 0;
    end;
    else
   return -3;
END IF;

end; 
$$
