CREATE FUNCTION S_UP_USPROF ("@RAILROAD_ID" integer, "@DEPOT_ID" integer, "@USER_ID" integer, "@USER_PROFILE" integer, "@USER_LOGIN" character varying) RETURNS integer
	LANGUAGE plpgsql
AS $$
declare n1 integer :=-1;
begin
select COALESCE("USER_ID",0) into n1 from "DIRECTORY_USERS"
 where "RAILROAD_ID"="@RAILROAD_ID" and "DEPOT_ID"="@DEPOT_ID" and (Upper("USER_LOGIN")=Upper("@USER_LOGIN") or "USER_ID"="@USER_ID");
IF (n1 >0)
  Then
  begin
    Update "DIRECTORY_USERS" set "USER_PROFILE"="@USER_PROFILE"
     where "USER_ID" = n1;
    return 0;
    end;
    else
    return -3;
END IF;

end; 
$$
