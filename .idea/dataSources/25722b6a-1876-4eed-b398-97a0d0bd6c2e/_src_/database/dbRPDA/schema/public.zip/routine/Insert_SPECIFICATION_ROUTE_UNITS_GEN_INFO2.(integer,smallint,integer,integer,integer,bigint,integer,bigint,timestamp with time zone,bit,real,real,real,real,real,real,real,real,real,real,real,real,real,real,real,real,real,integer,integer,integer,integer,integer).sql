CREATE FUNCTION Insert_SPECIFICATION_ROUTE_UNITS_GEN_INFO2 ("@UNIT_ROUTE_ID" integer, "@TYPE_SYSTEM_USAVP" smallint, "@NET_WEIGHT_TRAIN_Kg" integer, "@SPECIFIC_CONSUMPTION_TRAIN_Wh_10000tnKm" integer, "@WORK_TRAIN_tn10000Km" integer, "@ID_ASUT1" bigint, "@ID_ASUT2" integer, "@POINTER_SYSTEM_CONFIG_RPDA" bigint, "@DATE_TIME_END_SHIFT" timestamp with time zone, "@E_Invalidate" bit, "@x_Common" real, "@x_SavpeAuto" real, "@x_SavpePrompt" real, "@DrawMeter" real, "@DrawMeter_1" real, "@DrawMeter_2" real, "@DrawMeter_3" real, "@RecupMeter" real, "@RecupMeter_1" real, "@RecupMeter_2" real, "@RecupMeter_3" real, "@Norma" real, "@DifNorma" real, "@NormaVt" real, "@DifNormaVt" real, "@av_speed" real, "@av_speed_move" real, "@countTLim" integer, "@train_time" integer, "@nKar" integer, "@SUM_ENERGY" integer, "@SUM_ENERGY_REACTIVE" integer) RETURNS integer
	LANGUAGE plpgsql
AS $$
declare COUNT_SECTIONS integer;
begin 

select count(*) into COUNT_SECTIONS from "SPECIFICATION_SECTIONS" where "UNIT_ROUTE_ID"="@UNIT_ROUTE_ID";

INSERT INTO "SPECIFICATION_ROUTE_UNITS_GEN_INFO"(
            "UNIT_ROUTE_ID", "COUNT_SECTIONS", 
            "TYPE_SYSTEM_USAVP", "NET_WEIGHT_TRAIN_Kg", "SPECIFIC_CONSUMPTION_TRAIN_Wh_10000tnKm", 
            "WORK_TRAIN_tn10000Km", "ID_ASUT1", "ID_ASUT2", "POINTER_SYSTEM_CONFIG_RPDA", 
            "DATE_TIME_END_SHIFT", "E_Invalidate", "x_Common", "x_SavpeAuto", 
            "x_SavpePrompt", "DrawMeter", "DrawMeter_1", "DrawMeter_2", "DrawMeter_3", 
            "RecupMeter", "RecupMeter_1", "RecupMeter_2", "RecupMeter_3", 
            "Norma", "DifNorma", "NormaVt", "DifNormaVt", "av_speed", "av_speed_move", 
            "countTLim", "train_time", "nKar","SUM_ENERGY","SUM_ENERGY_REACTIVE")
    VALUES ("@UNIT_ROUTE_ID", COUNT_SECTIONS, 
            "@TYPE_SYSTEM_USAVP", "@NET_WEIGHT_TRAIN_Kg", "@SPECIFIC_CONSUMPTION_TRAIN_Wh_10000tnKm", 
            "@WORK_TRAIN_tn10000Km", "@ID_ASUT1", "@ID_ASUT2", "@POINTER_SYSTEM_CONFIG_RPDA", 
            "@DATE_TIME_END_SHIFT", "@E_Invalidate", "@x_Common", "@x_SavpeAuto", 
            "@x_SavpePrompt", "@DrawMeter", "@DrawMeter_1", "@DrawMeter_2", "@DrawMeter_3", 
            "@RecupMeter", "@RecupMeter_1", "@RecupMeter_2", "@RecupMeter_3", 
            "@Norma", "@DifNorma", "@NormaVt", "@DifNormaVt", "@av_speed", "@av_speed_move", 
            "@countTLim", "@train_time", "@nKar","@SUM_ENERGY","@SUM_ENERGY_REACTIVE");
return 0;

end;
$$
