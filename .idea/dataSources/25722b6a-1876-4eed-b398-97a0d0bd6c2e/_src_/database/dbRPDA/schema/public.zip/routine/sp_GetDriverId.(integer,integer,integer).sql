CREATE FUNCTION sp_GetDriverId ("@tab_num" integer, "@num_road" integer, "@num_tch" integer) RETURNS integer
	LANGUAGE plpgsql
AS $$
declare drv_id integer;
declare drv_id1 integer;
declare r_id integer;
declare d_id integer;

begin

select  "DRIVER_ID" into drv_id 
from "DIRECTORY_DRIVERS"
where "PERSON_NUMBER_DRIVER" = "@tab_num" and
"RAILROAD_ID" in (select "RAILROAD_ID" from "DIRECTORY_RAILROADS" where   "CODE_RAILROAD"="@num_road") and
"DEPOT_ID" in (select  "DEPOT_ID" from "DIRECTORY_DEPOT" where  "CODE_DEPOT"="@num_tch");

select "RAILROAD_ID" into r_id from "DIRECTORY_RAILROADS" where   "CODE_RAILROAD"="@num_road"; 

select  "DEPOT_ID" into d_id from "DIRECTORY_DEPOT" where  "CODE_DEPOT"="@num_tch" and "RAILROAD_ID"=r_id;

if drv_id is null then
begin
if (r_id is null) or (d_id is null) then
begin
RAISE 'Не найдены код дороги или код депо';
Rollback transaction;

end;

end if;

end;
end if;

if drv_id is null then
begin
insert into "DIRECTORY_DRIVERS" ("PERSON_NUMBER_DRIVER", "SURNAME_DRIVER", "NAME_DRIVER", "PATRONYMIC_DRIVER","RAILROAD_ID","DEPOT_ID","NUMBER_COLUMN_DRIVER","CLASS_DRIVER","DATE_BIRTH_DRIVER","DATE_BEGIN_WORK_POST_DRIVER","POST_DRIVER")
Values("@tab_num", 'Таб.номер - ' || ltrim(cast("@tab_num" as varchar(100))), '', '', r_id, d_id,0,-1,'01.01.1900','01.01.1900',-1)
returning "DRIVER_ID" into drv_id1;
return drv_id1;
end;
else
return drv_id;
end if;


















end;
$$
