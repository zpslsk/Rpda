CREATE FUNCTION S_DEL_DEPO ("@RAILROAD_ID" integer, "@DEPOT_ID" integer) RETURNS integer
	LANGUAGE plpgsql
AS $$
declare n1 integer :=-1;
begin
select COALESCE("DEPOT_ID",0) into n1 from "DIRECTORY_DEPOT"
 where "RAILROAD_ID"="@RAILROAD_ID" and "DEPOT_ID"="@DEPOT_ID";
IF (n1>0)
  Then
    delete from "DIRECTORY_DEPOT"
     where "DEPOT_ID" = n1;
    return 0;
    else
    return -3;
END IF;

end; 

  
--else
  
	--select -3;
 

--END IF;
  
$$
