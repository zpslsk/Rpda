CREATE FUNCTION S_WSP_DEPO ("@RAILROAD_ID" integer, "@CODE_DEPOT" integer) RETURNS integer
	LANGUAGE plpgsql
AS $$
declare n1 integer :=-1;


begin

if "@RAILROAD_ID">1 then
  begin



select COALESCE("DEPOT_ID",0) into n1 from "DIRECTORY_DEPOT"
 where "RAILROAD_ID"="@RAILROAD_ID" and "CODE_DEPOT"="@CODE_DEPOT" and "DEP_ISP"=false;
IF (n1>0)
  Then
    begin

      
    
        Update "DIRECTORY_DEPOT"  set "DEP_ISP"=true
     where "DEPOT_ID" = n1;
    return n1;
                  
    end;
    else
     begin
     
    return -3;

     end;
    
END IF;
 
  end;
else
 return -1;

END IF;
 
end; 
$$
