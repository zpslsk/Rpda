CREATE FUNCTION S_WU_DEPO ("@RAILROAD_ID" integer, "@DEPOT_ID" integer, "@scapt" character varying, "@capt" character varying, "@CODE_DEPOT" integer) RETURNS integer
	LANGUAGE plpgsql
AS $$
declare n1 integer :=-1;
declare _new_id integer;
declare id_isp boolean :=false; 
begin

if "@RAILROAD_ID">1 then
  begin



select COALESCE("DEPOT_ID",0),COALESCE("DEP_ISP",false) into n1,id_isp from "DIRECTORY_DEPOT"
 where "RAILROAD_ID"="@RAILROAD_ID" and ("DEPOT_ID"="@DEPOT_ID" or "CODE_DEPOT"="@CODE_DEPOT");
IF (n1>0)
  Then
    begin

       if (id_isp=true) then
		  begin
    
        Update "DIRECTORY_DEPOT" set "NAME_DEPOT"="@scapt","DESCRIPTION_DEPOT"="@capt"
     where "DEPOT_ID" = n1;
    return n1;
                 end;
              else
              begin
                  return -4; -- Помечен как удаленный
              end;
              end if;   
    end;
    else
     begin
     insert into "DIRECTORY_DEPOT"("RAILROAD_ID","NAME_DEPOT","DESCRIPTION_DEPOT","CODE_DEPOT")
     -- Values(4,'ТЧ-10','',10);
        Values("@RAILROAD_ID","@scapt","@capt","@CODE_DEPOT")
	  RETURNING "DEPOT_ID" INTO _new_id;
--_new_id := currval('public.auto_id_users6');
  return _new_id;

return 889;
     end;
    
END IF;
 
  end;
else
 return -1;

END IF;
 
end; 
$$
