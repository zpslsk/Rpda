CREATE FUNCTION Test () RETURNS character varying
	LANGUAGE plpgsql
AS $$
declare cTimeCommon varchar(100);
begin
select  "sp_SecInHHMMSS"(
    70
) as d into cTimeCommon;


return PATINDEX('%\%', REVERSE('sdss%\%dsdsddsds'));
--return cTimeCommon;

end;
$$
