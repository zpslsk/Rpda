CREATE FUNCTION Delete_Locomotiv ("@loc_num" integer, "@loc_type" integer) RETURNS integer
	LANGUAGE plpgsql
AS $$
begin
delete from "DIRECTORY_SERIES_TRAINS"
where "CODE_CLASSIFIER" = "@loc_num" and
"TYPE_SERIES_TRAIN_ID" = "@loc_type";




return 0;






end;
$$
